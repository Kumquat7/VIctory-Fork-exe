//! Buffers in the PC's memory (upload, shared and read-back) by the place in
//! our code that asked for them: how many were made since the start and, with
//! `VICTORY_BUFFER_CENSUS=1`, how many are alive now.
//!
//! Why: on a 16 GB PC the process's private memory reached 16 GB in the world
//! (runs n09, n10), 4.5 GB of it write-combined in the driver's 32 and 64 MB
//! blocks. That is where it puts upload buffers (and command allocators, which
//! reuse what dropped ones left). 21,397 upload buffers of 12.6 GB were made in
//! ten minutes of n10, and the release memory line did not say by whom.
//!
//! The census holds a reference to each buffer it counts. A buffer that only the
//! census holds was let go by its owner: it is counted as gone and released at
//! the next census, a few seconds late.

use std::panic::Location;
use std::sync::{Mutex, OnceLock};

use windows::Win32::Graphics::Direct3D12::ID3D12Resource;
use windows::core::Interface;

/// Upload, shared or read-back.
pub(crate) const KINDS: [&str; 3] = ["upload", "shared", "read-back"];

struct Place {
    at: &'static Location<'static>,
    kind: u8,
    made: u64,
    made_bytes: u64,
    /// At the last census: made then, and alive then.
    seen_made: u64,
    alive: u64,
    alive_bytes: u64,
}

static PLACES: Mutex<Vec<Place>> = Mutex::new(Vec::new());
/// Buffers the census holds: the buffer, its bytes, its place.
static HELD: Mutex<Vec<(ID3D12Resource, u64, usize)>> = Mutex::new(Vec::new());

fn held<T>(m: &Mutex<T>) -> std::sync::MutexGuard<'_, T> {
    m.lock().unwrap_or_else(|e| e.into_inner())
}

/// Whether buffers alive are counted (`VICTORY_BUFFER_CENSUS=1`).
fn alive_counted() -> bool {
    static ON: OnceLock<bool> = OnceLock::new();
    *ON.get_or_init(|| std::env::var_os("VICTORY_BUFFER_CENSUS").is_some_and(|v| v == "1"))
}

/// A buffer of `kind` ([`KINDS`]) and `bytes` was made for `at`.
pub(crate) fn made(at: &'static Location<'static>, kind: u8, bytes: u64, buffer: &ID3D12Resource) {
    let i = {
        let mut places = held(&PLACES);
        let i = match places.iter().position(|p| std::ptr::eq(p.at, at) && p.kind == kind) {
            Some(i) => i,
            None => {
                places.push(Place { at, kind, made: 0, made_bytes: 0, seen_made: 0, alive: 0, alive_bytes: 0 });
                places.len() - 1
            }
        };
        places[i].made += 1;
        places[i].made_bytes += bytes;
        i
    };
    if alive_counted() {
        held(&HELD).push((buffer.clone(), bytes, i));
    }
}

/// The references a COM object has, read by an AddRef and a Release.
fn references(buffer: &ID3D12Resource) -> u32 {
    let raw = buffer.as_raw();
    // SAFETY: a live COM object (the census holds it); AddRef then Release
    // leave its count as it was and return it.
    unsafe {
        let vtable = *(raw as *const *const windows::core::IUnknown_Vtbl);
        ((*vtable).AddRef)(raw);
        ((*vtable).Release)(raw)
    }
}

/// For the release memory line: the places with the most bytes alive (with
/// the census) or made since the start, with what each made since the last
/// line. Lets go of the buffers only the census held.
pub(crate) fn line() -> String {
    let counted = alive_counted();
    let mut gone = Vec::new();
    let mut alive: Vec<(u64, u64)> = Vec::new();
    if counted {
        let mut held_now = held(&HELD);
        let places = held(&PLACES).len();
        alive = vec![(0, 0); places];
        let mut kept = Vec::with_capacity(held_now.len());
        for (buffer, bytes, i) in held_now.drain(..) {
            if references(&buffer) <= 1 {
                gone.push(buffer);
            } else {
                alive[i].0 += 1;
                alive[i].1 += bytes;
                kept.push((buffer, bytes, i));
            }
        }
        *held_now = kept;
    }
    // Released outside the lock.
    drop(gone);
    let mut places = held(&PLACES);
    for (i, p) in places.iter_mut().enumerate() {
        if let Some(&(n, b)) = alive.get(i) {
            p.alive = n;
            p.alive_bytes = b;
        }
    }
    let mut order: Vec<usize> = (0..places.len()).collect();
    if counted {
        order.sort_by_key(|&i| std::cmp::Reverse(places[i].alive_bytes));
    } else {
        order.sort_by_key(|&i| std::cmp::Reverse(places[i].made_bytes));
    }
    let mut out = String::new();
    for &i in order.iter().take(8) {
        let p = &places[i];
        let file = p.at.file().rsplit(['/', '\\']).next().unwrap_or(p.at.file());
        if !out.is_empty() {
            out.push_str("; ");
        }
        if counted {
            out.push_str(&format!(
                "{} {}:{} {} alive {} MB, made {} ({} MB), {} since the last line",
                KINDS[p.kind as usize],
                file,
                p.at.line(),
                p.alive,
                p.alive_bytes >> 20,
                p.made,
                p.made_bytes >> 20,
                p.made - p.seen_made
            ));
        } else {
            out.push_str(&format!(
                "{} {}:{} made {} ({} MB), {} since the last line",
                KINDS[p.kind as usize],
                file,
                p.at.line(),
                p.made,
                p.made_bytes >> 20,
                p.made - p.seen_made
            ));
        }
    }
    for p in places.iter_mut() {
        p.seen_made = p.made;
    }
    out
}
