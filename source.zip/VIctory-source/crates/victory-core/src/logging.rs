//! One tracing setup for every binary.
//!
//! Filter with `VICTORY_LOG` (falls back to `RUST_LOG`), e.g.
//! `VICTORY_LOG=victory_loader=trace,info`. Debug and trace output exist
//! only in builds with the `diagnostics` feature; a plain release build
//! logs info and above whatever the filter asks for.

use tracing_subscriber::EnvFilter;
use tracing_subscriber::filter::LevelFilter;
use tracing_subscriber::layer::SubscriberExt;
use tracing_subscriber::util::SubscriberInitExt;

/// The most verbose level this build can log.
const CAP: LevelFilter = if cfg!(feature = "diagnostics") {
    LevelFilter::TRACE
} else {
    LevelFilter::INFO
};

/// Lines below errors, written to stderr by a thread of their own.
///
/// Why: each line was written by the thread that logged it, synchronously.
/// The per-frame lines come from the thread that submits to the card, and
/// with the PC paging a write could wait on the disk: 44 % of that thread's
/// busy time in the world was in the write (profile n10, info level).
/// Errors are still written at once, so what comes before a crash is out.
/// `VICTORY_LOG_BEHIND=0`: every line at once, as before.
struct Behind;

impl std::io::Write for Behind {
    fn write(&mut self, buf: &[u8]) -> std::io::Result<usize> {
        match behind() {
            Some(lines) if lines.send(buf.to_vec()).is_ok() => Ok(buf.len()),
            _ => std::io::stderr().write(buf),
        }
    }

    fn flush(&mut self) -> std::io::Result<()> {
        Ok(())
    }
}

fn behind() -> Option<&'static std::sync::mpsc::Sender<Vec<u8>>> {
    static LINES: std::sync::OnceLock<Option<std::sync::mpsc::Sender<Vec<u8>>>> = std::sync::OnceLock::new();
    LINES
        .get_or_init(|| {
            if std::env::var_os("VICTORY_LOG_BEHIND").is_some_and(|v| v == "0") {
                return None;
            }
            let (lines, written) = std::sync::mpsc::channel::<Vec<u8>>();
            std::thread::Builder::new()
                .name("victory-log".into())
                .spawn(move || {
                    use std::io::Write;
                    let mut err = std::io::stderr();
                    for line in written {
                        let _ = err.write_all(&line);
                    }
                })
                .ok()?;
            Some(lines)
        })
        .as_ref()
}

pub fn init(default_level: &str) {
    use tracing_subscriber::fmt::writer::MakeWriterExt;
    let filter = std::env::var("VICTORY_LOG")
        .or_else(|_| std::env::var("RUST_LOG"))
        .ok()
        .and_then(|v| EnvFilter::try_new(v).ok())
        .unwrap_or_else(|| EnvFilter::new(default_level));
    let _ = tracing_subscriber::registry()
        .with(CAP)
        .with(filter)
        .with(
            tracing_subscriber::fmt::layer()
                .with_target(true)
                .with_writer(
                    std::io::stderr
                        .with_filter(|meta| LevelFilter::from_level(*meta.level()) == LevelFilter::ERROR)
                        .or_else(|| Behind),
                ),
        )
        .try_init();
}
