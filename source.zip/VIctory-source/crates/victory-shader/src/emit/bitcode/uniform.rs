//! Values the same in every thread that computes them, and the first-lane
//! reads of such values folded away.
//!
//! The console compiler moves a value every active lane holds to an SGPR
//! with `v_readfirstlane_b32` (a loop counter kept in a VGPR, a select
//! between scalars on a whole-wave mask). Each lowers to
//! `WaveReadLaneFirst`, whose result then feeds loads and loop-carried
//! values. NVIDIA's compiler (nvgpucomp64, driver 591) faults on some of
//! those shapes and the pipeline is refused with E_OUTOFMEMORY: 573 of the
//! title's pipelines, among them every skinned mesh variant that samples a
//! texture and the ray-tracing resolve passes. Bisection on two of them
//! (`avgLuminanceCompute:ColorDownsampleInitCS`, a `TransformSkin` mesh
//! shader) found the fault goes away when those reads are left out, and
//! comes back with the same read written as a ballot and `WaveReadLaneAt`.
//!
//! When the operand is provably the same in every thread, the read returns
//! it unchanged, so it is replaced by the operand: the same result, with no
//! wave operation. Reads of values that may differ (waterfall loops, a
//! title's own `WaveReadLaneFirst`) are kept.
//!
//! The analysis is the usual divergence analysis over the emitted function:
//! values start uniform, and divergence spreads from thread-varying sources
//! through data, through phis at the joins of divergent branches (within
//! the branch's region, up to its immediate post-dominator), and to uses
//! outside a loop of values defined in it when a divergent branch leaves
//! it. A branch condition is known in the blocks its edge dominates, which
//! keeps the emitter's repeated lane guards (`and %guard, ...` under a
//! branch on `%guard`) from making everything below them divergent.

use super::{Const, MdDef, Module, Op, Term, V, successors};

/// DXIL operations whose result is the same in every thread when their
/// operands are.
fn propagates(op: i64) -> bool {
    matches!(op,
        // Unary, binary and tertiary math, bit operations, dot products.
        6..=56
        // Handles and constant buffers.
        | 57..=59 | 216..=218
        // Reads with explicit levels or none (no implicit derivatives).
        | 62 | 63 | 65 | 66 | 68 | 72 | 73 | 74 | 139
        // The group's id.
        | 94
        // Double and half conversions.
        | 101 | 102 | 124..=134
        // Packing.
        | 219 | 220)
}

/// Reads of resource memory: the same in every thread only from read-only
/// views (a UAV may be written between two threads' reads).
fn reads_memory(op: i64) -> bool {
    matches!(op, 62 | 63 | 65 | 66 | 68 | 72 | 73 | 74 | 139)
}

/// Wave operations whose result is the same in every thread of the wave
/// that runs them.
fn wave_uniform(op: i64) -> bool {
    matches!(op, 112..=116 | 118..=120 | 135)
}

const READ_LANE_AT: i64 = 117;
const READ_FIRST_LANE: i64 = 118;
const ANNOTATE_HANDLE: i64 = 216;
/// `annotateHandle`'s first property word: a UAV.
const UAV: i64 = 0x1000;

/// A set of blocks.
#[derive(Clone, PartialEq, Eq)]
struct Bits(Vec<u64>);

impl Bits {
    fn new(n: usize) -> Self {
        Self(vec![0; n.div_ceil(64)])
    }
    fn full(n: usize) -> Self {
        let mut b = Self(vec![u64::MAX; n.div_ceil(64)]);
        if n % 64 != 0 {
            *b.0.last_mut().expect("a word") = (1u64 << (n % 64)) - 1;
        }
        b
    }
    fn has(&self, i: usize) -> bool {
        self.0[i / 64] >> (i % 64) & 1 != 0
    }
    fn set(&mut self, i: usize) {
        self.0[i / 64] |= 1 << (i % 64);
    }
    fn and(&mut self, o: &Self) {
        for (a, b) in self.0.iter_mut().zip(&o.0) {
            *a &= b;
        }
    }
    fn count(&self) -> u32 {
        self.0.iter().map(|w| w.count_ones()).sum()
    }
}

/// The control-flow facts the analysis needs.
struct Cfg {
    n: usize,
    succ: Vec<Vec<usize>>,
    pred: Vec<Vec<usize>>,
    /// Reachable blocks in reverse postorder.
    order: Vec<usize>,
    reachable: Vec<bool>,
    /// Dominators of each reachable block.
    dom: Vec<Bits>,
    /// Post-dominators of each reachable block (index `n` is the exit).
    pdom: Vec<Bits>,
    /// Natural loops: the blocks of each.
    loops: Vec<Bits>,
}

impl Cfg {
    /// `None` when some reachable block never reaches a return (the
    /// post-dominators would mean nothing).
    fn new(m: &Module) -> Option<Self> {
        let n = m.blocks.len();
        let succ: Vec<Vec<usize>> = m.blocks.iter().map(|b| successors(b.term).to_vec()).collect();
        let mut pred = vec![Vec::new(); n];
        // Reverse postorder from the entry.
        let mut reachable = vec![false; n];
        let mut post = Vec::new();
        let mut stack = vec![(0usize, 0usize)];
        reachable[0] = true;
        while let Some(top) = stack.last_mut() {
            let (b, k) = *top;
            top.1 += 1;
            match succ[b].get(k) {
                Some(&s) if !reachable[s] => {
                    reachable[s] = true;
                    stack.push((s, 0));
                }
                Some(_) => {}
                None => {
                    post.push(b);
                    stack.pop();
                }
            }
        }
        let order: Vec<usize> = post.iter().rev().copied().collect();
        for &b in &order {
            for &s in &succ[b] {
                pred[s].push(b);
            }
        }
        // Dominators.
        let mut dom = vec![Bits::full(n); n];
        dom[0] = Bits::new(n);
        dom[0].set(0);
        let mut changed = true;
        while changed {
            changed = false;
            for &b in order.iter().skip(1) {
                let mut d = Bits::full(n);
                for &p in &pred[b] {
                    d.and(&dom[p]);
                }
                d.set(b);
                if d != dom[b] {
                    dom[b] = d;
                    changed = true;
                }
            }
        }
        // Post-dominators, with a virtual exit after every return.
        let exit = n;
        let mut pdom = vec![Bits::full(n + 1); n + 1];
        pdom[exit] = Bits::new(n + 1);
        pdom[exit].set(exit);
        let mut changed = true;
        while changed {
            changed = false;
            for &b in post.iter() {
                let mut d = Bits::full(n + 1);
                if succ[b].is_empty() {
                    d.and(&pdom[exit]);
                }
                for &s in &succ[b] {
                    d.and(&pdom[s]);
                }
                d.set(b);
                if d != pdom[b] {
                    pdom[b] = d;
                    changed = true;
                }
            }
        }
        if order.iter().any(|&b| !pdom[b].has(exit)) {
            return None;
        }
        // Natural loops of the back edges (a branch to a dominator).
        let mut headers: Vec<(usize, Bits)> = Vec::new();
        for &b in &order {
            for &h in &succ[b] {
                if !dom[b].has(h) {
                    continue;
                }
                let mut body = Bits::new(n);
                body.set(h);
                let mut work = vec![b];
                while let Some(x) = work.pop() {
                    if body.has(x) {
                        continue;
                    }
                    body.set(x);
                    work.extend(pred[x].iter().copied());
                }
                match headers.iter_mut().find(|(hh, _)| *hh == h) {
                    Some((_, all)) => {
                        for (a, w) in all.0.iter_mut().zip(&body.0) {
                            *a |= w;
                        }
                    }
                    None => headers.push((h, body)),
                }
            }
        }
        let loops = headers.into_iter().map(|(_, b)| b).collect();
        Some(Self {
            n,
            succ,
            pred,
            order,
            reachable,
            dom,
            pdom,
            loops,
        })
    }

    /// The immediate post-dominator of `b` (the exit is `n`).
    fn ipdom(&self, b: usize) -> usize {
        let want = self.pdom[b].count() - 1;
        (0..=self.n)
            .filter(|&p| p != b && self.pdom[b].has(p))
            .find(|&p| self.pdom[p].count() == want)
            .unwrap_or(self.n)
    }

    /// Blocks reached from `from` without entering `branch` and without
    /// going past `stop` (which is included).
    fn region(&self, from: usize, branch: usize, stop: usize) -> Bits {
        let mut seen = Bits::new(self.n + 1);
        let mut work = vec![from];
        while let Some(x) = work.pop() {
            if x == branch || seen.has(x) {
                continue;
            }
            seen.set(x);
            if x == stop || x == self.n {
                continue;
            }
            work.extend(self.succ[x].iter().copied());
        }
        seen
    }
}

impl Module {
    /// Replaces each `dx.op.waveReadLaneFirst` whose operand is the same in
    /// every thread with that operand; returns how many were replaced.
    pub fn fold_uniform_first_lane_reads(&mut self) -> usize {
        let reads: Vec<(u32, V)> = self.call_sites(READ_FIRST_LANE);
        if reads.is_empty() {
            return 0;
        }
        let Some(div) = self.divergence() else {
            return 0;
        };
        let mut folded = 0;
        // A read of a folded read takes what that one was replaced with.
        let mut now = std::collections::HashMap::new();
        for (i, operand) in reads {
            // The read itself is divergent when it takes a value across a
            // divergent loop exit.
            if div.of(operand) || div.of(V::Inst(i)) {
                continue;
            }
            let mut operand = operand;
            while let V::Inst(o) = operand
                && let Some(&r) = now.get(&o)
            {
                operand = r;
            }
            now.insert(i, operand);
            self.replace_uses(V::Inst(i), operand);
            for b in &mut self.blocks {
                b.body.retain(|&x| x != i);
            }
            folded += 1;
        }
        if folded > 0 {
            self.drop_uncalled();
        }
        folded
    }

    /// Drops the declarations no written call uses (the validator refuses
    /// an unused external function).
    fn drop_uncalled(&mut self) {
        let mut used: Vec<bool> = self.funcs.iter().map(|f| f.body).collect();
        for md in &self.mds {
            if let MdDef::Value(_, V::Func(f)) = md {
                used[*f as usize] = true;
            }
        }
        let live = self.live();
        for (i, inst) in self.insts.iter().enumerate() {
            if let Op::Call(f, _) = inst.op
                && live[i]
            {
                used[f as usize] = true;
            }
        }
        if used.iter().all(|&u| u) {
            return;
        }
        let mut remap = vec![0u32; self.funcs.len()];
        let mut kept = Vec::new();
        for (i, f) in std::mem::take(&mut self.funcs).into_iter().enumerate() {
            if used[i] {
                remap[i] = kept.len() as u32;
                kept.push(f);
            }
        }
        self.funcs = kept;
        self.func_ids = self
            .funcs
            .iter()
            .enumerate()
            .map(|(i, f)| (f.name.clone(), i as u32))
            .collect();
        for inst in &mut self.insts {
            if let Op::Call(f, _) = &mut inst.op {
                // A dropped callee's calls are not written.
                *f = remap[*f as usize];
            }
        }
        for md in &mut self.mds {
            if let MdDef::Value(_, V::Func(f)) = md {
                *f = remap[*f as usize];
            }
        }
    }

    /// Whether a call of a wave or quad operation (both need the wave-ops
    /// feature flag) is left in a block.
    pub fn calls_wave_ops(&self) -> bool {
        self.blocks.iter().flat_map(|b| &b.body).any(|&i| {
            matches!(&self.insts[i as usize].op, Op::Call(f, _)
                if ["dx.op.wave", "dx.op.quad"]
                    .iter()
                    .any(|p| self.funcs[*f as usize].name.starts_with(p)))
        })
    }

    /// Calls of DXIL operation `opcode` in a block: each call and its first
    /// operand after the opcode.
    fn call_sites(&self, opcode: i64) -> Vec<(u32, V)> {
        self.blocks
            .iter()
            .flat_map(|b| &b.body)
            .filter_map(|&i| match &self.insts[i as usize].op {
                Op::Call(_, args) if self.opcode(i).is_some_and(|o| o == opcode) => {
                    args.get(1).map(|&a| (i, a))
                }
                _ => None,
            })
            .collect()
    }

    /// The DXIL opcode of call `i`, if it is one.
    fn opcode(&self, i: u32) -> Option<i64> {
        let Op::Call(f, args) = &self.insts[i as usize].op else {
            return None;
        };
        if !self.funcs[*f as usize].name.starts_with("dx.op.") {
            return None;
        }
        self.int_value(*args.first()?)
    }

    /// Whether `handle` may be a UAV: anything but an annotated read-only
    /// view.
    fn may_write(&self, handle: V) -> bool {
        let V::Inst(h) = handle else { return true };
        if self.opcode(h) != Some(ANNOTATE_HANDLE) {
            return true;
        }
        let Op::Call(_, args) = &self.insts[h as usize].op else {
            return true;
        };
        let Some(&V::Const(props)) = args.get(2) else {
            return true;
        };
        let Const::Aggregate(fields) = &self.consts[props as usize].1 else {
            return true;
        };
        let Some(&first) = fields.first() else {
            return true;
        };
        match self.consts[first as usize].1 {
            Const::Int(p) => p & UAV != 0,
            _ => true,
        }
    }

    fn replace_uses(&mut self, old: V, new: V) {
        let swap = |v: &mut V| {
            if *v == old {
                *v = new;
            }
        };
        for inst in &mut self.insts {
            match &mut inst.op {
                Op::Bin(_, a, b) | Op::Cmp(_, a, b) | Op::Store(a, b) | Op::AtomicRmw(_, a, b) => {
                    swap(a);
                    swap(b);
                }
                Op::Cast(_, a) | Op::Extract(a, _) | Op::Load(a) => swap(a),
                Op::Select(a, b, c) | Op::CmpXchg(a, b, c) => {
                    swap(a);
                    swap(b);
                    swap(c);
                }
                Op::Call(_, args) => args.iter_mut().for_each(swap),
                Op::Phi(inc) => inc.iter_mut().for_each(|(v, _)| swap(v)),
                Op::Gep(_, p, idx) => {
                    swap(p);
                    idx.iter_mut().for_each(swap);
                }
            }
        }
        for b in &mut self.blocks {
            if let Some(Term::CondBr(c, ..)) = &mut b.term {
                swap(c);
            }
        }
    }

    /// Which instruction results may differ between threads.
    fn divergence(&self) -> Option<Divergence> {
        let cfg = Cfg::new(self)?;
        let ni = self.insts.len();
        let mut block_of = vec![usize::MAX; ni];
        for (b, blk) in self.blocks.iter().enumerate() {
            for &i in blk.phis.iter().chain(&blk.body) {
                block_of[i as usize] = b;
            }
        }
        // Branch conditions known on the edges they dominate: (condition,
        // the edge's target, its value there).
        let mut known: Vec<(u32, usize, bool)> = Vec::new();
        for &b in &cfg.order {
            if let Some(Term::CondBr(V::Inst(c), t, f)) = self.blocks[b].term
                && t != f
            {
                for (to, value) in [(t, true), (f, false)] {
                    if cfg.pred[to].len() == 1 {
                        known.push((c, to, value));
                    }
                }
            }
        }
        let is_known = |c: u32, at: usize| {
            at != usize::MAX
                && known
                    .iter()
                    .any(|&(k, to, _)| k == c && cfg.reachable[at] && cfg.dom[at].has(to))
        };
        let mut div = vec![false; ni];
        // Uses forced divergent: values from a loop a divergent branch
        // leaves, read outside it.
        let mut forced = vec![false; ni];
        let mut forced_branch = vec![false; cfg.n];
        let mut joins = vec![false; cfg.n];
        let mut done = vec![false; cfg.n];
        let value = |div: &[bool], v: V, at: usize| match v {
            V::Inst(i) => div[i as usize] && !is_known(i, at),
            _ => false,
        };
        loop {
            let mut changed = false;
            for &b in &cfg.order {
                let blk = &self.blocks[b];
                for &i in blk.phis.iter().chain(&blk.body) {
                    if div[i as usize] {
                        continue;
                    }
                    let any = |vs: &[V]| vs.iter().any(|&v| value(&div, v, b));
                    let d = forced[i as usize]
                        || match &self.insts[i as usize].op {
                            Op::Bin(_, a, c) | Op::Cmp(_, a, c) => any(&[*a, *c]),
                            Op::Cast(_, a) | Op::Extract(a, _) => any(&[*a]),
                            Op::Select(a, c, e) => any(&[*a, *c, *e]),
                            Op::Gep(_, p, idx) => any(&[*p]) || any(idx),
                            Op::Phi(inc) => {
                                joins[b] || inc.iter().any(|&(v, from)| value(&div, v, from))
                            }
                            Op::Load(p) => !self.constant_table(*p) || any(&[*p]),
                            Op::Call(_, args) => match self.opcode(i) {
                                Some(o) if wave_uniform(o) => false,
                                Some(READ_LANE_AT) => args.get(2).is_none_or(|&l| value(&div, l, b)),
                                Some(o) if propagates(o) => {
                                    any(&args[1..])
                                        || reads_memory(o)
                                            && args.get(1).is_none_or(|&h| self.may_write(h))
                                }
                                _ => true,
                            },
                            Op::Store(..) | Op::AtomicRmw(..) | Op::CmpXchg(..) => true,
                        };
                    if d {
                        div[i as usize] = true;
                        changed = true;
                    }
                }
            }
            for &t in &cfg.order {
                let Some(Term::CondBr(c, s1, s2)) = self.blocks[t].term else {
                    continue;
                };
                if done[t] || s1 == s2 || !(forced_branch[t] || value(&div, c, t)) {
                    continue;
                }
                done[t] = true;
                changed = true;
                // Phis where the two sides meet, up to where they all do.
                let stop = cfg.ipdom(t);
                let (r1, r2) = (cfg.region(s1, t, stop), cfg.region(s2, t, stop));
                for b in 0..cfg.n {
                    if r1.has(b) && r2.has(b) {
                        joins[b] = true;
                    }
                }
                // Leaving a loop at different iterations: what the loop
                // computed differs between threads after it.
                for body in cfg.loops.iter().filter(|l| l.has(t)) {
                    if body.has(s1) && body.has(s2) {
                        continue;
                    }
                    let inside = |i: u32| {
                        let b = block_of[i as usize];
                        b != usize::MAX && body.has(b)
                    };
                    for (u, inst) in self.insts.iter().enumerate() {
                        let ub = block_of[u];
                        if ub == usize::MAX || body.has(ub) {
                            continue;
                        }
                        let mut reads = false;
                        super::for_each_operand(&inst.op, |v| {
                            reads |= matches!(v, V::Inst(i) if inside(i));
                        });
                        if reads {
                            forced[u] = true;
                        }
                    }
                    for (b, blk) in self.blocks.iter().enumerate() {
                        if let Some(Term::CondBr(V::Inst(c), ..)) = blk.term
                            && !body.has(b)
                            && inside(c)
                        {
                            forced_branch[b] = true;
                        }
                    }
                }
            }
            if !changed {
                break;
            }
        }
        Some(Divergence { div, block_of })
    }

    /// Whether `p` points into an internal constant table.
    fn constant_table(&self, p: V) -> bool {
        let base = match p {
            V::Inst(i) => match &self.insts[i as usize].op {
                Op::Gep(_, base, _) => *base,
                _ => return false,
            },
            other => other,
        };
        matches!(base, V::Global(g) if self.globals[g as usize].init.is_some())
    }
}

struct Divergence {
    div: Vec<bool>,
    #[allow(dead_code)]
    block_of: Vec<usize>,
}

impl Divergence {
    fn of(&self, v: V) -> bool {
        match v {
            V::Inst(i) => self.div[i as usize],
            _ => false,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::super::{Attr, Bin, Term, for_each_operand, pred};
    use super::*;

    /// How many operands and branch conditions name `target`.
    fn uses_of(m: &Module, target: V) -> usize {
        let mut n = 0;
        for inst in &m.insts {
            for_each_operand(&inst.op, |v| n += usize::from(v == target));
        }
        for b in &m.blocks {
            if let Some(Term::CondBr(c, ..)) = b.term {
                n += usize::from(c == target);
            }
        }
        n
    }

    /// A module with `dx.op.*` declarations for the tests.
    struct T {
        m: Module,
        i32t: super::super::Ty,
    }

    impl T {
        fn new() -> Self {
            let mut m = Module::default();
            let i32t = m.int(32);
            Self { m, i32t }
        }
        fn op(&mut self, block: usize, name: &str, opcode: u32, args: &[V]) -> V {
            let i32t = self.i32t;
            let mut params = vec![i32t];
            params.extend(args.iter().map(|&a| self.m.type_of(a)));
            let fty = self.m.func_ty(i32t, params);
            self.m.ptr(fty);
            let f = self.m.function(&format!("dx.op.{name}"), fty, Some(Attr::NoUnwind), false);
            let mut all = vec![self.m.i32(opcode)];
            all.extend(args);
            self.m.call(block, f, all)
        }
        fn thread(&mut self, block: usize) -> V {
            self.op(block, "flattenedThreadIdInGroup.i32", 96, &[])
        }
        fn first(&mut self, block: usize, v: V) -> V {
            self.op(block, "waveReadLaneFirst.i32", 118, &[v])
        }
        /// Stores `v` so it stays read.
        fn keep(&mut self, block: usize, v: V) {
            let k = self.m.i32(0);
            self.op(block, "bufferStore.i32", 69, &[k, v]);
        }
    }

    #[test]
    fn a_loop_counter_read_from_the_first_lane_is_folded() {
        let mut t = T::new();
        let (entry, head, exit) = (t.m.new_block(), t.m.new_block(), t.m.new_block());
        t.m.terminate(entry, Term::Br(head));
        let i32t = t.i32t;
        let n = t.m.phi(head, i32t);
        let one = t.m.i32(1);
        let next = t.m.bin(head, Bin::Add, n, one);
        let r = t.first(head, next);
        t.keep(head, r);
        let limit = t.m.i32(8);
        let more = t.m.cmp(head, pred::IULT, next, limit);
        t.m.terminate(head, Term::CondBr(more, head, exit));
        let zero = t.m.i32(0);
        t.m.set_phi(n, vec![(zero, entry), (next, head)]);
        t.m.terminate(exit, Term::Ret);
        assert_eq!(t.m.fold_uniform_first_lane_reads(), 1);
        assert!(!t.m.calls_wave_ops());
        assert!(!t.m.funcs.iter().any(|f| f.name.starts_with("dx.op.waveReadLaneFirst")));
        assert!(t.m.funcs.iter().any(|f| f.name == "dx.op.bufferStore.i32"));
        // The store reads the count itself now.
        assert_eq!(uses_of(&t.m, r), 0);
    }

    #[test]
    fn a_read_of_a_folded_read_takes_its_operand() {
        let mut t = T::new();
        let entry = t.m.new_block();
        let k = t.m.i32(5);
        let one = t.m.i32(1);
        let x = t.m.bin(entry, Bin::Add, k, one);
        let a = t.first(entry, x);
        let b = t.first(entry, a);
        t.keep(entry, b);
        t.m.terminate(entry, Term::Ret);
        assert_eq!(t.m.fold_uniform_first_lane_reads(), 2);
        // The store reads `x`; the folded reads are out of their block.
        assert_eq!(uses_of(&t.m, b), 0);
        assert!(!t.m.calls_wave_ops());
    }

    #[test]
    fn quad_reads_still_count_as_wave_operations() {
        let mut t = T::new();
        let entry = t.m.new_block();
        let k = t.m.i32(5);
        let r = t.first(entry, k);
        t.keep(entry, r);
        let lane = t.m.i32(1);
        let q = t.op(entry, "quadReadLaneAt.i32", 122, &[k, lane]);
        t.keep(entry, q);
        t.m.terminate(entry, Term::Ret);
        assert_eq!(t.m.fold_uniform_first_lane_reads(), 1);
        assert!(t.m.calls_wave_ops());
    }

    #[test]
    fn a_thread_value_read_from_the_first_lane_is_kept() {
        let mut t = T::new();
        let entry = t.m.new_block();
        let id = t.thread(entry);
        let r = t.first(entry, id);
        t.keep(entry, r);
        t.m.terminate(entry, Term::Ret);
        assert_eq!(t.m.fold_uniform_first_lane_reads(), 0);
        assert!(t.m.calls_wave_ops());
    }

    #[test]
    fn constants_merged_after_a_divergent_branch_are_kept() {
        // The console's `v_mov v0, -1` under a narrowed EXEC: -1 in the
        // lanes that took the branch, 0 in the others.
        let mut t = T::new();
        let (entry, then, join) = (t.m.new_block(), t.m.new_block(), t.m.new_block());
        let id = t.thread(entry);
        let zero = t.m.i32(0);
        let c = t.m.cmp(entry, pred::EQ, id, zero);
        t.m.terminate(entry, Term::CondBr(c, then, join));
        t.m.terminate(then, Term::Br(join));
        let i32t = t.i32t;
        let p = t.m.phi(join, i32t);
        let all = t.m.i32(u32::MAX);
        t.m.set_phi(p, vec![(zero, entry), (all, then)]);
        let r = t.first(join, p);
        t.keep(join, r);
        t.m.terminate(join, Term::Ret);
        assert_eq!(t.m.fold_uniform_first_lane_reads(), 0);
    }

    #[test]
    fn a_guard_is_known_under_its_own_branch() {
        // Only thread 0 runs the loop; its exit tests the guard again
        // (`and %guard, ...`), which is true wherever the loop runs.
        let mut t = T::new();
        let b: Vec<usize> = (0..5).map(|_| t.m.new_block()).collect();
        let (entry, body, head, latch, exit) = (b[0], b[1], b[2], b[3], b[4]);
        let id = t.thread(entry);
        let zero = t.m.i32(0);
        let guard = t.m.cmp(entry, pred::EQ, id, zero);
        t.m.terminate(entry, Term::CondBr(guard, body, exit));
        t.m.terminate(body, Term::Br(head));
        let i32t = t.i32t;
        let n = t.m.phi(head, i32t);
        let one = t.m.i32(1);
        let next = t.m.bin(head, Bin::Add, n, one);
        let limit = t.m.i32(8);
        let below = t.m.cmp(head, pred::IULT, next, limit);
        let more = t.m.bin(head, Bin::And, guard, below);
        t.m.terminate(head, Term::CondBr(more, latch, exit));
        let r = t.first(latch, next);
        t.keep(latch, r);
        t.m.terminate(latch, Term::Br(head));
        t.m.set_phi(n, vec![(zero, body), (next, latch)]);
        t.m.terminate(exit, Term::Ret);
        assert_eq!(t.m.fold_uniform_first_lane_reads(), 1);
    }

    #[test]
    fn a_counter_read_after_a_divergent_loop_exit_is_kept() {
        // Threads leave at different iterations: the counter after the
        // loop differs between them.
        let mut t = T::new();
        let (entry, head, exit) = (t.m.new_block(), t.m.new_block(), t.m.new_block());
        let id = t.thread(entry);
        t.m.terminate(entry, Term::Br(head));
        let i32t = t.i32t;
        let n = t.m.phi(head, i32t);
        let one = t.m.i32(1);
        let next = t.m.bin(head, Bin::Add, n, one);
        let more = t.m.cmp(head, pred::IULT, next, id);
        t.m.terminate(head, Term::CondBr(more, head, exit));
        let zero = t.m.i32(0);
        t.m.set_phi(n, vec![(zero, entry), (next, head)]);
        let inside = t.first(head, next);
        t.keep(head, inside);
        let after = t.first(exit, next);
        t.keep(exit, after);
        t.m.terminate(exit, Term::Ret);
        // Inside the loop every thread still running has the same count.
        assert_eq!(t.m.fold_uniform_first_lane_reads(), 1);
        assert!(t.m.calls_wave_ops());
    }

    #[test]
    fn uav_reads_are_not_uniform() {
        let mut t = T::new();
        let entry = t.m.new_block();
        let zero = t.m.i32(0);
        let handle = t.op(entry, "createHandleFromHeap", 218, &[zero]);
        let i32t = t.i32t;
        let props_ty = t.m.named_struct("dx.types.ResourceProperties", vec![i32t, i32t]);
        let (uav, k) = (t.m.i32(0x1000 | 11), t.m.i32(0));
        let props = t.m.aggregate(props_ty, &[uav, k]);
        let h = t.op(entry, "annotateHandle", 216, &[handle, props]);
        let x = t.op(entry, "rawBufferLoad.i32", 139, &[h, zero]);
        let r = t.first(entry, x);
        t.keep(entry, r);
        let (srv, _) = (t.m.i32(11), ());
        let props = t.m.aggregate(props_ty, &[srv, k]);
        let h = t.op(entry, "annotateHandle", 216, &[handle, props]);
        let y = t.op(entry, "rawBufferLoad.i32", 139, &[h, zero]);
        let r = t.first(entry, y);
        t.keep(entry, r);
        t.m.terminate(entry, Term::Ret);
        assert_eq!(t.m.fold_uniform_first_lane_reads(), 1);
    }
}
