//! The title's hang watch, given longer (`VICTORY_TITLE_HANG_S=<seconds>`; off without it).
//!
//! A thread of the title's looks once a second at a word its main loop writes every frame; when
//! the word stays the same for 30 of those looks in a row, the thread ends the process as a hang.
//! On a PC with little memory the host can stand still that long while it pages (a 155 MB refresh
//! with 571 MB of the PC's memory free, then 50 s without a line, runs p02-p05), and the run ends
//! where the console would have gone on. Here the 30 becomes the asked number at each place that
//! sets the count, in the build of the title these places were read in; an image whose bytes
//! there differ is left as it is.

/// The places that set the count (offsets in the image), each `mov ebp, 30` or `mov ebx, 30`.
const PLACES: [usize; 8] = [0x2215acc, 0x2215b3a, 0x2215b62, 0x2215bfd, 0x2215c64, 0x2215cde, 0x2215d06, 0x2215d67];

/// Whether `code` is a `mov ebp/ebx, 30`.
fn sets_thirty(code: [u8; 5]) -> bool {
    matches!(code, [0xbd | 0xbb, 30, 0, 0, 0])
}

/// The seconds asked for, if any: at least the title's own 30.
fn asked() -> Option<u32> {
    let seconds: u32 = std::env::var("VICTORY_TITLE_HANG_S").ok()?.trim().parse().ok()?;
    (seconds > 30).then_some(seconds)
}

/// Gives the hang watch of the image at `base` (`size` bytes) the asked seconds: how many places
/// were changed (all or none).
///
/// # Safety
/// The image stays mapped, and no thread runs its code yet.
pub unsafe fn lengthen_asked(base: usize, size: usize) -> usize {
    use windows_sys::Win32::System::Diagnostics::Debug::FlushInstructionCache;
    use windows_sys::Win32::System::Memory::{PAGE_EXECUTE_READWRITE, VirtualProtect};
    use windows_sys::Win32::System::Threading::GetCurrentProcess;
    let Some(seconds) = asked() else {
        return 0;
    };
    if PLACES.iter().any(|&at| at + 5 > size) {
        return 0;
    }
    // SAFETY: five bytes inside the image at each place.
    let all = PLACES.iter().all(|&at| sets_thirty(unsafe { std::ptr::read_unaligned((base + at) as *const [u8; 5]) }));
    if !all {
        tracing::warn!("VICTORY_TITLE_HANG_S: this title's hang watch is not where it was read; left as it is");
        return 0;
    }
    let mut done = 0;
    for at in PLACES.map(|at| base + at + 1) {
        let mut old = 0;
        // SAFETY: the instruction's constant, whose page is made writable for it and put back;
        // nothing runs it yet.
        unsafe {
            if VirtualProtect(at as *const _, 4, PAGE_EXECUTE_READWRITE, &mut old) == 0 {
                continue;
            }
            std::ptr::write_unaligned(at as *mut u32, seconds);
            VirtualProtect(at as *const _, 4, old, &mut old);
            FlushInstructionCache(GetCurrentProcess(), at as *const _, 4);
        }
        done += 1;
    }
    tracing::info!(seconds, places = done, "the title's hang watch waits longer (VICTORY_TITLE_HANG_S)");
    done
}

#[cfg(test)]
mod tests {
    use super::sets_thirty;

    #[test]
    fn only_a_count_of_thirty_is_changed() {
        assert!(sets_thirty([0xbd, 0x1e, 0, 0, 0]));
        assert!(sets_thirty([0xbb, 0x1e, 0, 0, 0]));
        assert!(!sets_thirty([0xbd, 0x1f, 0, 0, 0]));
        assert!(!sets_thirty([0xb8, 0x1e, 0, 0, 0]));
    }
}
