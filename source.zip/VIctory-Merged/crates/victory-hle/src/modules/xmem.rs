//! `xmem.dll`: console memory, served from host memory. The GPU side works
//! from CPU addresses (unified memory), so memory types and bandwidth
//! classes change nothing here; what constrains addresses (alignment,
//! 2 MiB pages, address-bit limits) is honoured.
#![allow(non_snake_case)]
// Title code calls these through its import table, passing pointers the real
// API would trust.
#![allow(clippy::not_unsafe_ptr_arg_deref)]

use std::alloc::{Layout, alloc, dealloc};
use std::collections::{BTreeMap, HashMap};
use std::ffi::c_void;
use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};
use std::sync::{Arc, LazyLock, Mutex, MutexGuard, RwLock, RwLockReadGuard, RwLockWriteGuard};

use windows_sys::Win32::Foundation::{
    CloseHandle, ERROR_COMMITMENT_LIMIT, HANDLE, INVALID_HANDLE_VALUE,
};
use windows_sys::Win32::System::Memory::{
    CreateFileMappingW, MEM_ADDRESS_REQUIREMENTS, MEM_COMMIT, MEM_EXTENDED_PARAMETER,
    MEM_PRESERVE_PLACEHOLDER, MEM_RELEASE, MEM_REPLACE_PLACEHOLDER, MEM_RESERVE,
    MEM_RESERVE_PLACEHOLDER, MEMORY_BASIC_INFORMATION, MEMORY_MAPPED_VIEW_ADDRESS, MapViewOfFile3,
    MemExtendedParameterAddressRequirements, PAGE_NOACCESS, PAGE_READWRITE, SEC_COMMIT,
    SEC_RESERVE, UnmapViewOfFile2, VirtualAlloc, VirtualAlloc2, VirtualFree, VirtualQueryEx,
};
use windows_sys::Win32::System::ProcessStatus::{
    K32GetPerformanceInfo, K32GetProcessMemoryInfo, PERFORMANCE_INFORMATION,
    PROCESS_MEMORY_COUNTERS,
};
use windows_sys::Win32::System::Threading::GetCurrentProcess;
use windows_sys::core::BOOL;

use crate::{HleModule, hle_export};

const MIB: usize = 1 << 20;

/// Whether we run under Wine (its ntdll exports `wine_get_version`).
pub(crate) fn on_wine() -> bool {
    static WINE: LazyLock<bool> = LazyLock::new(|| {
        use windows_sys::Win32::System::LibraryLoader::{GetModuleHandleA, GetProcAddress};
        // SAFETY: plain lookups in ntdll, always loaded.
        unsafe {
            let ntdll = GetModuleHandleA(c"ntdll.dll".as_ptr().cast());
            !ntdll.is_null() && GetProcAddress(ntdll, c"wine_get_version".as_ptr().cast()).is_some()
        }
    });
    *WINE
}

/// Standard memory the title has handed to the system.
static TRANSFERRED: AtomicUsize = AtomicUsize::new(0);

// Console additions to the host's flags.
/// 2 MiB pages; the host reads this bit as large pages, which need a
/// privilege.
const PAGES_2M: u32 = 0x2000_0000;
/// With `PAGES_2M`: 64 KiB pages; the host reads it as AWE memory.
const PAGES_64K_BIT: u32 = 0x40_0000;
const PAGES_64K: u32 = PAGES_2M | PAGES_64K_BIT;
/// The host's protection constants and `PAGE_GUARD`. Above them the console
/// adds GPU access bits (0x800-0x40000). Write-combining and uncached are
/// dropped too: our GPU side reads this memory through the CPU.
const HOST_PROTECTION: u32 = 0x1ff;
/// XMem flags of memory both processors reach: all of ours.
const GRAPHICS: u64 = 3;
/// XMem flag bit of 32-bit graphics memory.
const ADDRESS_32BIT: u64 = 4;
/// The host's write watching (not in windows-sys' memory module).
const MEM_WRITE_WATCH: u32 = 0x20_0000;

/// The addresses XMem `flags` allow, first and last: the low 4 GiB for
/// 32-bit memory; else from 4 GiB (kept for 32-bit requests, which the
/// title's big pools would otherwise crowd out) up to 46 down to 40 bits
/// from the field at bit 12, or 40 bits without one: the console keeps
/// title memory there, and its ray-tracing structures must be (
/// the title's BVH builder refuses one above; the title asks for its GPU heap
/// with no field). Decision 0001.
fn address_range(flags: u64) -> (usize, usize) {
    let bits = match (flags & ADDRESS_32BIT, flags >> 12 & 7) {
        (0, 0) => 40,
        (0, field) => 47 - field,
        _ => return (0, u32::MAX as usize),
    };
    (1 << 32, (1 << bits) - 1)
}

pub extern "system" fn XMemVirtualAlloc(
    base: *mut c_void,
    size: usize,
    kind: u32,
    flags: u64,
    protect: u32,
) -> *mut c_void {
    // Asked of addresses a lazy view shows: as if the view were mapped.
    if !base.is_null() {
        materialize_for(base as usize, size, Touch::TitleCall);
    }
    let (lowest, highest) = address_range(flags);
    let mut requirements = MEM_ADDRESS_REQUIREMENTS {
        LowestStartingAddress: lowest as *mut c_void,
        HighestEndingAddress: highest as *mut c_void,
        Alignment: if kind & (PAGES_2M | PAGES_64K_BIT) == PAGES_2M {
            2 * MIB
        } else {
            0
        },
    };
    let asked = protect;
    let mut protect = match protect & HOST_PROTECTION {
        0 => PAGE_NOACCESS,
        p => p,
    };
    // A reservation of 64 KiB pages takes physical pages later
    // (`XMemMapPhysicalPages`); on the host only a placeholder can.
    // shortcut: committing part of such a reservation later would fail
    // (the title's 23 calls never do); replace that part of the
    // placeholder then.
    let placeholder = kind & PAGES_64K == PAGES_64K && kind & MEM_COMMIT == 0;
    if placeholder {
        if kind & MEM_REPLACE_PLACEHOLDER != 0 {
            // Part of a placeholder the title split: it stays one.
            return base;
        }
        protect = PAGE_NOACCESS;
    }
    let mut kind = kind & !(PAGES_2M | PAGES_64K_BIT);
    if placeholder {
        kind |= MEM_RESERVE | MEM_RESERVE_PLACEHOLDER;
    }
    let mut parameter = MEM_EXTENDED_PARAMETER::default();
    parameter.Anonymous1._bitfield = MemExtendedParameterAddressRequirements as u64;
    parameter.Anonymous2.Pointer = (&raw mut requirements).cast();
    // Address requirements apply to reservations at an address of our choice.
    let constrained = base.is_null();
    if constrained {
        kind |= MEM_RESERVE;
        // The GPU side copies only the pages the title wrote since its last
        // copy (`victory_gpu`, decision 0007); placeholders cannot be
        // watched (their physical-page views are copied whole).
        if kind & MEM_RESERVE_PLACEHOLDER == 0 {
            kind |= MEM_WRITE_WATCH;
        }
    }
    // SAFETY: the title's own arguments, cleaned of console bits; the
    // parameter points at `requirements`, which outlives the call.
    let at = unsafe {
        VirtualAlloc2(
            GetCurrentProcess(),
            base,
            size,
            kind,
            protect,
            if constrained {
                &mut parameter
            } else {
                std::ptr::null_mut()
            },
            constrained.into(),
        )
    };
    if at.is_null() {
        let error = std::io::Error::last_os_error();
        if kind & MEM_COMMIT != 0 {
            commit_refused(size, "virtual memory", error);
        } else {
            tracing::warn!(
                size,
                kind = format_args!("{kind:#x}"),
                flags = format_args!("{flags:#x}"),
                %error,
                "XMemVirtualAlloc refused"
            );
        }
    }
    if base.is_null() {
        tracing::debug!(
            size,
            kind = format_args!("{kind:#x}"),
            flags = format_args!("{flags:#x}"),
            at = format_args!("{at:p}"),
            "XMemVirtualAlloc"
        );
    }
    if !at.is_null() && !placeholder {
        victory_gpu::title_memory_allocated(at as usize, size);
    }
    // Write-combined: memory the title's CPU writes and does not read.
    if !at.is_null() && asked & 0x400 != 0 {
        victory_gpu::title_memory_write_combined(at as usize, size);
    }
    // (Grand Theft Auto VI asks for its 32-bit heap with kind 0x42000,
    // without the 64 KiB page bits: not `placeholder` above, though the host
    // makes a placeholder of it all the same.)
    if !at.is_null() && constrained && kind & MEM_COMMIT == 0 && flags & ADDRESS_32BIT != 0 {
        LOW_RESERVATIONS.lock().unwrap_or_else(|e| e.into_inner()).push((at as usize, size));
    }
    note_protection(asked, kind, flags, at as usize, size);
    at
}

/// What the title asks its memory to be (the console's protection, with the
/// bits that say how each processor reaches it: 0x200 uncached, 0x400
/// write-combined, 0x800 and on the GPU's): said for the 1st, 2nd, 4th.. time of
/// each, with how much so far. (For placing it: memory the CPU reaches
/// uncached or write-combined is memory it does not read.)
fn note_protection(protect: u32, kind: u32, flags: u64, at: usize, size: usize) {
    type Seen = std::collections::HashMap<(u32, u32, u64), (u64, usize)>;
    static SEEN: std::sync::Mutex<Option<Seen>> = std::sync::Mutex::new(None);
    let (n, bytes) = {
        let mut seen = SEEN.lock().unwrap_or_else(|e| e.into_inner());
        let e = seen.get_or_insert_with(Default::default).entry((protect, kind, flags)).or_default();
        *e = (e.0 + 1, e.1 + size);
        *e
    };
    if n.is_power_of_two() {
        tracing::info!(
            "title memory asked for as protection {protect:#x}, kind {kind:#x}, flags {flags:#x}: {n} times, {} MB, last {at:#x}+{size:#x}",
            bytes >> 20
        );
    }
}

/// `MEMORY_BASIC_INFORMATION` (the console's first 0x30 bytes are the
/// same), then the XMem flags and tag.
#[repr(C)]
pub struct BasicInformation {
    host: MEMORY_BASIC_INFORMATION,
    flags: u64,
    tag_code: u32,
    tag: [u8; 4],
}

// shortcut: every committed page reports graphics memory and no tag, since
// all of it is GPU-reachable here (the title's BVH builder, the
// only caller, wants graphics memory); remember the flags of
// `XMemVirtualAlloc` regions if a title tells CPU-only memory apart.
pub extern "system" fn XMemVirtualQuery(
    process: HANDLE,
    address: *const c_void,
    out: *mut BasicInformation,
) -> BOOL {
    let size = size_of::<MEMORY_BASIC_INFORMATION>();
    // A lazy view is committed memory to the title.
    materialize_for(address as usize, 1, Touch::TitleCall);
    // SAFETY: the title passes room for the whole structure; the host
    // fails on a null one.
    unsafe {
        if VirtualQueryEx(process, address, out.cast(), size) == 0 {
            return 0;
        }
        let info = &mut *out;
        info.flags = if info.host.State == MEM_COMMIT {
            GRAPHICS
        } else {
            0
        };
        info.tag_code = 0;
        info.tag = [0; 4];
    }
    1
}

// `XMemAlloc` attributes: alignment as log2 (5 bits at 24, 4 bytes and up
// from 2), then the memory type, then bit 33: a 32-bit address.
const ALIGNMENT_SHIFT: u64 = 24;
const ALLOC_32BIT: u64 = 1 << 33;
/// Our block header: the block's size and alignment, just below the
/// pointer handed out.
const HEADER: usize = 2 * size_of::<usize>();

fn layout(size: usize, attributes: u64) -> Option<Layout> {
    // An alignment of at least 16 leaves room for the header.
    let align = 1usize << (attributes >> ALIGNMENT_SHIFT & 0x1f).max(4);
    Layout::from_size_align(size.checked_add(align)?, align).ok()
}

type AllocRoutine = extern "system" fn(usize, u64) -> *mut c_void;
type FreeRoutine = extern "system" fn(*mut c_void, u64);

/// The allocation and free routines the title's exe exports as
/// `__XMemAllocationHooks__` (the title does): `XMemAlloc` and
/// `XMemFree` call them, for the title's own calls and its middleware's;
/// the `…Default` exports do not.
fn hooks() -> [usize; 2] {
    static AT: std::sync::OnceLock<usize> = std::sync::OnceLock::new();
    let at = match AT.get() {
        Some(&at) => at,
        // Looked up once the title is mapped, which is before it runs.
        None => match crate::runtime::main_image() {
            Some(base) => *AT.get_or_init(|| {
                use windows_sys::Win32::System::LibraryLoader::GetProcAddress;
                // SAFETY: a mapped image and a NUL-terminated name.
                let at = unsafe {
                    GetProcAddress(base as _, c"__XMemAllocationHooks__".as_ptr().cast())
                }
                .map_or(0, |f| f as usize);
                tracing::info!(found = at != 0, "xmem allocation hooks");
                at
            }),
            None => 0,
        },
    };
    if at == 0 {
        return [0; 2];
    }
    // SAFETY: the export is two routine pointers.
    unsafe { (at as *const [usize; 2]).read() }
}

/// The title's general allocator, for middleware too: its hook if it has
/// one, else [`XMemAllocDefault`].
pub extern "system" fn XMemAlloc(size: usize, attributes: u64) -> *mut c_void {
    match hooks()[0] {
        0 => XMemAllocDefault(size, attributes),
        hook => {
            // SAFETY: the title's own routine of this type.
            let alloc: AllocRoutine = unsafe { std::mem::transmute(hook) };
            alloc(size, attributes)
        }
    }
}

/// See [`XMemAlloc`].
pub extern "system" fn XMemFree(address: *mut c_void, attributes: u64) {
    match hooks()[1] {
        0 => XMemFreeDefault(address, attributes),
        hook => {
            // SAFETY: the title's own routine of this type.
            let free: FreeRoutine = unsafe { std::mem::transmute(hook) };
            free(address, attributes)
        }
    }
}

/// The system allocator behind [`XMemAlloc`].
pub extern "system" fn XMemAllocDefault(size: usize, attributes: u64) -> *mut c_void {
    if attributes & ALLOC_32BIT != 0 {
        return XMemVirtualAlloc(
            std::ptr::null_mut(),
            size,
            MEM_RESERVE | MEM_COMMIT,
            GRAPHICS | ADDRESS_32BIT,
            PAGE_READWRITE,
        );
    }
    let Some(layout) = layout(size, attributes) else {
        return std::ptr::null_mut();
    };
    // shortcut: the host heap's addresses lie above 2^40, unlike the
    // console's; nothing seen builds ray-tracing structures in this memory
    // (the title uses its GPU heap). Sub-allocate from a
    // reservation below 2^40 if one does.
    // SAFETY: the layout has a non-zero size.
    let block = unsafe { alloc(layout) };
    if block.is_null() {
        tracing::warn!(size, "XMemAllocDefault: the host heap is out of memory");
        return block.cast();
    }
    // SAFETY: the block holds the alignment (at least the header) and then
    // `size` bytes.
    unsafe {
        let user = block.add(layout.align());
        user.sub(HEADER)
            .cast::<[usize; 2]>()
            .write([layout.size(), layout.align()]);
        user.cast()
    }
}

/// Frees what [`XMemAllocDefault`] returned, given the same attributes.
pub extern "system" fn XMemFreeDefault(address: *mut c_void, attributes: u64) {
    if address.is_null() {
        return;
    }
    // SAFETY: the address came from `XMemAlloc` with these attributes: a
    // whole reservation, or a header-prefixed block.
    unsafe {
        if attributes & ALLOC_32BIT != 0 {
            VirtualFree(address, 0, MEM_RELEASE);
            return;
        }
        let user = address.cast::<u8>();
        let [size, align] = user.sub(HEADER).cast::<[usize; 2]>().read();
        dealloc(
            user.sub(align),
            Layout::from_size_align_unchecked(size, align),
        );
    }
}

/// A retail console has no tools memory.
pub extern "system" fn XMemIsToolsMemAvailable() -> BOOL {
    0
}

// Physical pages: on the console, 64 KiB frames a title maps into its own
// reservations, at more than one address if it likes. Here each allocation
// is a pagefile-backed section, its pages are 64 KiB slices of it, and a
// mapping is a view of consecutive slices in place of a host placeholder.

const PAGE: usize = 64 << 10;

struct Section {
    handle: HANDLE,
    pages: usize,
    /// A view of the whole section, kept ([`Section::window`]); 0 if the
    /// host gave none.
    window: std::sync::OnceLock<usize>,
    /// A bit per page: committed, as far as [`Section::window`] asked.
    committed: Box<[std::sync::atomic::AtomicU64]>,
}

impl Section {
    /// Where bytes of `n` pages from page `index` on can be written,
    /// whether or not the pages are mapped anywhere, committed.
    ///
    /// Every DirectStorage write mapped a view of its pages, committed it,
    /// faulted each of its 4 KiB pages in and unmapped it again, all of it
    /// under the process's one address-space lock, with 24 workers, the
    /// title's own mapping calls (about 100,000 views of one page) and our
    /// guards asking for the same lock. One view of the section, kept,
    /// costs that once per page.
    /// `VICTORY_SECTION_WINDOW=0`: a view for each write, as before.
    fn window(&self, index: usize, n: usize) -> Option<usize> {
        use std::sync::atomic::Ordering;
        use windows_sys::Win32::System::Memory::{FILE_MAP_WRITE, MapViewOfFile};
        static ON: LazyLock<bool> =
            LazyLock::new(|| std::env::var_os("VICTORY_SECTION_WINDOW").is_none_or(|v| v != "0"));
        if !*ON || index + n > self.pages {
            return None;
        }
        let base = *self.window.get_or_init(|| {
            // SAFETY: the whole of a section we own.
            unsafe { MapViewOfFile(self.handle, FILE_MAP_WRITE, 0, 0, self.pages * PAGE) }.Value as usize
        });
        if base == 0 {
            return None;
        }
        let missing = |page: usize| self.committed[page / 64].load(Ordering::Acquire) >> (page % 64) & 1 == 0;
        let mut page = index;
        while page < index + n {
            if !missing(page) {
                page += 1;
                continue;
            }
            let run = (page..index + n).take_while(|&p| missing(p)).count();
            if run == 0 {
                continue; // another worker committed it meanwhile
            }
            if !commit(base + page * PAGE, run * PAGE) {
                return None;
            }
            for p in page..page + run {
                self.committed[p / 64].fetch_or(1 << (p % 64), Ordering::AcqRel);
            }
            page += run;
        }
        Some(base + index * PAGE)
    }
}

impl Section {
    /// Commits the pages from `index` on that a view at `base` shows, unless
    /// all of them are ([`lean`]): committed for one view is for all.
    fn commit_shown(&self, index: usize, base: usize, len: usize) -> bool {
        use std::sync::atomic::Ordering;
        let pages = index..(index + len / PAGE).min(self.pages);
        let bit = |p: usize| (&self.committed[p / 64], 1 << (p % 64));
        let done = || {
            pages.clone().all(|p| {
                let (word, bit) = bit(p);
                word.load(Ordering::Acquire) & bit != 0
            })
        };
        if lean() && done() {
            return true;
        }
        if !counted(Call::Commit, || commit(base, len)) {
            return false;
        }
        for p in pages {
            let (word, bit) = bit(p);
            word.fetch_or(bit, Ordering::AcqRel);
        }
        true
    }
}

// SAFETY: a section handle may be used from any thread.
unsafe impl Send for Section {}
// SAFETY: as above.
unsafe impl Sync for Section {}

impl Drop for Section {
    fn drop(&mut self) {
        use windows_sys::Win32::System::Memory::UnmapViewOfFile;
        if let Some(&base) = self.window.get()
            && base != 0
        {
            // SAFETY: our view; whoever writes through it holds the section.
            unsafe {
                UnmapViewOfFile(MEMORY_MAPPED_VIEW_ADDRESS {
                    Value: base as *mut c_void,
                })
            };
        }
        victory_gpu::title_memory_section_gone(self.handle as usize);
        // SAFETY: our handle; views keep the section alive on their own.
        unsafe { CloseHandle(self.handle) };
    }
}

/// Where a page lives, or what a view starts with: a section and a page
/// index in it.
#[derive(Clone)]
struct Slice {
    section: Arc<Section>,
    index: usize,
}

#[derive(Default)]
struct Physical {
    /// Mapped views by address: their length and what they show.
    views: BTreeMap<usize, (usize, Slice)>,
    /// Placeholders that are some view's own, left by its unmapping: address
    /// and length. The title may have joined one with others since.
    holes: HashMap<usize, usize>,
}

impl Physical {
    /// What the page at `at` shows.
    fn slice_at(&self, at: usize) -> Option<Slice> {
        self.views
            .range(..=at)
            .next_back()
            .filter(|(base, (size, _))| at < *base + size)
            .map(|(base, (_, s))| Slice {
                index: s.index + (at - base) / PAGE,
                section: s.section.clone(),
            })
    }
}

/// The title's pages by number.
struct Pages {
    next_page: usize,
    pages: HashMap<usize, Slice>,
}

/// Where the title sees its pages: [`Physical::views`] the other way.
/// Locked apart from them, and only for a moment ([`PAGES`]).
#[derive(Default)]
struct Shown {
    /// The addresses that show a page, by the page's section and index.
    /// Views of more than [`SHORT`] pages are in `long`.
    pages: HashMap<(usize, usize), Vec<usize>>,
    /// Address, bytes, section, first page.
    long: Vec<(usize, usize, usize, usize)>,
}

/// Pages of a view noted page by page in [`Shown::pages`].
const SHORT: usize = 64;

/// Taken after [`PHYSICAL`] where both are.
static SHOWN: LazyLock<RwLock<Shown>> = LazyLock::new(Default::default);

fn shown_mut() -> RwLockWriteGuard<'static, Shown> {
    SHOWN.write().unwrap_or_else(|e| e.into_inner())
}

impl Shown {
    fn note(&mut self, base: usize, len: usize, slice: &Slice) {
        let section = Arc::as_ptr(&slice.section) as usize;
        if len / PAGE > SHORT {
            self.long.push((base, len, section, slice.index));
            return;
        }
        for k in 0..len / PAGE {
            self.pages.entry((section, slice.index + k)).or_default().push(base + k * PAGE);
        }
    }

    fn forget(&mut self, base: usize, len: usize, slice: &Slice) {
        if len / PAGE > SHORT {
            self.long.retain(|view| view.0 != base);
            return;
        }
        let section = Arc::as_ptr(&slice.section) as usize;
        for k in 0..len / PAGE {
            let key = (section, slice.index + k);
            if let Some(at) = self.pages.get_mut(&key) {
                at.retain(|&at| at != base + k * PAGE);
                if at.is_empty() {
                    self.pages.remove(&key);
                }
            }
        }
    }

    /// Where the title sees the page at `slice`: addresses and bytes.
    fn at(&self, slice: &Slice) -> Vec<(usize, usize)> {
        let section = Arc::as_ptr(&slice.section) as usize;
        let mut out: Vec<(usize, usize)> =
            self.pages.get(&(section, slice.index)).into_iter().flatten().map(|&at| (at, PAGE)).collect();
        for &(base, len, of, index) in &self.long {
            if of == section && (index..index + len / PAGE).contains(&slice.index) {
                out.push((base + (slice.index - index) * PAGE, PAGE));
            }
        }
        out
    }
}

/// See [`pages_written`].
pub(crate) fn stream_notice() -> bool {
    static ON: LazyLock<bool> =
        LazyLock::new(|| std::env::var_os("VICTORY_STREAM_NOTICE").is_none_or(|v| v != "0"));
    *ON
}

/// The views, changed by the title's mapping calls; held for as long as
/// those take (the host maps, commits and unmaps under it).
static PHYSICAL: LazyLock<Mutex<Physical>> = LazyLock::new(Default::default);

fn physical() -> Held {
    let guard = PHYSICAL.lock().unwrap_or_else(|e| e.into_inner());
    HOLDING.set(true);
    Held(guard)
}

thread_local! {
    /// This thread holds [`PHYSICAL`]: a fault of its own in lazily mapped
    /// title memory cannot be made real here ([`materialize`]).
    static HOLDING: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
}

/// [`PHYSICAL`] held, and [`HOLDING`] said while it is.
struct Held(MutexGuard<'static, Physical>);

impl std::ops::Deref for Held {
    type Target = Physical;
    fn deref(&self) -> &Physical {
        &self.0
    }
}

impl std::ops::DerefMut for Held {
    fn deref_mut(&mut self) -> &mut Physical {
        &mut self.0
    }
}

impl Drop for Held {
    fn drop(&mut self) {
        HOLDING.set(false);
    }
}

/// The title's pages. Apart from the views: DirectStorage looks pages up at
/// every request, from 24 workers, and used to wait there for the title's
/// mapping calls (12,000 waits of 1 to 170 ms in a load of 90 s). Written
/// only where the title allocates or frees pages. Taken after [`PHYSICAL`]
/// where both are.
static PAGES: LazyLock<RwLock<Pages>> = LazyLock::new(|| {
    RwLock::new(Pages {
        // Page numbers are opaque to titles; 0 stays unused.
        next_page: 0x10_0000,
        pages: HashMap::new(),
    })
});

fn page_table() -> RwLockReadGuard<'static, Pages> {
    PAGES.read().unwrap_or_else(|e| e.into_inner())
}

fn page_table_mut() -> RwLockWriteGuard<'static, Pages> {
    PAGES.write().unwrap_or_else(|e| e.into_inner())
}

/// `count` is in and out (pages wanted, pages given); all or nothing here.
pub extern "system" fn XMemAllocatePhysicalPages(
    flags: u64,
    count: *mut usize,
    pages: *mut usize,
) -> BOOL {
    if count.is_null() || pages.is_null() {
        return 0;
    }
    // SAFETY: checked non-null.
    let n = unsafe { *count };
    let Some(size) = n.checked_mul(PAGE).filter(|&s| s > 0) else {
        return 0;
    };
    // A pagefile-backed section of `size` bytes, its pages committed when
    // first mapped or written (`commit`): the title asks for 6.1
    // GiB at once, which a busy host often cannot commit (error 1450).
    // SAFETY: plain section creation.
    let handle = unsafe {
        CreateFileMappingW(
            INVALID_HANDLE_VALUE,
            std::ptr::null(),
            // Under Wine a committed section is a sparse file, free until
            // touched, and committing a reserved one page by page costs a
            // wineserver request each that scans every range committed so
            // far: commit it whole there.
            PAGE_READWRITE | if on_wine() { SEC_COMMIT } else { SEC_RESERVE },
            (size as u64 >> 32) as u32,
            size as u32,
            std::ptr::null(),
        )
    };
    if handle.is_null() {
        let error = std::io::Error::last_os_error();
        tracing::warn!(n, %error, "XMemAllocatePhysicalPages failed");
        // SAFETY: checked non-null.
        unsafe { count.write(0) };
        return 0;
    }
    tracing::debug!(
        n,
        flags = format_args!("{flags:#x}"),
        "XMemAllocatePhysicalPages"
    );
    // For the GPU side's in-place census: only a committed section can be
    // opened as a host heap.
    victory_gpu::title_memory_section(handle as usize, size as u64, on_wine());
    let section = Arc::new(Section {
        handle,
        pages: n,
        window: std::sync::OnceLock::new(),
        committed: (0..n.div_ceil(64)).map(|_| std::sync::atomic::AtomicU64::new(0)).collect(),
    });
    let mut table = page_table_mut();
    let first = table.next_page;
    table.next_page += n * FRAMES;
    for index in 0..n {
        let slice = Slice {
            section: section.clone(),
            index,
        };
        table.pages.insert(first + index * FRAMES, slice);
    }
    // Title memory is touched without our locks: a fault there may wait for
    // a mapping call, which takes them.
    drop(table);
    for index in 0..n {
        // SAFETY: the title passes room for `n` page numbers.
        unsafe { pages.add(index).write(first + index * FRAMES) };
    }
    1
}

/// Page numbers count 4 KiB frames, so a 64 KiB page's is a multiple of
/// 16: the title keeps them as 21-bit `number >> 4` and rebuilds
/// them with `<< 4` (128 GiB of pages at most).
const FRAMES: usize = PAGE >> 12;

/// Pages still mapped stay readable through their views until unmapped.
pub extern "system" fn XMemFreePhysicalPages(n: usize, pages: *const usize) -> BOOL {
    if pages.is_null() {
        return 0;
    }
    // SAFETY: the title passes `n` page numbers.
    let numbers = unsafe { std::slice::from_raw_parts(pages, n) }.to_vec();
    let mut table = page_table_mut();
    // Dropped without the lock: the last page of a section unmaps its window.
    let gone: Vec<Slice> = numbers.iter().filter_map(|number| table.pages.remove(number)).collect();
    drop(table);
    drop(gone);
    1
}

/// A view of our own on consecutive slices of one section, committed and
/// writable, unmapped when dropped.
struct View {
    at: MEMORY_MAPPED_VIEW_ADDRESS,
    len: usize,
}

impl View {
    /// Maps `n` slices from `slice` on.
    fn map(slice: &Slice, n: usize) -> Option<View> {
        use windows_sys::Win32::System::Memory::{FILE_MAP_WRITE, MapViewOfFile};
        let (offset, len) = ((slice.index * PAGE) as u64, n * PAGE);
        // SAFETY: slices of a section we own; the view is ours until dropped.
        let at = unsafe {
            MapViewOfFile(
                slice.section.handle,
                FILE_MAP_WRITE,
                (offset >> 32) as u32,
                offset as u32,
                len,
            )
        };
        if at.Value.is_null() {
            tracing::warn!(error = %std::io::Error::last_os_error(), n, "physical pages not mapped for a write");
            return None;
        }
        let view = View { at, len };
        if !commit(at.Value as usize, len) {
            tracing::warn!(error = %std::io::Error::last_os_error(), n, "physical pages not committed for a write");
            return None;
        }
        Some(view)
    }

    fn bytes(&mut self) -> &mut [u8] {
        // SAFETY: the view holds `len` committed read-write bytes, ours
        // alone while `self` lives (other views of the slices only alias
        // them, as the console's do).
        unsafe { std::slice::from_raw_parts_mut(self.at.Value.cast(), self.len) }
    }
}

impl Drop for View {
    fn drop(&mut self) {
        use windows_sys::Win32::System::Memory::UnmapViewOfFile;
        // SAFETY: our view.
        unsafe { UnmapViewOfFile(self.at) };
    }
}

/// The pages behind bytes `[offset, offset + len)` of `pages` (64 KiB
/// each), as runs of consecutive slices of one section: each run's first
/// slice and its length in pages. One look at the page table. `None`
/// if a page is unknown or `pages` ends early.
fn runs(pages: &[usize], offset: usize, len: usize) -> Option<Vec<(Slice, usize)>> {
    let end = offset.checked_add(len)?;
    let pages = pages.get(offset / PAGE..end.div_ceil(PAGE))?;
    let table = page_table();
    let mut runs: Vec<(Slice, usize)> = Vec::new();
    for page in pages {
        let Some(slice) = table.pages.get(page) else {
            tracing::warn!(page, offset, len, "a physical page the title does not own (any more)");
            return None;
        };
        match runs.last_mut() {
            Some((first, n))
                if Arc::ptr_eq(&first.section, &slice.section)
                    && slice.index == first.index + *n =>
            {
                *n += 1;
            }
            _ => runs.push((slice.clone(), 1)),
        }
    }
    Some(runs)
}

/// Whether the title owns every page under bytes `[offset, offset + len)`.
pub(crate) fn pages_known(pages: &[usize], offset: usize, len: usize) -> bool {
    let table = page_table();
    pages
        .get(offset / PAGE..(offset + len).div_ceil(PAGE))
        .is_some_and(|pages| pages.iter().all(|page| table.pages.contains_key(page)))
}

/// Where the title sees the pages under bytes `[offset, offset + len)` now,
/// in order (for the streaming trace: whether that changed while a request
/// wrote them).
pub(crate) fn pages_shown(pages: &[usize], offset: usize, len: usize) -> Vec<(usize, usize)> {
    let numbers = pages.get(offset / PAGE..(offset + len).div_ceil(PAGE)).unwrap_or_default();
    let slices: Vec<Slice> = {
        let table = page_table();
        numbers.iter().filter_map(|n| table.pages.get(n)).cloned().collect()
    };
    let shown = SHOWN.read().unwrap_or_else(|e| e.into_inner());
    let mut at: Vec<(usize, usize)> = slices.iter().flat_map(|slice| shown.at(slice)).collect();
    at.sort_unstable();
    at
}

/// Copies `data` into physical pages, from `offset` bytes into the first,
/// whether or not they are mapped anywhere (DirectStorage destinations).
/// One view per run of consecutive pages, not one per page: each view
/// costs a map, a commit and an unmap (which flushes every core's TLB).
/// False if a page is unknown or the host fails.
pub(crate) fn write_physical(pages: &[usize], offset: usize, data: &[u8]) -> bool {
    let Some(runs) = runs(pages, offset, data.len()) else {
        return false;
    };
    let (mut within, mut done) = (offset % PAGE, 0);
    for (slice, n) in &runs {
        let k = (n * PAGE - within).min(data.len() - done);
        if let Some(at) = slice.section.window(slice.index, *n) {
            // SAFETY: committed bytes of the section's view, which `runs`
            // holds; the title's other uses of them race as on the console.
            unsafe { std::ptr::copy_nonoverlapping(data[done..].as_ptr(), (at + within) as *mut u8, k) };
        } else {
            let Some(mut view) = View::map(slice, *n) else {
                return false;
            };
            view.bytes()[within..within + k].copy_from_slice(&data[done..done + k]);
        }
        (within, done) = (0, done + k);
    }
    true
}

/// Bytes `[offset, offset + len)` of physical pages, writable in place
/// until dropped: DirectStorage decodes into it instead of a buffer it
/// would then copy.
pub(crate) struct PageWindow {
    view: Window,
    within: usize,
    len: usize,
}

enum Window {
    /// In the section's own view, which the section holds.
    Kept(usize, #[expect(dead_code, reason = "held for the view")] Arc<Section>),
    Own(View),
}

impl PageWindow {
    pub(crate) fn bytes(&mut self) -> &mut [u8] {
        let (within, len) = (self.within, self.len);
        match &mut self.view {
            // SAFETY: committed bytes of the section's view, ours alone as
            // far as the runtime goes (other views alias them, as the
            // console's do).
            Window::Kept(at, _) => unsafe { std::slice::from_raw_parts_mut((*at + within) as *mut u8, len) },
            Window::Own(view) => &mut view.bytes()[within..within + len],
        }
    }
}

/// A window on bytes `[offset, offset + len)` of `pages` when they are
/// consecutive pages of one allocation (how titles usually hand them out);
/// `None` otherwise (pages of several allocations, out of order, or
/// unknown, or a host failure), which `write_physical` then handles or
/// reports.
pub(crate) fn page_window(pages: &[usize], offset: usize, len: usize) -> Option<PageWindow> {
    let runs = runs(pages, offset, len)?;
    let [(slice, n)] = runs.as_slice() else {
        return None;
    };
    let view = match slice.section.window(slice.index, *n) {
        Some(at) => Window::Kept(at, slice.section.clone()),
        None => Window::Own(View::map(slice, *n)?),
    };
    Some(PageWindow {
        view,
        within: offset % PAGE,
        len,
    })
}

/// The title addresses that show bytes `[offset, offset + len)` of `pages`
/// now, byte for byte, as runs (address, bytes) in address order: a write
/// to the pages through a view of our own ([`page_window`],
/// [`write_physical`]) lands there too, and nothing that watches those
/// addresses sees it. Empty if no view shows them. Byte for byte, not by
/// whole pages: the title packs several small textures into one page and
/// fills each with a request of its own.
pub(crate) fn shown_at(pages: &[usize], offset: usize, len: usize) -> Vec<(usize, usize)> {
    let Some(end) = offset.checked_add(len) else {
        return Vec::new();
    };
    let first = offset / PAGE;
    let Some(touched) = pages.get(first..end.div_ceil(PAGE)) else {
        return Vec::new();
    };
    let slices: Vec<Option<Slice>> = {
        let table = page_table();
        touched.iter().map(|page| table.pages.get(page).cloned()).collect()
    };
    let mut pieces: Vec<(usize, usize)> = Vec::new();
    {
        let shown = SHOWN.read().unwrap_or_else(|e| e.into_inner());
        for (i, slice) in slices.iter().enumerate() {
            let Some(slice) = slice else { continue };
            // The bytes of this page that the write covers.
            let lo = if i == 0 { offset % PAGE } else { 0 };
            let hi = (end - (first + i) * PAGE).min(PAGE);
            pieces.extend(shown.at(slice).into_iter().map(|(at, _)| (at + lo, hi - lo)));
        }
    }
    pieces.sort_unstable();
    let mut runs: Vec<(usize, usize)> = Vec::new();
    for (at, bytes) in pieces {
        match runs.last_mut() {
            Some((start, n)) if *start + *n == at => *n += bytes,
            _ => runs.push((at, bytes)),
        }
    }
    runs
}

/// DirectStorage has put bytes `[offset, offset + len)` of `pages` into
/// memory, through a view of our own: the GPU side is told where the title
/// sees them, so that what it copied there before they arrived (a texture
/// uploaded when its view was written holds whatever the pages held then)
/// is copied again. Call when the bytes are there.
/// `VICTORY_STREAM_NOTICE=0`: not told; what is then done is
/// `VICTORY_PAGE_WRITES`' to say (`victory_gpu::title_memory_written`).
pub(crate) fn pages_written(pages: &[usize], offset: usize, len: usize) {
    if len == 0 {
        return;
    }
    for (at, bytes) in shown_at(pages, offset, len) {
        if stream_notice() {
            victory_gpu::kernel_will_write(at, bytes);
        } else {
            victory_gpu::title_memory_written(at, bytes, true);
        }
    }
}

/// What the title's mapping calls cost since the last asking, for the
/// streaming log, counted only while that log is on: calls, pages,
/// milliseconds in all, the longest one's and waiting for the lock; the same
/// of the GPU's page-mapping copies ([`map_aliases`], or [`map_alias`]
/// called alone; calls and milliseconds); by system call (unmap, split, map,
/// commit) how many and their milliseconds; and of the pages those copies
/// map, how many, and how many of them show the section page after the one
/// the page before them shows (what one view could show with it:
/// [`alias_runs`]).
///
/// (A copy of mappings was counted twice, once as the batch and once per
/// range, when one thread maps: the streaming log's copies' calls and
/// milliseconds were up to twice what they were.)
static MAPPING: [std::sync::atomic::AtomicU64; 17] = [const { std::sync::atomic::AtomicU64::new(0) }; 17];

/// The streaming log's line of mapping costs ([`MAPPING`]), then, with
/// `VICTORY_LAZY_VIEWS=1` or `VICTORY_SOFT_VIEWS`, of the views kept in the
/// books alone, since the last line: noted, let go untouched, made real;
/// noted by the title's mapping calls and by page-mapping copies; made real
/// by a fault of the title's code, by a fault of other code, asked for by
/// the GPU side, by a call of the title's; reads of the GPU side served
/// from the pages and their KiB ([`Soft`]); and how many such views there
/// are now.
pub(crate) fn map_costs() -> Option<String> {
    static BEFORE: Mutex<[u64; SOFT_FIELDS]> = Mutex::new([0; SOFT_FIELDS]);
    let mapping: [u64; 17] = std::array::from_fn(|i| MAPPING[i].swap(0, Ordering::Relaxed));
    let mut soft = soft_since(&mut BEFORE.lock().unwrap_or_else(|e| e.into_inner())).to_vec();
    soft[Soft::ReadBytes as usize] >>= 10;
    soft.push(LAZY_N.load(Ordering::Relaxed) as u64);
    let books = lazy_views() || soft_views() != 0;
    let n: Vec<u64> = mapping.iter().chain(if books { &soft[..] } else { &[] }).copied().collect();
    let time = |i: usize| matches!(i, 2 | 3 | 4 | 6 | 8 | 10 | 12 | 14);
    (n[0] + n[5] > 0).then(|| {
        let all: Vec<String> = n
            .iter()
            .enumerate()
            .map(|(i, &n)| if time(i) { n / 1_000_000 } else { n })
            .map(|n| n.to_string())
            .collect();
        all.join("\t")
    })
}

/// The system calls that change a mapping, as [`MAPPING`] counts them.
#[derive(Clone, Copy)]
enum Call {
    Unmap = 7,
    Split = 9,
    Map = 11,
    Commit = 13,
}

/// Runs `f`, a system call, and counts it while the streaming log is on.
fn counted<T>(call: Call, f: impl FnOnce() -> T) -> T {
    if !super::dstorage::stream_log::on() {
        return f();
    }
    let started = std::time::Instant::now();
    let done = f();
    MAPPING[call as usize].fetch_add(1, Ordering::Relaxed);
    MAPPING[call as usize + 1].fetch_add(started.elapsed().as_nanos() as u64, Ordering::Relaxed);
    done
}

/// Counts a mapping call when dropped.
struct Costed {
    started: std::time::Instant,
    /// `None`: a copy of mappings.
    pages: Option<usize>,
    waited: u64,
}

impl Costed {
    fn begin(pages: Option<usize>) -> Option<Costed> {
        super::dstorage::stream_log::on().then(|| Costed { started: std::time::Instant::now(), pages, waited: 0 })
    }
}

impl Drop for Costed {
    fn drop(&mut self) {
        let ns = self.started.elapsed().as_nanos() as u64;
        let Some(pages) = self.pages else {
            MAPPING[5].fetch_add(1, Ordering::Relaxed);
            MAPPING[6].fetch_add(ns, Ordering::Relaxed);
            return;
        };
        for (i, n) in [1, pages as u64, ns].into_iter().enumerate() {
            MAPPING[i].fetch_add(n, Ordering::Relaxed);
        }
        MAPPING[3].fetch_max(ns, Ordering::Relaxed);
        MAPPING[4].fetch_add(self.waited, Ordering::Relaxed);
    }
}

/// Whether a mapping change asks the host only for what it needs: no split
/// of a placeholder that is already the view's own, no commit of section
/// pages that are committed (`VICTORY_MAP_LEAN=0`: both every time, as
/// before).
///
/// All of the title's streaming goes through one thread, which maps the
/// pages of a batch and then submits it. Each call waits for the process's
/// one address-space lock, behind the guards' and the driver's: 200 to 400
/// us a page in the world against 10 in a menu, 2 to 4 s of every 5 s of
/// that thread (runs stream-1 and -2; all six stacks taken of it in the
/// opening were in these calls), so that models came as fast as their pages
/// could be mapped. A page took up to four calls (unmap, split, map,
/// commit), twice: the title maps a page into its pool and then has the GPU
/// map it into its tiled heap.
fn lean() -> bool {
    static ON: LazyLock<bool> = LazyLock::new(|| std::env::var_os("VICTORY_MAP_LEAN").is_none_or(|v| v != "0"));
    *ON
}

/// The title's streaming thread runs below normal priority, as do sixteen
/// workers of ours when pipelines are made; on the console nothing else
/// wants its core. Called where that thread maps and submits: lifts a
/// thread that is below normal to above it (`VICTORY_STREAM_PRIORITY=0`:
/// left as the title set it).
pub(crate) fn lift_thread() {
    use windows_sys::Win32::System::Threading::{
        GetCurrentThread, GetThreadPriority, SetThreadPriority, THREAD_PRIORITY_ABOVE_NORMAL,
    };
    static ON: LazyLock<bool> =
        LazyLock::new(|| std::env::var_os("VICTORY_STREAM_PRIORITY").is_none_or(|v| v != "0"));
    if !*ON {
        return;
    }
    // SAFETY: plain calls on this thread.
    unsafe {
        let thread = GetCurrentThread();
        if matches!(GetThreadPriority(thread), -2..0) {
            SetThreadPriority(thread, THREAD_PRIORITY_ABOVE_NORMAL);
        }
    }
}

/// Renderer port 1 (`VICTORY_PORT_CONSTANTS=1`; the GPU side's half is
/// `victory_gpu`'s `port`): read here for xmem's part, [`arrange`].
fn port_on() -> bool {
    static ON: LazyLock<bool> = LazyLock::new(|| std::env::var("VICTORY_PORT_CONSTANTS").is_ok_and(|v| v.trim() == "1"));
    *ON
}

/// The title's reservations of 64 KiB pages for 32-bit graphics memory:
/// base and bytes (one, of 185 MB, in Grand Theft Auto VI).
static LOW_RESERVATIONS: Mutex<Vec<(usize, usize)>> = Mutex::new(Vec::new());

/// Pages given another place in their section so far by [`arrange`], and
/// the times it found a page that was not fresh.
static ARRANGED: [AtomicU64; 2] = [const { AtomicU64::new(0) }; 2];

/// Before `pages` are mapped at `base`: if `base` lies in a 32-bit graphics
/// reservation ([`LOW_RESERVATIONS`]) whose pages are all one section of
/// the same size, the page numbers are given the slices of that section in
/// the reservation's address order (each page at its offset in the
/// reservation), so that the reservation becomes one stretch of the section
/// and the GPU side can open it as one heap.
///
/// Grand Theft Auto VI takes all the pages of its 185 MB heap in one call
/// and maps its five pieces in another order than their addresses (run
/// port1-1: "Scattered"). Only fresh slices are exchanged: never mapped,
/// never written (no commit bit), so every page still reads as zeros and
/// which slice a number names is not observable by the title.
fn arrange(base: usize, pages: &[usize]) {
    let Some((first, bytes)) = LOW_RESERVATIONS
        .lock()
        .unwrap_or_else(|e| e.into_inner())
        .iter()
        .copied()
        .find(|&(at, len)| at <= base && base + pages.len() * PAGE <= at + len)
    else {
        return;
    };
    let mut table = page_table_mut();
    let Some(section) = pages.first().and_then(|p| table.pages.get(p)).map(|s| s.section.clone()) else {
        return;
    };
    if section.pages * PAGE < bytes
        || !pages.iter().all(|p| table.pages.get(p).is_some_and(|s| Arc::ptr_eq(&s.section, &section)))
    {
        static SAID: AtomicU64 = AtomicU64::new(0);
        if SAID.fetch_add(1, Ordering::Relaxed) < 4 {
            tracing::warn!(
                at = format_args!("{base:#x}"),
                pages = pages.len(),
                section_pages = section.pages,
                reservation = bytes / PAGE,
                "renderer port 1: pages mapped into the 32-bit heap are not of one section as big as it: left where they are"
            );
        }
        return;
    }
    let fresh = |index: usize| section.committed[index / 64].load(Ordering::Acquire) >> (index % 64) & 1 == 0;
    // Which number has which slice of the section.
    let mut owner: HashMap<usize, usize> = table
        .pages
        .iter()
        .filter(|(_, s)| Arc::ptr_eq(&s.section, &section))
        .map(|(&number, s)| (s.index, number))
        .collect();
    let mut moved = 0u64;
    for (i, number) in pages.iter().enumerate() {
        let want = (base - first) / PAGE + i;
        let Some(have) = table.pages.get(number).map(|s| s.index) else {
            continue;
        };
        if have == want {
            continue;
        }
        if !fresh(have) || !fresh(want) {
            ARRANGED[1].fetch_add(1, Ordering::Relaxed);
            continue;
        }
        if let Some(other) = owner.get(&want).copied()
            && let Some(slice) = table.pages.get_mut(&other)
        {
            slice.index = have;
            owner.insert(have, other);
        }
        if let Some(slice) = table.pages.get_mut(number) {
            slice.index = want;
        }
        owner.insert(want, *number);
        moved += 1;
    }
    if moved > 0 {
        let all = ARRANGED[0].fetch_add(moved, Ordering::Relaxed) + moved;
        tracing::info!(
            at = format_args!("{base:#x}"),
            pages = pages.len(),
            moved,
            all,
            not_fresh = ARRANGED[1].load(Ordering::Relaxed),
            "renderer port 1: the title's 32-bit graphics pages given their section's slices in address order"
        );
    }
}

/// Maps `n` pages at `address`, in place of what is mapped there; null
/// `pages` unmaps. Returns `address`, or null if a page or the host fails.
pub extern "system" fn XMemMapPhysicalPages(
    address: *mut c_void,
    n: usize,
    pages: *const usize,
) -> *mut c_void {
    map_pages(address, n, pages, lazy_views() || soft_views() & SOFT_POOL != 0)
}

/// [`XMemMapPhysicalPages`]; `lazy`: views are mapped on the host when first
/// touched ([`lazy_views`], [`soft_views`]).
fn map_pages(address: *mut c_void, n: usize, pages: *const usize, lazy: bool) -> *mut c_void {
    let base = address as usize;
    // Read before any lock is taken: a fault in title memory may wait for
    // the mapping call that holds them.
    // SAFETY: the title passes `n` page numbers, or null.
    let pages = (!pages.is_null()).then(|| unsafe { std::slice::from_raw_parts(pages, n) }.to_vec());
    if port_on()
        && let Some(pages) = &pages
    {
        arrange(base, pages);
    }
    let mut costed = Costed::begin(Some(n));
    let _called = victory_gpu::timeline::span("the title's XMemMapPhysicalPages");
    let _busy = Busy::begin();
    // Until the pages are mapped again: `unmap` takes whole views away and
    // maps what stays of them again, and a mapped view is a reservation
    // until it is committed. A read of title memory in place must not fall
    // into that gap (`victory_gpu::title_memory_remapping`). Taken before
    // the views, as everywhere: a reader that holds it may fault into a
    // lazy view and need the views to make it real ([`materialize`]).
    let _changing = victory_gpu::title_memory_remapping();
    let mut physical = physical();
    if let Some(costed) = &mut costed {
        costed.waited = costed.started.elapsed().as_nanos() as u64;
    }
    unmap(&mut physical, base, n * PAGE);
    let Some(pages) = pages else {
        return address;
    };
    let slices: Vec<Option<Slice>> = {
        let table = page_table();
        pages.iter().map(|page| table.pages.get(page).cloned()).collect()
    };
    let mut i = 0;
    while i < n {
        let Some(first) = slices[i].clone() else {
            tracing::warn!(page = pages[i], "XMemMapPhysicalPages: unknown page");
            return std::ptr::null_mut();
        };
        // One view per run of consecutive slices of one section.
        let run = 1 + slices[i + 1..]
            .iter()
            .zip(1..)
            .take_while(|&(slice, k)| {
                slice.as_ref().is_some_and(|s| {
                    Arc::ptr_eq(&s.section, &first.section) && s.index == first.index + k
                })
            })
            .count();
        if !place(&mut physical, base + i * PAGE, run * PAGE, first, lazy.then_some(Soft::NotedPool)) {
            return std::ptr::null_mut();
        }
        i += run;
    }
    address
}

/// One page at each address; null `pages`, or a page number 0, unmaps
/// (the title passes 0 for addresses to clear).
pub extern "system" fn XMemMapPhysicalPagesScatter(
    addresses: *const *mut c_void,
    n: usize,
    pages: *const usize,
) -> BOOL {
    if addresses.is_null() {
        return 0;
    }
    lift_thread();
    if side_by_side() > 1 && n > 1 {
        // Read before any lock is taken, as in `XMemMapPhysicalPages`.
        let wanted: Vec<(usize, usize)> = (0..n)
            // SAFETY: the title passes `n` addresses and, unless null, `n` pages.
            .map(|i| unsafe { (*addresses.add(i) as usize, if pages.is_null() { 0 } else { *pages.add(i) }) })
            .collect();
        if wanted.iter().all(|w| w.0 % PAGE == 0) {
            return scatter(&wanted).into();
        }
    }
    for i in 0..n {
        // SAFETY: the title passes `n` addresses and, unless null, `n` pages.
        let (address, page) = unsafe {
            (
                *addresses.add(i),
                if pages.is_null() || *pages.add(i) == 0 {
                    std::ptr::null()
                } else {
                    pages.add(i)
                },
            )
        };
        if XMemMapPhysicalPages(address, 1, page).is_null() {
            return 0;
        }
    }
    1
}

/// Maps the physical pages shown at `[from, from + len)` at `to` as well,
/// in place of what `to` shows; `from` 0 unmaps. The GPU's page-mapping
/// copies (`victory_gpu`, queue `CopyPageMappingsBatchX`):
/// the title maps pages into a pool view, then has the GPU map them into its tiled
/// heap. Page by page; false if a source page is not mapped physical memory.
pub fn map_alias(to: u64, from: u64, len: u64) -> bool {
    let _costed = Costed::begin(None);
    alias(to, from, len)
}

/// [`map_alias`], not counted as a call of its own.
fn alias(to: u64, from: u64, len: u64) -> bool {
    alias_as(to, from, len, alias_runs(), soft_views() & SOFT_COPIES != 0)
}

/// [`alias`]; `runs`: a view per run of consecutive section pages
/// ([`alias_runs`]), else a view per page; `lazy`: the views are kept in the
/// books alone ([`soft_views`]), a page each.
fn alias_as(to: u64, from: u64, len: u64, runs_in_one: bool, lazy: bool) -> bool {
    let (to, from, len) = (to as usize, from as usize, len as usize);
    let lazy = lazy.then_some(Soft::NotedCopies);
    let _busy = Busy::begin();
    // As in `XMemMapPhysicalPages`: no read in place meets the gap (taken
    // before the views, as there).
    let _changing = victory_gpu::title_memory_remapping();
    let mut physical = physical();
    unmap(&mut physical, to, len);
    if from == 0 {
        return true;
    }
    // A range mapped onto itself (shifted) is looked up page by page as it
    // changes, as before.
    if to < from + len && from < to + len {
        for k in (0..len).step_by(PAGE) {
            let Some(slice) = physical.slice_at(from + k) else {
                return false;
            };
            if !place(&mut physical, to + k, PAGE, slice, lazy) {
                return false;
            }
        }
        return true;
    }
    // The pages to show, up to the first that is not mapped physical
    // memory (those before it are mapped all the same, as before).
    let mut slices = Vec::with_capacity(len / PAGE);
    let mut found = true;
    for k in (0..len).step_by(PAGE) {
        match physical.slice_at(from + k) {
            Some(slice) => slices.push(slice),
            None => {
                found = false;
                break;
            }
        }
    }
    let runs = runs_of(&slices);
    if super::dstorage::stream_log::on() {
        MAPPING[15].fetch_add(slices.len() as u64, Ordering::Relaxed);
        MAPPING[16].fetch_add((slices.len() - runs.len()) as u64, Ordering::Relaxed);
    }
    if runs_in_one && lazy.is_none() {
        // One view per run of consecutive section pages, where its
        // addresses are one placeholder or can be joined into one; else a
        // view a page, as before.
        let mut k = 0;
        for run in runs {
            let base = to + k * PAGE;
            let len = run * PAGE;
            let one = run > 1
                && if one_placeholder(&mut physical, base, len) {
                    if !map(&mut physical, base, len, slices[k].clone()) {
                        return false;
                    }
                    true
                } else {
                    // Memory no view of ours left holes in: mostly part of
                    // one placeholder the title reserved, which is cut there
                    // (else nothing is changed, and it goes page by page).
                    (k..k + run).all(|page| !physical.holes.contains_key(&(to + page * PAGE)))
                        && map_as(&mut physical, base, len, slices[k].clone(), true)
                };
            if !one {
                for page in k..k + run {
                    if !map(&mut physical, to + page * PAGE, PAGE, slices[page].clone()) {
                        return false;
                    }
                }
            }
            k += run;
        }
        return found;
    }
    for (k, slice) in slices.into_iter().enumerate() {
        if !place(&mut physical, to + k * PAGE, PAGE, slice, lazy) {
            return false;
        }
    }
    found
}

/// Whether `[base, base + len)`, all placeholders after an unmapping, is
/// one placeholder of exactly that length now, so that a view of it all can
/// be mapped there: one already (the hole a view of that length left), or
/// several such holes side by side that cover it exactly, joined into one
/// here (one system call, counted as a split). Anything else (memory never
/// mapped, holes not known, a hole reaching past it) says no: the caller
/// maps page by page, as before.
fn one_placeholder(physical: &mut Physical, base: usize, len: usize) -> bool {
    // (`VirtualFree`'s flag to join placeholders; not in windows-sys.)
    const MEM_COALESCE_PLACEHOLDERS: u32 = 0x1;
    if physical.holes.get(&base) == Some(&len) {
        return true;
    }
    let mut parts = Vec::new();
    let mut at = base;
    while at < base + len {
        match physical.holes.get(&at) {
            Some(&part) if part > 0 && at + part <= base + len => {
                parts.push(at);
                at += part;
            }
            _ => return false,
        }
    }
    if parts.len() < 2 {
        return false;
    }
    // SAFETY: acts only on placeholders, which our views left there.
    let joined = counted(Call::Split, || unsafe {
        VirtualFree(base as *mut c_void, len, MEM_RELEASE | MEM_COALESCE_PLACEHOLDERS)
    }) != 0;
    if joined {
        for part in parts {
            physical.holes.remove(&part);
        }
        physical.holes.insert(base, len);
    }
    joined
}

/// The lengths of the runs of `slices` that are consecutive pages of one
/// section, in order.
fn runs_of(slices: &[Slice]) -> Vec<usize> {
    let mut runs: Vec<usize> = Vec::new();
    for (k, slice) in slices.iter().enumerate() {
        let continues = k > 0 && {
            let before = &slices[k - 1];
            Arc::ptr_eq(&before.section, &slice.section) && before.index + 1 == slice.index
        };
        match runs.last_mut() {
            Some(run) if continues => *run += 1,
            _ => runs.push(1),
        }
    }
    runs
}

/// Whether a page-mapping copy ([`map_alias`]) shows a run of consecutive
/// section pages through one view rather than a view a page
/// (`VICTORY_MAP_RUNS=1`; off by default: one view a page, as before).
///
/// Each view is a system call to map and one to unmap again (unmapping is
/// the dearest: 110 us a view in a cutscene, 330,000 of them in 4 minutes
/// of run x1440-streamlog), so a run of n pages in one view costs 2 calls
/// where it cost 2n. The streaming log's last two fields say how many of
/// the copies' pages continue a run. What it may cost: a later change of a
/// single page inside such a view unmaps all of it and maps the rest again
/// (`unmap`), three calls where one page alone took one.
fn alias_runs() -> bool {
    static ON: LazyLock<bool> = LazyLock::new(|| std::env::var_os("VICTORY_MAP_RUNS").is_some_and(|v| v == "1"));
    *ON
}

/// [`map_alias`] of many ranges, in order.
pub fn map_aliases(ranges: &[(u64, u64, u64)]) -> bool {
    let _costed = Costed::begin(None);
    lift_thread();
    if side_by_side() <= 1 {
        return ranges.iter().all(|&(to, from, len)| alias(to, from, len));
    }
    // By the page: the address, and the one whose page it is to show.
    let pages: Vec<(usize, Option<usize>)> = ranges
        .iter()
        .flat_map(|&(to, from, len)| {
            (0..len as usize).step_by(PAGE).map(move |k| (to as usize + k, (from != 0).then_some(from as usize + k)))
        })
        .collect();
    if pages.iter().any(|p| p.0 % PAGE != 0 || p.1.is_some_and(|from| from % PAGE != 0)) {
        return ranges.iter().all(|&(to, from, len)| alias(to, from, len));
    }
    let mut ok = true;
    let mut at = 0;
    while at < pages.len() {
        let _busy = Busy::begin();
        let _changing = victory_gpu::title_memory_remapping();
        let mut physical = physical();
        let mut ops: Vec<Op> = Vec::new();
        let mut touched = std::collections::HashSet::new();
        for &(to, from) in &pages[at..] {
            // A page the group changes already, or one it would be mapped
            // from: after it.
            if ops.len() == GROUP || touched.contains(&to) || from.is_some_and(|from| touched.contains(&from)) {
                break;
            }
            let slice = from.map(|from| physical.slice_at(from));
            ok &= !matches!(slice, Some(None));
            touched.insert(to);
            ops.push(Op::new(to, slice.flatten()));
            at += 1;
        }
        ok &= change(&mut physical, ops);
    }
    ok
}

/// Maps (page number not 0) or unmaps each address; false if a page is not
/// the title's or the host refuses one.
fn scatter(wanted: &[(usize, usize)]) -> bool {
    let mut ok = true;
    let mut at = 0;
    while at < wanted.len() {
        let _busy = Busy::begin();
        let mut costed = Costed::begin(None);
        let mut ops: Vec<Op> = Vec::new();
        let _changing = victory_gpu::title_memory_remapping();
        let mut physical = physical();
        if let Some(costed) = &mut costed {
            costed.waited = costed.started.elapsed().as_nanos() as u64;
        }
        {
            let table = page_table();
            let mut touched = std::collections::HashSet::new();
            for &(to, page) in &wanted[at..] {
                if ops.len() == GROUP || !touched.insert(to) {
                    break;
                }
                let slice = table.pages.get(&page).cloned();
                if page != 0 && slice.is_none() {
                    tracing::warn!(page, "XMemMapPhysicalPagesScatter: unknown page");
                    ok = false;
                }
                ops.push(Op::new(to, slice));
                at += 1;
            }
        }
        if let Some(costed) = &mut costed {
            costed.pages = Some(ops.len());
        }
        ok &= change(&mut physical, ops);
    }
    ok
}

/// Pages changed under the locks at once.
const GROUP: usize = 64;

/// How many threads map a group of pages side by side (`VICTORY_MAP_THREADS`;
/// 8 unless set; 1: the caller alone, a page after the other; `auto`: 1 while
/// mapping takes little of the time, [`WIDE`] while the title streams as fast
/// as its pages are mapped, [`Busy`]).
///
/// shortcut: `auto` is not the default. The intro's diner was there in time
/// with it (one run, textures-d3), but in the dorm, where each call takes 0.3
/// ms of something that only one at a time gets (until a step of the mission,
/// after which it takes 0.01), 16 threads map no more pages than one, and the
/// groups hold the mapping lock: 260 ms a frame against 125 (textures-d4, -d2).
///
/// Mapping and unmapping a view wait for a lock that every protection change
/// of a view takes too, and our guards make 100,000 of those a second, from
/// many threads, in the world: 0.2 to 4 ms a page. One thread stands in that
/// queue once at a time. In a bench (60,000 views, five threads changing
/// protections) one thread mapped 1,500 pages a second, eight 30,000.
fn side_by_side() -> usize {
    // Views kept in the books alone are noted by the caller, one after the
    // other, with no call to stand in the host's queue for.
    if soft_views() != 0 {
        return 1;
    }
    // Diagnostics: 1 and 8 by turns.
    #[cfg(all(windows, feature = "diagnostics"))]
    if let Some(on) = victory_gpu::switched("VICTORY_MAP_THREADS") {
        return if on { 8 } else { 1 };
    }
    match asked_threads() {
        Some(n) => n,
        None if BUSY.2.load(Ordering::Relaxed) => WIDE,
        None => 1,
    }
}

/// Threads while the title streams fast: they stand in the host's queue side
/// by side, each for a millisecond or two a page in the world's first seconds.
const WIDE: usize = 16;

/// `VICTORY_MAP_THREADS` as a number; `None`: by how much there is to map.
fn asked_threads() -> Option<usize> {
    static ASKED: LazyLock<Option<usize>> = LazyLock::new(|| {
        match std::env::var("VICTORY_MAP_THREADS") {
            Ok(v) if v.trim() == "auto" => None,
            v => Some(v.ok().and_then(|v| v.trim().parse().ok()).unwrap_or(8).clamp(1, 32)),
        }
    });
    *ASKED
}

/// Of the window under way: when it began, the nanoseconds spent mapping in
/// it; and whether the last one was busy.
static BUSY: (Mutex<Option<std::time::Instant>>, AtomicU64, std::sync::atomic::AtomicBool) =
    (Mutex::new(None), AtomicU64::new(0), std::sync::atomic::AtomicBool::new(false));

/// Counts the time a mapping call of the title's takes, as long as it lives.
/// More than a quarter of a window, and the calls are what loading waits for
/// (one thread of the title's makes them); less than a twentieth, they are
/// not any more.
struct Busy(std::time::Instant);

impl Busy {
    fn begin() -> Busy {
        Busy(std::time::Instant::now())
    }
}

/// Whether mapping is busy after a window of `window` with `spent` in it.
fn busy_after(was: bool, spent: std::time::Duration, window: std::time::Duration) -> bool {
    spent * if was { 20 } else { 4 } > window
}

impl Drop for Busy {
    fn drop(&mut self) {
        const WINDOW: std::time::Duration = std::time::Duration::from_millis(250);
        let now = std::time::Instant::now();
        let all = BUSY.1.fetch_add((now - self.0).as_nanos() as u64, Ordering::Relaxed) + (now - self.0).as_nanos() as u64;
        let mut began = BUSY.0.lock().unwrap_or_else(|e| e.into_inner());
        let window = now - *began.get_or_insert(self.0);
        if window < WINDOW {
            return;
        }
        *began = Some(now);
        BUSY.1.store(0, Ordering::Relaxed);
        let was = BUSY.2.load(Ordering::Relaxed);
        let is = busy_after(was, std::time::Duration::from_nanos(all), window);
        if was != is {
            BUSY.2.store(is, Ordering::Relaxed);
            static SAID: AtomicU64 = AtomicU64::new(0);
            if asked_threads().is_none() && SAID.fetch_add(1, Ordering::Relaxed) < 200 {
                tracing::info!(
                    "title pages are mapped by {} (VICTORY_MAP_THREADS): {:.0} ms of the last {:.0} ms went into mapping calls",
                    if is { "several threads" } else { "the caller alone" },
                    all as f64 / 1e6,
                    window.as_secs_f64() * 1e3
                );
            }
        }
    }
}

/// A page of address space to unmap and, with a slice, map anew.
struct Op {
    at: usize,
    slice: Option<Slice>,
    /// A view of this page alone is there, to be unmapped.
    had: bool,
    /// The placeholder is the page's own (or will be, after the unmapping).
    own: bool,
}

impl Op {
    fn new(at: usize, slice: Option<Slice>) -> Op {
        Op { at, slice, had: false, own: false }
    }

    /// The system calls; whether the host did as asked.
    fn run(&self) -> bool {
        if self.had {
            // SAFETY: a view we mapped; it becomes a placeholder again.
            let gone = counted(Call::Unmap, || unsafe {
                UnmapViewOfFile2(
                    GetCurrentProcess(),
                    MEMORY_MAPPED_VIEW_ADDRESS { Value: self.at as *mut c_void },
                    MEM_PRESERVE_PLACEHOLDER,
                )
            });
            if gone == 0 {
                return false;
            }
        }
        let Some(slice) = &self.slice else {
            return true;
        };
        show(self.at, PAGE, slice, self.own)
    }
}

/// Does `ops`, each of another page, side by side: first what is noted of
/// the pages goes, then the system calls, then what is there now is noted.
/// With [`PHYSICAL`] and the change of mapping (`title_memory_remapping`)
/// held.
fn change(physical: &mut Physical, mut ops: Vec<Op>) -> bool {
    for op in &mut ops {
        let there = physical
            .views
            .range(..=op.at)
            .next_back()
            .filter(|(base, view)| op.at < **base + view.0)
            .map(|(base, view)| (*base, view.0));
        match there {
            Some((base, PAGE)) if base == op.at => {
                if let Some((size, slice)) = physical.views.remove(&op.at) {
                    shown_mut().forget(op.at, size, &slice);
                }
                victory_gpu::title_memory_unmapping(op.at, PAGE);
                physical.holes.remove(&op.at);
                if unlazy(op.at) {
                    // Only in our books: its own placeholder is there.
                    count(Soft::Gone, 1);
                    if op.slice.is_none() {
                        physical.holes.insert(op.at, PAGE);
                    }
                    op.own = true;
                    continue;
                }
                (op.had, op.own) = (true, lean());
            }
            // Part of a larger view.
            Some(_) => {
                unmap(physical, op.at, PAGE);
            }
            None => {}
        }
        if op.had {
            continue;
        }
        op.own = physical.holes.remove(&op.at) == Some(PAGE) && lean();
        if op.slice.is_some() && !op.own {
            // Cut out of a larger placeholder here, not side by side: a
            // thread that maps a piece while others cut the same one can
            // fail.
            split(op.at, PAGE);
            op.own = true;
        }
    }
    let done = pool::all(ops);
    let mut ok = true;
    for (op, done) in done {
        match op.slice {
            Some(slice) if done => {
                // As in `map`.
                shown_mut().note(op.at, PAGE, &slice);
                victory_gpu::title_memory_remapped(op.at, PAGE);
                victory_gpu::title_memory_view(op.at, PAGE, slice.section.handle as usize, (slice.index * PAGE) as u64);
                physical.views.insert(op.at, (PAGE, slice));
            }
            None if op.had && done => {
                physical.holes.insert(op.at, PAGE);
            }
            _ => ok &= done,
        }
    }
    ok
}

/// The threads that do the system calls of [`change`].
mod pool {
    use std::collections::VecDeque;
    use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
    use std::sync::{Arc, Condvar, Mutex, OnceLock};

    use super::{Op, side_by_side};

    struct Batch {
        ops: Vec<(Op, AtomicBool)>,
        next: AtomicUsize,
        /// Ops not done yet.
        left: AtomicUsize,
        over: (Mutex<bool>, Condvar),
    }

    impl Batch {
        /// Does ops until none is left to begin.
        fn work(&self) {
            loop {
                let i = self.next.fetch_add(1, Ordering::Relaxed);
                let Some((op, done)) = self.ops.get(i) else {
                    return;
                };
                done.store(op.run(), Ordering::Release);
                if self.left.fetch_sub(1, Ordering::AcqRel) == 1 {
                    *self.over.0.lock().unwrap_or_else(|e| e.into_inner()) = true;
                    self.over.1.notify_all();
                }
            }
        }
    }

    struct Pool {
        batches: Mutex<VecDeque<Arc<Batch>>>,
        more: Condvar,
    }

    fn pool() -> &'static Pool {
        static POOL: OnceLock<Pool> = OnceLock::new();
        static STARTED: std::sync::Once = std::sync::Once::new();
        let pool = POOL.get_or_init(|| Pool { batches: Mutex::default(), more: Condvar::new() });
        STARTED.call_once(|| {
            let started = (1..super::asked_threads().unwrap_or(super::WIDE).max(side_by_side()))
                .filter(|i| std::thread::Builder::new().name(format!("mapping {i}")).spawn(|| serve(pool)).is_ok())
                .count();
            tracing::info!(started, "threads that map pages side by side (VICTORY_MAP_THREADS=1: none)");
        });
        pool
    }

    fn serve(pool: &Pool) {
        use windows_sys::Win32::System::Threading::{
            GetCurrentThread, SetThreadPriority, THREAD_PRIORITY_ABOVE_NORMAL,
        };
        // SAFETY: a plain call on our own thread.
        unsafe { SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_ABOVE_NORMAL) };
        let mut batches = pool.batches.lock().unwrap_or_else(|e| e.into_inner());
        loop {
            let Some(batch) = batches.front().cloned() else {
                batches = pool.more.wait(batches).unwrap_or_else(|e| e.into_inner());
                continue;
            };
            if batch.next.load(Ordering::Relaxed) >= batch.ops.len() {
                // All begun: nobody needs to see it any more.
                if batches.front().is_some_and(|b| Arc::ptr_eq(b, &batch)) {
                    batches.pop_front();
                }
                continue;
            }
            drop(batches);
            batch.work();
            batches = pool.batches.lock().unwrap_or_else(|e| e.into_inner());
        }
    }

    /// Runs `ops`; each with whether the host did it.
    pub(super) fn all(ops: Vec<Op>) -> Vec<(Op, bool)> {
        // Waking the others takes longer than a few quick calls.
        if ops.len() < 3 {
            return ops
                .into_iter()
                .map(|op| {
                    let done = op.run();
                    (op, done)
                })
                .collect();
        }
        let n = ops.len();
        let batch = Arc::new(Batch {
            ops: ops.into_iter().map(|op| (op, AtomicBool::new(false))).collect(),
            next: AtomicUsize::new(0),
            left: AtomicUsize::new(n),
            over: Default::default(),
        });
        let pool = pool();
        pool.batches.lock().unwrap_or_else(|e| e.into_inner()).push_back(batch.clone());
        if n > side_by_side() {
            pool.more.notify_all();
        } else {
            (1..n).for_each(|_| pool.more.notify_one());
        }
        batch.work();
        let mut over = batch.over.0.lock().unwrap_or_else(|e| e.into_inner());
        while !*over {
            over = batch.over.1.wait(over).unwrap_or_else(|e| e.into_inner());
        }
        drop(over);
        // No worker changes it any more (one may still hold it for a moment).
        batch
            .ops
            .iter()
            .map(|(op, done)| {
                let op = Op { at: op.at, slice: op.slice.clone(), had: op.had, own: op.own };
                (op, done.load(Ordering::Acquire))
            })
            .collect()
    }
}

/// Maps `slice` and the slices after it over `[base, base + len)`, which
/// must lie in one placeholder.
fn map(physical: &mut Physical, base: usize, len: usize, slice: Slice) -> bool {
    map_as(physical, base, len, slice, false)
}

/// [`map`]; `quiet`: a failure is not said (the caller tries another way).
fn map_as(physical: &mut Physical, base: usize, len: usize, slice: Slice, quiet: bool) -> bool {
    let own = physical.holes.remove(&base) == Some(len) && lean();
    if !show_as(base, len, &slice, own, quiet) {
        return false;
    }
    // Noted before the GPU side is told: bytes DirectStorage put in earlier,
    // without notice at these addresses ([`pages_written`]), are there by
    // the time the copies of them go.
    shown_mut().note(base, len, &slice);
    // New contents, read-write: the GPU side's copies no longer guard it.
    victory_gpu::title_memory_remapped(base, len);
    // What the range shows now, for the GPU side's in-place census.
    victory_gpu::title_memory_view(base, len, slice.section.handle as usize, (slice.index * PAGE) as u64);
    physical.views.insert(base, (len, slice));
    true
}

/// Cuts `[base, base + len)` out of the placeholder it is in (which fails
/// harmlessly when the range is the whole placeholder).
fn split(base: usize, len: usize) {
    // SAFETY: acts only on a placeholder.
    counted(Call::Split, || unsafe {
        VirtualFree(
            base as *mut c_void,
            len,
            MEM_RELEASE | MEM_PRESERVE_PLACEHOLDER,
        )
    });
}

/// The system calls of [`map`]; `own`: the placeholder at `base` is `len`
/// long already.
fn show(base: usize, len: usize, slice: &Slice, own: bool) -> bool {
    show_as(base, len, slice, own, false)
}

/// [`show`]; `quiet`: a failure to map is not said.
fn show_as(base: usize, len: usize, slice: &Slice, own: bool, quiet: bool) -> bool {
    let map_view = || {
        // SAFETY: maps the section over a placeholder; acts only on one.
        counted(Call::Map, || unsafe {
            MapViewOfFile3(
                slice.section.handle,
                GetCurrentProcess(),
                base as *const c_void,
                (slice.index * PAGE) as u64,
                len,
                MEM_REPLACE_PLACEHOLDER,
                PAGE_READWRITE,
                std::ptr::null_mut(),
                0,
            )
        })
    };
    let mut view = if own { map_view() } else { MEMORY_MAPPED_VIEW_ADDRESS { Value: std::ptr::null_mut() } };
    if view.Value as usize != base {
        split(base, len);
        view = map_view();
    }
    if view.Value as usize != base {
        if quiet {
            return false;
        }
        tracing::warn!(
            address = format_args!("{base:#x}"),
            len,
            error = %std::io::Error::last_os_error(),
            "mapping physical pages failed (not a placeholder?)"
        );
        return false;
    }
    if !slice.section.commit_shown(slice.index, base, len) {
        // SAFETY: the view just mapped, back to a placeholder.
        unsafe { UnmapViewOfFile2(GetCurrentProcess(), view, MEM_PRESERVE_PLACEHOLDER) };
        return false;
    }
    true
}

/// Commits the section pages a view shows (once per page, whichever view).
fn commit(base: usize, len: usize) -> bool {
    if on_wine() {
        return true; // sections are committed whole there
    }
    // SAFETY: `[base, base + len)` is a view of a reserved section.
    if !unsafe { VirtualAlloc(base as *const c_void, len, MEM_COMMIT, PAGE_READWRITE) }.is_null() {
        return true;
    }
    commit_refused(len, "physical pages", std::io::Error::last_os_error());
    false
}

/// Reports memory the host would not give: at the Windows commit limit to
/// `crashes.log`, since the title usually faults soon after on the null it
/// gets; otherwise as a warning.
fn commit_refused(len: usize, what: &str, error: std::io::Error) {
    if error.raw_os_error() == Some(ERROR_COMMITMENT_LIMIT as i32) {
        let mut info = PERFORMANCE_INFORMATION {
            cb: size_of::<PERFORMANCE_INFORMATION>() as u32,
            ..Default::default()
        };
        // SAFETY: the buffer and size describe a writable PERFORMANCE_INFORMATION.
        let queried = unsafe { K32GetPerformanceInfo(&mut info, info.cb) } != 0;
        victory_loader::log_crash(&commit_limit_message(
            len,
            what,
            &error,
            queried.then_some(&info),
        ));
    } else {
        tracing::warn!(len, %error, "committing {what} failed");
    }
}

fn commit_limit_message(
    len: usize,
    what: &str,
    error: &std::io::Error,
    info: Option<&PERFORMANCE_INFORMATION>,
) -> String {
    let mut message = format!(
        "VIctory: Windows commit limit reached while committing {len} bytes of {what}: {error}.\n"
    );
    if let Some(info) = info {
        use std::fmt::Write;

        let committed = info.CommitTotal * info.PageSize / MIB;
        let limit = info.CommitLimit * info.PageSize / MIB;
        let _ = writeln!(
            message,
            "System commit: {committed} MiB of {limit} MiB in use."
        );
    }
    message.push_str(
        "Close other applications or increase the Windows paging file size, then retry.\n",
    );
    message
}

/// Returns `[base, base + len)` to placeholders; views reaching past it
/// are mapped again outside it.
fn unmap(physical: &mut Physical, base: usize, len: usize) {
    // No bytes: no view to return. The search below would still find the
    // view holding `base` and cut it in two there, and its range of views
    // starting inside would run backwards (which `BTreeMap` panics on).
    if len == 0 {
        return;
    }
    let end = base + len;
    // Views do not overlap: the one holding `base`, then those starting
    // inside (the GPU's page mappings make one view per page).
    let first = physical
        .views
        .range(..=base)
        .next_back()
        .filter(|(at, (size, _))| *at + size > base)
        .map(|(at, _)| *at);
    let hit: Vec<usize> = first
        .into_iter()
        .chain(physical.views.range(base + 1..end).map(|(at, _)| *at))
        .collect();
    for at in hit {
        let Some((size, slice)) = physical.views.remove(&at) else {
            continue;
        };
        shown_mut().forget(at, size, &slice);
        if at < base || at + size > end {
            // Parts of it stay, and are mapped again below.
            victory_gpu::title_memory_splitting(at, size);
        }
        victory_gpu::title_memory_unmapping(at, size);
        if unlazy(at) {
            // A view only in our books ([`map_lazy`]): no host view to
            // unmap; its own placeholder is there, and what stays of it
            // stays lazy.
            count(Soft::Gone, 1);
            if at >= base && at + size <= end {
                physical.holes.insert(at, size);
            }
            if at < base {
                map_lazy(physical, at, base - at, slice.clone(), None);
            }
            if at + size > end {
                let index = slice.index + (end - at) / PAGE;
                map_lazy(physical, end, at + size - end, Slice { index, ..slice }, None);
            }
            continue;
        }
        // SAFETY: a view we mapped; it becomes a placeholder again.
        let gone = counted(Call::Unmap, || unsafe {
            UnmapViewOfFile2(
                GetCurrentProcess(),
                MEMORY_MAPPED_VIEW_ADDRESS {
                    Value: at as *mut c_void,
                },
                MEM_PRESERVE_PLACEHOLDER,
            )
        });
        if gone != 0 && at >= base && at + size <= end {
            physical.holes.insert(at, size);
        }
        if at < base {
            map(physical, at, base - at, slice.clone());
        }
        if at + size > end {
            let index = slice.index + (end - at) / PAGE;
            map(physical, end, at + size - end, Slice { index, ..slice });
        }
    }
}

/// Whether the title's own mapping calls (`XMemMapPhysicalPages`) map
/// lazily (`VICTORY_LAZY_VIEWS=1`; off by default): the view is noted, and
/// told to the GPU side, as mapped, and its addresses are made a
/// placeholder of their own (a split, cheap), but the host maps the view
/// only when something touches it: a fault in it, the title's or ours (the
/// GPU side's fault handler asks [`materialize`] first:
/// `victory_gpu::use_lazy_views`), or a touch that handler does not see
/// (the GPU side's reads and writes through the kernel, its guards, its
/// questions to Windows; the title's `XMemVirtualQuery`, `VirtualFree` and
/// `XMemVirtualAlloc` there), which asks [`materialize`] itself. A view no
/// one touched is let go with no system call at all.
///
/// Why: the title maps the pages it streams into one call a page (365,000
/// calls in 4 minutes of run x1440-streamlog, 25.7 s), and DirectStorage
/// fills them through views of its own of the pages (by page number); the
/// GPU side's page-mapping copies read what the pool shows from our books
/// alone. Each such view was a map (45 us) and later an unmap (110 us, the
/// TLB shootdown), and a cutscene's streaming thread spent 846 ms of 1.7 s
/// in them (timeline tl.120), on the frame's critical path.
///
/// Page-mapping copies (`map_alias`) map as before: the GPU side reads the
/// textures there. Mapping side by side (`VICTORY_MAP_THREADS` over 1)
/// maps as before too, and lets lazy views go as views of their own.
fn lazy_views() -> bool {
    static ON: LazyLock<bool> = LazyLock::new(|| {
        let on = std::env::var_os("VICTORY_LAZY_VIEWS").is_some_and(|v| v == "1");
        if on {
            victory_gpu::use_lazy_views(materialize);
            tracing::info!("title pages are mapped on the host when first touched (VICTORY_LAZY_VIEWS=1)");
        }
        on
    });
    *ON
}

/// The title's own mapping calls keep their views in our books alone
/// ([`soft_views`]).
const SOFT_POOL: u8 = 1;
/// The GPU's page-mapping copies do.
const SOFT_COPIES: u8 = 2;

/// Which of the title's views are kept in our books alone, with no view of
/// the host's until the title's CPU touches them (`VICTORY_SOFT_VIEWS`; off
/// unless asked for). `1`: those of the title's own mapping calls
/// (`XMemMapPhysicalPages`, into its pool) and those of the GPU's
/// page-mapping copies (`CopyPageMappingsBatchX`, into its tiled heap);
/// `pool`: the first alone; `copies`: the second alone.
///
/// Why: every view of the host's is a call to map it (45 us) and one to
/// unmap it (93 us), each waiting for a lock of the kernel's that our
/// guards' protection changes take too. In 143 s of run stream2: 445,503
/// maps (20.1 s) and 349,175 unmaps (32.6 s); the title's 359,969 mapping
/// calls took 23.8 s and its 3,294 page-mapping copies 33.7 s, one of them
/// 467 ms of a frame of 608 (timeline tl.120). A view kept in the books is
/// one split of a placeholder the first time its addresses are used and no
/// call after that.
///
/// Who needs the bytes at such a view, and how they get them:
/// - DirectStorage writes the pages by number, through the section's own
///   view ([`Section::window`]): as before, no view of the title's needed.
/// - The page-mapping copies take what the pool shows from the books
///   ([`Physical::slice_at`]): as before.
/// - The GPU side reads title memory through one function, which takes the
///   bytes of such a view from the pages ([`soft_read`]), asks which memory
///   is such a view ([`soft_runs`]) to take it for committed and to read a
///   texture there through a copy, and guards such a view in its books,
///   with no protection change (`victory_gpu::SoftViews`).
/// - The title's CPU, and whatever of ours touches the memory itself: the
///   access faults, the GPU side's handler (first in the process) makes the
///   view a mapping of the host's ([`materialize_for`]) and the access is
///   made again. From then on it is a view as before, until the title
///   unmaps it. What that handler does not see asks first: our writes
///   through the kernel, the kernel's writes the runtime announces (file
///   reads, DirectStorage's memory destinations), the title's
///   `XMemVirtualQuery`, `VirtualFree` and `XMemVirtualAlloc` there, and,
///   with this switch, its `VirtualQuery` and `VirtualProtect`
///   ([`title_virtual_query`]). Not covered: another call of the host's
///   that the title makes itself with such memory as an argument.
///
/// What it differs in from `VICTORY_LAZY_VIEWS=1` (2 fps in run xw-lazy,
/// 2.4 to 3.4 GB of copies a frame): there the GPU side made a lazy view
/// real whenever it guarded a range (every refresh of a copy or texture
/// over it), and a view guarded together with a lazy view of the same page
/// was never clean, since the host refused to protect the placeholder; and
/// only the title's own calls mapped lazily. Here a view in the books is
/// guarded in the books, read from the pages, and the copies' views are
/// kept there too.
///
/// What a run must show (the streaming log's M line, and a line of the log
/// every 10 s): how many views were made real, and by whose touch. If the
/// title's code touches most of them, nothing is gained (a fault and a map
/// where a map was).
///
/// With it one thread maps (`VICTORY_MAP_THREADS` counts as 1): mapping
/// side by side maps views of the host's.
fn soft_views() -> u8 {
    static ON: LazyLock<u8> = LazyLock::new(|| {
        let which = match std::env::var("VICTORY_SOFT_VIEWS").as_deref().map(str::trim) {
            Ok("1") => SOFT_POOL | SOFT_COPIES,
            Ok("pool") => SOFT_POOL,
            Ok("copies") => SOFT_COPIES,
            _ => 0,
        };
        if which != 0 {
            use_soft_views();
            let said = std::thread::Builder::new().name("victory-soft-views".into()).spawn(|| {
                let mut before = ([0; SOFT_FIELDS], [0; 2]);
                loop {
                    std::thread::sleep(std::time::Duration::from_secs(10));
                    if let Some(line) = soft_line(&mut before, 10) {
                        tracing::info!("{line}");
                    }
                }
            });
            tracing::info!(
                pool = which & SOFT_POOL != 0,
                copies = which & SOFT_COPIES != 0,
                line = said.is_ok(),
                "title views are kept in the books alone until the title's CPU touches them (VICTORY_SOFT_VIEWS)"
            );
        }
        which
    });
    *ON
}

/// Tells the GPU side how views in our books alone are read, asked about
/// and made real ([`soft_views`]).
fn use_soft_views() {
    victory_gpu::use_soft_views(victory_gpu::SoftViews {
        materialize: |at, len| materialize_for(at, len, Touch::Asked),
        fault: |at, code| materialize_for(at, 1, Touch::Fault(code)),
        read: soft_read,
        runs: soft_runs,
    });
}

/// The views in our books that are no host mapping yet: address, bytes and
/// what they show. Written with [`PHYSICAL`] held (after it); read without
/// it, so that the many questions and reads of the GPU side about title
/// memory cost no wait behind a mapping call.
static LAZY: LazyLock<RwLock<BTreeMap<usize, (usize, Slice)>>> = LazyLock::new(Default::default);

/// How many views [`LAZY`] holds: none, and nothing is asked of it.
static LAZY_N: AtomicUsize = AtomicUsize::new(0);

/// How many views in [`LAZY`] touch each 256 MiB of the first 2^40 bytes
/// (where the title's memory is): what lies in a piece with none (the
/// title's heaps, which the GPU side reads far more often than its views)
/// is no question to [`LAZY`], which costs a lock and a search.
static LAZY_AT: [std::sync::atomic::AtomicU32; 1 << 12] = [const { std::sync::atomic::AtomicU32::new(0) }; 1 << 12];

/// The pieces of [`LAZY_AT`], as a shift of the address.
const LAZY_PIECE: u32 = 28;

/// Notes in [`LAZY_AT`] that a view at `[base, base + len)` is in [`LAZY`]
/// (`there`), or no more.
fn lazy_at(base: usize, len: usize, there: bool) {
    for piece in base >> LAZY_PIECE..=(base + len.max(1) - 1) >> LAZY_PIECE {
        match LAZY_AT.get(piece) {
            Some(n) if there => n.fetch_add(1, Ordering::AcqRel),
            Some(n) => n.fetch_sub(1, Ordering::AcqRel),
            None => break,
        };
    }
}

/// Whether a view in [`LAZY`] may overlap `[at, at + len)`.
fn maybe_lazy(at: usize, len: usize) -> bool {
    if LAZY_N.load(Ordering::Acquire) == 0 {
        return false;
    }
    let (first, last) = (at >> LAZY_PIECE, at.saturating_add(len.max(1) - 1) >> LAZY_PIECE);
    // (A range over many pieces, or past them: [`LAZY`] says.)
    last - first >= 16 || last >= LAZY_AT.len() || LAZY_AT[first..=last].iter().any(|n| n.load(Ordering::Acquire) != 0)
}

/// What is counted of the views in our books alone, since the start: the
/// fields of the streaming log's M line after the mapping costs, in this
/// order (there since the last line), then how many there are now.
#[derive(Clone, Copy)]
enum Soft {
    /// Views noted with no view of the host's.
    Noted = 0,
    /// Let go before anything touched them: no map, no unmap.
    Gone = 1,
    /// Made views of the host's.
    Real = 2,
    /// Of the noted: by the title's own mapping calls.
    NotedPool = 3,
    /// By the GPU's page-mapping copies.
    NotedCopies = 4,
    /// Of those made real: by a fault of code in the title's main image.
    FaultTitle = 5,
    /// By a fault of other code (ours, a library's, the system's).
    FaultOther = 6,
    /// Asked for by the GPU side ahead of a touch through the kernel.
    Asked = 7,
    /// By a call of the title's about the memory.
    TitleCall = 8,
    /// Reads of the GPU side served from the pages.
    Reads = 9,
    /// Their bytes.
    ReadBytes = 10,
}

const SOFT_FIELDS: usize = 11;

static SOFT_N: [AtomicU64; SOFT_FIELDS] = [const { AtomicU64::new(0) }; SOFT_FIELDS];

fn count(what: Soft, n: u64) {
    SOFT_N[what as usize].fetch_add(n, Ordering::Relaxed);
}

/// [`SOFT_N`] since `before` held it, which holds it now.
fn soft_since(before: &mut [u64; SOFT_FIELDS]) -> [u64; SOFT_FIELDS] {
    let now: [u64; SOFT_FIELDS] = std::array::from_fn(|i| SOFT_N[i].load(Ordering::Relaxed));
    let since = std::array::from_fn(|i| now[i].wrapping_sub(before[i]));
    *before = now;
    since
}

/// The last access that made a view real by a fault: its address and the
/// code's, for a fault of the title's main image and for one of other code
/// (0: none yet). Said in the log's line, not from the fault handler.
static LAST_FAULT: [AtomicUsize; 4] = [const { AtomicUsize::new(0) }; 4];

/// The log's line about the views in our books alone over the last
/// `seconds` (since `before` held the counts), or `None` if there was
/// nothing to say.
fn soft_line(before: &mut ([u64; SOFT_FIELDS], [u64; 2]), seconds: u64) -> Option<String> {
    let n = soft_since(&mut before.0);
    let guards = victory_gpu::soft_view_guards();
    let guarded = [guards[0].wrapping_sub(before.1[0]), guards[1].wrapping_sub(before.1[1])];
    before.1 = guards;
    let now = LAZY_N.load(Ordering::Relaxed);
    if n.iter().all(|&n| n == 0) && now == 0 {
        return None;
    }
    let of = |what: Soft| n[what as usize];
    let image = crate::runtime::main_image().unwrap_or(0);
    let last = |i: usize| {
        let (at, code) = (LAST_FAULT[i].load(Ordering::Relaxed), LAST_FAULT[i + 1].load(Ordering::Relaxed));
        match (at, i) {
            (0, _) => String::new(),
            (_, 0) => format!(" (the last at {at:#x}, code title+{:#x})", code.wrapping_sub(image)),
            _ => format!(" (the last at {at:#x}, code {code:#x})"),
        }
    };
    Some(format!(
        "title views kept in the books alone (VICTORY_SOFT_VIEWS), last {seconds} s: {} noted with no view of the host's ({} by the title's mapping calls, {} by page-mapping copies), \
         {} let go untouched (no map, no unmap); {} made views of the host's: {} by a fault of the title's code{}, {} by a fault of other code{}, \
         {} asked for by the GPU side, {} by a call of the title's; {} reads of the GPU side served from the pages ({} MB); \
         guarded in the books: {} blocks, {} more as other views of guarded pages; {now} such views now",
        of(Soft::Noted),
        of(Soft::NotedPool),
        of(Soft::NotedCopies),
        of(Soft::Gone),
        of(Soft::Real),
        of(Soft::FaultTitle),
        last(0),
        of(Soft::FaultOther),
        last(2),
        of(Soft::Asked),
        of(Soft::TitleCall),
        of(Soft::Reads),
        of(Soft::ReadBytes) >> 20,
        guarded[0],
        guarded[1],
    ))
}

/// Takes the view at `at` out of [`LAZY`]; whether it was lazy.
fn unlazy(at: usize) -> bool {
    if LAZY_N.load(Ordering::Acquire) == 0 {
        return false;
    }
    let gone = LAZY.write().unwrap_or_else(|e| e.into_inner()).remove(&at);
    if let Some((size, _)) = &gone {
        lazy_at(at, *size, false);
        LAZY_N.fetch_sub(1, Ordering::AcqRel);
    }
    gone.is_some()
}

/// [`map`], in the books alone ([`lazy_views`], [`soft_views`]): the
/// addresses become one placeholder of their own, as the view would leave
/// them, and the view is noted and told of; no host view yet. Where they
/// cannot be made one placeholder, the view is mapped now, as [`map`] does.
/// `who`: whose view it is, for the counts (`None`: what stays of one that
/// was cut).
fn map_lazy(physical: &mut Physical, base: usize, len: usize, slice: Slice, who: Option<Soft>) -> bool {
    // The pages are committed now, as mapping a view commits them: the GPU
    // side reads and writes them through views of its own of the section
    // (ours, [`soft_read`]; its own, where it puts bytes in beside a guard),
    // and a page nothing has written yet would fault there. Through the
    // section's view, once a page ([`Section::window`]); without that view
    // (`VICTORY_SECTION_WINDOW=0`) a view of the host's, as before.
    if slice.section.window(slice.index, len / PAGE).is_none() {
        return map(physical, base, len, slice);
    }
    let own = physical.holes.remove(&base) == Some(len);
    if !own {
        split(base, len);
        if !one_placeholder_there(base, len) {
            return map(physical, base, len, slice);
        }
    }
    // Known as in the books alone before the GPU side is told of the view:
    // a refresh that guards it in between would find a placeholder of the
    // host's, take the block for not there, and leave it out of its copies
    // until the next mapping there.
    lazy_at(base, len, true);
    match LAZY.write().unwrap_or_else(|e| e.into_inner()).insert(base, (len, slice.clone())) {
        // (None was there: `unmap` took it out. Counted right all the same.)
        Some((before, _)) => lazy_at(base, before, false),
        None => {
            LAZY_N.fetch_add(1, Ordering::AcqRel);
        }
    }
    shown_mut().note(base, len, &slice);
    victory_gpu::title_memory_remapped(base, len);
    victory_gpu::title_memory_view(base, len, slice.section.handle as usize, (slice.index * PAGE) as u64);
    physical.views.insert(base, (len, slice));
    if let Some(who) = who {
        count(Soft::Noted, 1);
        count(who, 1);
    }
    true
}

/// [`map`], or [`map_lazy`] for `lazy`.
fn place(physical: &mut Physical, base: usize, len: usize, slice: Slice, lazy: Option<Soft>) -> bool {
    match lazy {
        Some(who) => map_lazy(physical, base, len, slice, Some(who)),
        None => map(physical, base, len, slice),
    }
}

/// For the GPU side (`victory_gpu::SoftViews::read`): if a view in our
/// books alone holds `at`, its bytes from there on, to its end or `len` at
/// most, are copied from the pages to `to`: `(true, bytes copied)`. Else
/// `(false, n)`: the next `n` bytes, `len` at most, are in no such view.
/// (A view whose section has no view of ours, [`Section::window`], is made
/// a mapping of the host's and answered as the second.)
fn soft_read(at: usize, to: *mut u8, len: usize) -> (bool, usize) {
    if len == 0 || !maybe_lazy(at, len) {
        return (false, len);
    }
    let found = {
        let lazy = LAZY.read().unwrap_or_else(|e| e.into_inner());
        match lazy.range(..=at).next_back().filter(|(base, view)| at < **base + view.0) {
            Some((&base, (size, slice))) => Ok((base, *size, slice.clone())),
            None => Err(lazy.range(at..).next().map_or(len, |(&next, _)| (next - at).min(len))),
        }
    };
    let (base, size, slice) = match found {
        Ok(view) => view,
        Err(n) => return (false, n),
    };
    let n = (base + size - at).min(len);
    let (first, within) = ((at - base) / PAGE, (at - base) % PAGE);
    // Committed, as the view would be when mapped: a page nothing wrote
    // reads as zeros, as it would there. (The section is held: its view
    // stands while the bytes are copied, whatever the title unmaps.)
    let Some(window) = slice.section.window(slice.index + first, (within + n).div_ceil(PAGE)) else {
        materialize_for(at, n, Touch::Asked);
        return (false, n);
    };
    // SAFETY: `n` committed bytes of the section's view; the caller's `to`
    // holds as many. The title's writes to the pages race as on the console.
    unsafe { std::ptr::copy_nonoverlapping((window + within) as *const u8, to, n) };
    count(Soft::Reads, 1);
    count(Soft::ReadBytes, n as u64);
    (true, n)
}

/// For the GPU side (`victory_gpu::SoftViews::runs`): the parts of
/// `[at, at + len)` that views in our books alone show, in order, those
/// that touch as one: (address, bytes).
fn soft_runs(at: usize, len: usize) -> Vec<(usize, usize)> {
    let mut runs: Vec<(usize, usize)> = Vec::new();
    if len == 0 || !maybe_lazy(at, len) {
        return runs;
    }
    let end = at.saturating_add(len);
    let lazy = LAZY.read().unwrap_or_else(|e| e.into_inner());
    let first = lazy.range(..=at).next_back().filter(|(base, view)| **base + view.0 > at).map(|(&base, view)| (base, view.0));
    let rest = lazy.range(at.saturating_add(1)..end.max(at.saturating_add(1))).map(|(&base, view)| (base, view.0));
    for (base, size) in first.into_iter().chain(rest) {
        let (from, to) = (base.max(at), (base + size).min(end));
        match runs.last_mut() {
            Some((start, bytes)) if *start + *bytes == from => *bytes += to - from,
            _ => runs.push((from, to - from)),
        }
    }
    runs
}

/// What made a view in our books alone a view of the host's.
#[derive(Clone, Copy)]
enum Touch {
    /// An access that faulted, of the code at this address.
    Fault(usize),
    /// The GPU side, ahead of a touch through the kernel.
    Asked,
    /// A call of the title's about the memory.
    TitleCall,
}

/// Whether `code` lies in the title's main image.
fn title_code(code: usize) -> bool {
    static SIZE: AtomicUsize = AtomicUsize::new(0);
    let Some(base) = crate::runtime::main_image() else {
        return false;
    };
    let mut size = SIZE.load(Ordering::Relaxed);
    if size == 0 {
        // SAFETY: a mapped image: its headers are there (the DOS header's
        // offset of the PE header, and that header's size of the image).
        size = unsafe {
            let pe = base + ((base + 0x3c) as *const u32).read_unaligned() as usize;
            ((pe + 0x50) as *const u32).read_unaligned() as usize
        };
        SIZE.store(size, Ordering::Relaxed);
    }
    (base..base + size).contains(&code)
}

/// Whether `[base, base + len)` is one placeholder, exactly (Windows asked).
fn one_placeholder_there(base: usize, len: usize) -> bool {
    use windows_sys::Win32::System::Memory::VirtualQuery;
    // SAFETY: plain data filled in by the query.
    let mut info: MEMORY_BASIC_INFORMATION = unsafe { std::mem::zeroed() };
    // SAFETY: a valid out pointer of the right size.
    let n = unsafe { VirtualQuery(base as *const c_void, &mut info, size_of_val(&info)) };
    n != 0
        && info.State == MEM_RESERVE
        && info.AllocationBase as usize == base
        && info.BaseAddress as usize == base
        && info.RegionSize == len
}

/// Makes the lazy views ([`lazy_views`]) that overlap `[at, at + len)` host
/// views; whether there were any and all of them could be made (then an
/// access that faulted there is made again). For the GPU side's fault
/// handler and its other touches of title memory, and the title's calls
/// below. Not on a thread that holds the views (one of our mapping calls
/// touching title memory: never, by design).
fn materialize(at: usize, len: usize) -> bool {
    materialize_for(at, len, Touch::Asked)
}

/// [`materialize`]; `touch`: what asks, for the counts.
fn materialize_for(at: usize, len: usize, touch: Touch) -> bool {
    if !maybe_lazy(at, len.max(1)) {
        return false;
    }
    let end = at.saturating_add(len.max(1));
    let overlapping = |lazy: &BTreeMap<usize, (usize, Slice)>| -> Vec<usize> {
        lazy.range(..end).rev().take_while(|&(&base, view)| base + view.0 > at).map(|(&base, _)| base).collect()
    };
    {
        let lazy = LAZY.read().unwrap_or_else(|e| e.into_inner());
        if lazy.is_empty() || overlapping(&lazy).is_empty() {
            return false;
        }
    }
    if HOLDING.get() {
        return false;
    }
    let physical = physical();
    let bases = overlapping(&LAZY.read().unwrap_or_else(|e| e.into_inner()));
    let mut all = !bases.is_empty();
    for base in bases {
        let Some((size, slice)) = physical.views.get(&base).cloned() else {
            unlazy(base);
            all = false;
            continue;
        };
        // Its own placeholder is there ([`map_lazy`]).
        let made = show(base, size, &slice, true);
        unlazy(base);
        // Read-write, and there: the title writes through it from now on
        // with no fault. What the GPU side guarded of it in its books, and
        // the other views of its pages with it, counts as written.
        victory_gpu::title_memory_made_real(base, size);
        count(Soft::Real, 1);
        match touch {
            Touch::Fault(code) => {
                let title = title_code(code);
                count(if title { Soft::FaultTitle } else { Soft::FaultOther }, 1);
                let last = if title { 0 } else { 2 };
                LAST_FAULT[last].store(at, Ordering::Relaxed);
                LAST_FAULT[last + 1].store(code, Ordering::Relaxed);
            }
            Touch::Asked => count(Soft::Asked, 1),
            Touch::TitleCall => count(Soft::TitleCall, 1),
        }
        all &= made;
    }
    drop(physical);
    all
}

/// The oldest layout we know; newer titles pass other flag values (Minecraft
/// 0x20000001) and read the same leading fields.
#[repr(C)]
#[derive(Debug, Default)]
pub struct WorkingSet {
    pub title_limit: usize,
    pub title_used: usize,
    pub tools_limit: usize,
    pub tools_used: usize,
    pub stack_used: u32,
    pub physical_pages: u32,
    pub gpu_optimal_limit: usize,
    pub gpu_optimal_used: usize,
    pub tools_gpu_optimal_limit: usize,
    pub tools_gpu_optimal_used: usize,
    pub kernel_pool_used: u32,
    pub kernel_pool_limit: u32,
}

/// The title's budget and our process's commit as what it uses. No tools
/// memory: a retail console.
// shortcut: all fields are filled whatever the flags ask for, and use is
// not split by bandwidth class (GPU-optimal use reads 0); track
// allocations per class if a title budgets from that field.
pub extern "system" fn XMemGetWorkingSetStatistics(_which: u32, out: *mut WorkingSet) -> BOOL {
    if out.is_null() {
        return 0;
    }
    let mut counters = PROCESS_MEMORY_COUNTERS {
        cb: size_of::<PROCESS_MEMORY_COUNTERS>() as u32,
        ..Default::default()
    };
    // SAFETY: our own process and a sized structure.
    unsafe { K32GetProcessMemoryInfo(GetCurrentProcess(), &mut counters, counters.cb) };
    let (gpu_optimal, standard) = victory_gpu::console::current().title_memory();
    let stats = WorkingSet {
        title_limit: gpu_optimal + standard - TRANSFERRED.load(Ordering::Relaxed),
        title_used: counters.PagefileUsage,
        gpu_optimal_limit: gpu_optimal,
        ..Default::default()
    };
    // What the title is told, logged at the first asking and at every
    // 1,024th: "used" is all the process has committed, the layer's own
    // memory and the card's included (27 GB in run 60's gameplay against a
    // limit of 13.5 GB). A title that budgets its streaming from these two
    // figures believes it is far over its limit.
    // shortcut: the figure is not yet the title's own memory alone (its
    // heaps and the pages it mapped); count those if this line shows the
    // title asking.
    static ASKED: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
    let asked = ASKED.fetch_add(1, Ordering::Relaxed);
    if asked.is_multiple_of(1024) {
        tracing::info!(
            asked = asked + 1,
            which = _which,
            limit_mb = stats.title_limit >> 20,
            used_mb = stats.title_used >> 20,
            "the title asks how much memory it uses"
        );
    }
    // SAFETY: checked non-null; the title passes room for the structure.
    unsafe { out.write(stats) };
    1
}

/// Hands title memory (standard, in 2 MiB pages) to the system. The other
/// transfers involve tools memory, which a retail console has none of.
pub extern "system" fn XMemTransferMemory(kind: u32, size: usize) -> BOOL {
    const TITLE_TO_SYSTEM: u32 = 0;
    tracing::info!(kind, size, "XMemTransferMemory");
    if size == 0 {
        return 1;
    }
    let Some(size) = size.checked_next_multiple_of(2 * MIB) else {
        return 0;
    };
    let standard = victory_gpu::console::current().title_memory().1;
    let moved = kind == TITLE_TO_SYSTEM
        && TRANSFERRED
            .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |t| {
                t.checked_add(size).filter(|&t| t <= standard)
            })
            .is_ok();
    moved.into()
}

/// The title's own `VirtualFree`. What the GPU side noted of the memory goes
/// first: the address may be other memory's the moment it is free.
extern "system" fn title_virtual_free(address: *mut c_void, size: usize, kind: u32) -> BOOL {
    const MEM_COALESCE_PLACEHOLDERS: u32 = 1;
    // A lazy view there is a view to the title (whose calls on it then fail
    // as they did), not the placeholder the host has.
    materialize_for(address as usize, size, Touch::TitleCall);
    // Splitting and joining placeholders changes nothing they show.
    if kind & (MEM_PRESERVE_PLACEHOLDER | MEM_COALESCE_PLACEHOLDERS) == 0 {
        victory_gpu::title_memory_freed(address as usize, size);
    }
    // SAFETY: the title's own arguments.
    unsafe { VirtualFree(address, size, kind) }
}

/// The title's own `VirtualQuery`, while views are kept in the books alone
/// ([`soft_views`]): such a view at the address is a view to the title, not
/// the placeholder the host has.
extern "system" fn title_virtual_query(address: *const c_void, out: *mut MEMORY_BASIC_INFORMATION, size: usize) -> usize {
    use windows_sys::Win32::System::Memory::VirtualQuery;
    materialize_for(address as usize, 1, Touch::TitleCall);
    // SAFETY: the title's own arguments.
    unsafe { VirtualQuery(address, out, size) }
}

/// The title's own `VirtualProtect`, as [`title_virtual_query`].
extern "system" fn title_virtual_protect(address: *const c_void, size: usize, protect: u32, old: *mut u32) -> BOOL {
    use windows_sys::Win32::System::Memory::VirtualProtect;
    materialize_for(address as usize, size, Touch::TitleCall);
    // SAFETY: the title's own arguments.
    unsafe { VirtualProtect(address, size, protect, old) }
}

pub(crate) fn module() -> HleModule {
    // (Asked of the environment here, not of [`soft_views`], which says what
    // it does to a log that is not open yet.)
    let soft = std::env::var_os("VICTORY_SOFT_VIEWS").is_some_and(|v| v != "0");
    let asks = [
        crate::HleExport { name: "VirtualQuery", address: title_virtual_query as *const () as usize },
        crate::HleExport { name: "VirtualProtect", address: title_virtual_protect as *const () as usize },
    ];
    HleModule {
        name: "xmem",
        dlls: &["xmem.dll", "kernel32.dll", "kernelbase.dll", "api-ms-win-core-memory-*"],
        exports: soft.then_some(asks).into_iter().flatten().chain([
            crate::HleExport { name: "VirtualFree", address: title_virtual_free as *const () as usize },
            hle_export!(XMemAlloc),
            hle_export!(XMemFree),
            hle_export!(XMemAllocDefault),
            hle_export!(XMemFreeDefault),
            hle_export!(XMemIsToolsMemAvailable),
            hle_export!(XMemAllocatePhysicalPages),
            hle_export!(XMemFreePhysicalPages),
            hle_export!(XMemMapPhysicalPages),
            hle_export!(XMemMapPhysicalPagesScatter),
            hle_export!(XMemVirtualAlloc),
            hle_export!(XMemVirtualQuery),
            hle_export!(XMemGetWorkingSetStatistics),
            hle_export!(XMemTransferMemory),
        ])
        .collect(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn query(address: *const c_void) -> BasicInformation {
        // SAFETY: plain data; zero is a valid value.
        let mut info: BasicInformation = unsafe { std::mem::zeroed() };
        // SAFETY: a pseudo handle needs no closing.
        let process = unsafe { GetCurrentProcess() };
        assert_eq!(XMemVirtualQuery(process, address, &mut info), 1);
        info
    }

    #[test]
    fn alloc_honours_alignment_and_frees() {
        for (field, align) in [(0, 16), (4, 16), (0xc, 4096), (0x10, 64 * 1024)] {
            let attributes = field << ALIGNMENT_SHIFT | 1 << 29; // a graphics type
            let p = XMemAlloc(100, attributes);
            assert!(!p.is_null());
            assert_eq!(p as usize % align, 0, "field {field:#x}");
            // SAFETY: 100 bytes were allocated.
            unsafe { p.cast::<u8>().write_bytes(0xab, 100) };
            XMemFree(p, attributes);
        }
        let p = XMemAlloc(4096, ALLOC_32BIT);
        assert!(!p.is_null() && (p as usize) < 1 << 32);
        XMemFree(p, ALLOC_32BIT);
    }

    #[test]
    fn virtual_alloc_meets_console_constraints() {
        const GPU_READ_WRITE: u32 = 0x2000;
        let p = XMemVirtualAlloc(
            std::ptr::null_mut(),
            4 * MIB,
            PAGES_2M | MEM_RESERVE | MEM_COMMIT,
            GRAPHICS | 7 << 12, // 40-bit addresses
            PAGE_READWRITE | GPU_READ_WRITE,
        );
        assert!(!p.is_null());
        assert_eq!(p as usize % (2 * MIB), 0);
        assert!((p as usize) < 1 << 40);
        let info = query(p);
        assert_eq!(info.host.State, MEM_COMMIT);
        assert_eq!(info.host.Protect, PAGE_READWRITE);
        assert_eq!(info.flags & GRAPHICS, GRAPHICS);
        // Write-watched, for the GPU side's copies.
        let (mut found, mut count, mut granularity) = ([0usize; 4], 4, 0);
        // SAFETY: room for `count` addresses.
        let watched = unsafe {
            windows_sys::Win32::System::Memory::GetWriteWatch(
                0,
                p,
                4 * MIB,
                found.as_mut_ptr().cast(),
                &mut count,
                &mut granularity,
            )
        };
        assert_eq!(watched, 0);
        // SAFETY: our own reservation.
        assert_ne!(unsafe { VirtualFree(p, 0, MEM_RELEASE) }, 0);
        assert_eq!(query(p).flags, 0);
        // No address field: above the 32-bit range and below 2^40, where
        // the console keeps it.
        let p = XMemVirtualAlloc(
            std::ptr::null_mut(),
            16 << 30,
            MEM_RESERVE,
            GRAPHICS,
            PAGE_NOACCESS,
        );
        assert!(!p.is_null() && (p as usize) >= 1 << 32, "{p:p}");
        assert!((p as usize) + (16 << 30) <= 1 << 40, "{p:p}");
        // SAFETY: our own reservation.
        assert_ne!(unsafe { VirtualFree(p, 0, MEM_RELEASE) }, 0);
    }

    #[test]
    fn transfers_shrink_the_title_budget() {
        let mut before = WorkingSet::default();
        assert_eq!(XMemGetWorkingSetStatistics(0x2000_0001, &mut before), 1);
        assert!(before.title_used > 0);
        assert_eq!(XMemTransferMemory(0, 128 * MIB - 1), 1);
        assert_eq!(XMemTransferMemory(2, MIB), 0, "no tools memory");
        let standard = victory_gpu::console::current().title_memory().1;
        assert_eq!(XMemTransferMemory(0, standard), 0, "over budget");
        let mut after = WorkingSet::default();
        XMemGetWorkingSetStatistics(0x2000_0001, &mut after);
        assert_eq!(before.title_limit - after.title_limit, 128 * MIB);
    }

    #[test]
    fn statistics_have_the_console_layout() {
        assert_eq!(size_of::<WorkingSet>(), 0x50);
        assert_eq!(size_of::<BasicInformation>(), 0x40);
        assert_eq!(std::mem::offset_of!(WorkingSet, gpu_optimal_limit), 0x28);
    }

    #[test]
    fn commit_limit_report_includes_request_and_system_commit() {
        let error = std::io::Error::from_raw_os_error(ERROR_COMMITMENT_LIMIT as i32);
        let info = PERFORMANCE_INFORMATION {
            CommitTotal: 512,
            CommitLimit: 768,
            PageSize: 4096,
            ..Default::default()
        };
        let report = commit_limit_message(4 * MIB, "physical pages", &error, Some(&info));
        assert!(report.contains("4194304 bytes of physical pages"));
        assert!(report.contains("2 MiB of 3 MiB in use"));
        let fallback = commit_limit_message(4 * MIB, "virtual memory", &error, None);
        assert!(fallback.contains("4194304 bytes of virtual memory"));
        for report in [&report, &fallback] {
            assert!(report.contains("os error 1455"));
            assert!(report.contains("Windows paging file size"));
        }
        assert!(!fallback.contains("System commit:"));
    }

    #[test]
    fn the_32_bit_heap_gets_its_slices_in_address_order() {
        // As the title's heap: a 32-bit reservation of 64 KiB pages, all of
        // its pages from one call, mapped piece by piece in another order.
        // The title's own kind: reserve and 0x40000, no 64 KiB page bits.
        let base = XMemVirtualAlloc(std::ptr::null_mut(), 4 * PAGE, MEM_RESERVE | MEM_RESERVE_PLACEHOLDER, GRAPHICS | ADDRESS_32BIT, PAGE_NOACCESS);
        assert!(!base.is_null() && (base as usize) < 1 << 32);
        assert!(LOW_RESERVATIONS.lock().unwrap().iter().any(|r| r.0 == base as usize), "the reservation is known");
        let pages = allocate(4);
        let index = |number: usize| page_table().pages.get(&number).map(|s| s.index);
        let at = |page: usize| base.wrapping_byte_add(page * PAGE);
        // The last two pages' place first, from the array's start.
        arrange(at(2) as usize, &pages[..2]);
        assert_eq!(XMemMapPhysicalPages(at(2), 2, pages.as_ptr()), at(2));
        arrange(base as usize, &pages[2..]);
        assert_eq!(XMemMapPhysicalPages(base, 2, pages[2..].as_ptr()), base);
        assert_eq!([index(pages[0]), index(pages[1]), index(pages[2]), index(pages[3])], [Some(2), Some(3), Some(0), Some(1)]);
        // Mapped already: nothing moves any more.
        arrange(base as usize, &pages[..2]);
        assert_eq!(index(pages[0]), Some(2));
        // SAFETY: mapped read-write.
        unsafe { at(3).cast::<u32>().write(7) };
        assert_eq!(XMemMapPhysicalPages(base, 4, std::ptr::null()), base);
        assert_eq!(XMemFreePhysicalPages(4, pages.as_ptr()), 1);
    }

    #[test]
    fn physical_pages_map_alias_and_unmap() {
        let mut pages = [0usize; 3];
        let mut n = 3;
        assert_eq!(XMemAllocatePhysicalPages(0, &mut n, pages.as_mut_ptr()), 1);
        assert_eq!(n, 3);
        // Packed into 21 bits as `number >> 4`, as the title keeps them.
        for p in pages {
            assert_eq!((p >> 4 & 0x1f_ffff) << 4, p);
        }
        // Reservations of 64 KiB pages, as titles make them for mapping.
        let reserve = || {
            XMemVirtualAlloc(
                std::ptr::null_mut(),
                3 * PAGE,
                MEM_RESERVE | PAGES_64K,
                0,
                PAGE_READWRITE,
            )
        };
        let (a, b) = (reserve(), reserve());
        assert!(!a.is_null() && !b.is_null());
        let at = |p: *mut c_void, page: usize| p.wrapping_byte_add(page * PAGE);
        assert_eq!(XMemMapPhysicalPages(a, 3, pages.as_ptr()), a);

        // The same page at a second address shows the same bytes.
        assert_eq!(
            XMemMapPhysicalPages(at(b, 1), 1, pages[2..].as_ptr()),
            at(b, 1)
        );
        // SAFETY: both pages are mapped read-write.
        unsafe {
            at(a, 2).cast::<u8>().write(7);
            assert_eq!(at(b, 1).cast::<u8>().read(), 7);
            a.cast::<u8>().write(1);
        }
        // Writes into pages (DirectStorage's) show through their views.
        assert!(write_physical(&pages[2..], 1, &[9]));
        // SAFETY: mapped read-write.
        assert_eq!(unsafe { at(b, 1).cast::<u8>().add(1).read() }, 9);

        // Unmapping the middle page keeps its neighbours.
        assert_eq!(
            XMemMapPhysicalPages(at(a, 1), 1, std::ptr::null()),
            at(a, 1)
        );
        assert_eq!(query(at(a, 1)).host.State, MEM_RESERVE);
        assert_eq!(query(a).host.State, MEM_COMMIT);
        assert_eq!(query(at(a, 2)).host.State, MEM_COMMIT);
        // SAFETY: still mapped.
        assert_eq!(unsafe { at(a, 2).cast::<u8>().read() }, 7);

        // A scattered page lands in the hole.
        let addresses = [at(a, 1)];
        assert_eq!(
            XMemMapPhysicalPagesScatter(addresses.as_ptr(), 1, pages.as_ptr()),
            1
        );
        // SAFETY: page 0 is now mapped at both `a` and `a + PAGE`.
        assert_eq!(unsafe { at(a, 1).cast::<u8>().read() }, 1);
        // Page number 0 unmaps.
        assert_eq!(
            XMemMapPhysicalPagesScatter(addresses.as_ptr(), 1, [0usize].as_ptr()),
            1
        );
        assert_eq!(query(at(a, 1)).host.State, MEM_RESERVE);
        // The GPU's page-mapping copy: what `a + 2 pages` shows, at `b`.
        assert!(map_alias(b as u64, at(a, 2) as u64, PAGE as u64));
        // SAFETY: mapped read-write.
        assert_eq!(unsafe { b.cast::<u8>().read() }, 7);
        assert!(map_alias(b as u64, 0, PAGE as u64));
        assert_eq!(query(b).host.State, MEM_RESERVE);
        assert!(!map_alias(b as u64, at(a, 1) as u64, PAGE as u64));
        assert_eq!(XMemFreePhysicalPages(3, pages.as_ptr()), 1);
        assert_eq!(XMemIsToolsMemAvailable(), 0);
    }

    /// Lazy views (`VICTORY_LAZY_VIEWS`): mapped in the books, told of, a
    /// placeholder of their own on the host until touched; a touch (a read
    /// that faults, the GPU side's or the title's own questions) maps them,
    /// with the pages' bytes; one never touched goes with no host view, and
    /// what stays of a lazy view cut in two stays lazy.
    #[test]
    fn lazy_views_are_mapped_when_touched() {
        victory_gpu::use_lazy_views(materialize);
        let mut pages = [0usize; 3];
        let mut n = 3;
        assert_eq!(XMemAllocatePhysicalPages(0, &mut n, pages.as_mut_ptr()), 1);
        let reserve = || XMemVirtualAlloc(std::ptr::null_mut(), 3 * PAGE, MEM_RESERVE | PAGES_64K, 0, PAGE_READWRITE);
        let (a, b, c, d) = (reserve(), reserve(), reserve(), reserve());
        let at = |p: *mut c_void, page: usize| p.wrapping_byte_add(page * PAGE);
        let lazy = |p: *mut c_void| LAZY.read().unwrap().contains_key(&(p as usize));
        // What the host has there, not asking the runtime (which maps lazy views).
        let host = |p: *mut c_void| {
            use windows_sys::Win32::System::Memory::VirtualQuery;
            // SAFETY: plain data filled in by the query.
            let mut info: MEMORY_BASIC_INFORMATION = unsafe { std::mem::zeroed() };
            // SAFETY: a valid out pointer of the right size.
            unsafe { VirtualQuery(p, &mut info, size_of_val(&info)) };
            info.State
        };
        // The bytes, through a view mapped at once.
        assert_eq!(map_pages(a, 3, pages.as_ptr(), false), a);
        for k in 0..3 {
            // SAFETY: mapped read-write.
            unsafe { at(a, k).cast::<u8>().write(20 + k as u8) };
        }

        // Lazy: in the books, not on the host.
        assert_eq!(map_pages(b, 3, pages.as_ptr(), true), b);
        assert!(lazy(b));
        assert_eq!(host(b), MEM_RESERVE);
        assert_eq!(physical().views.get(&(b as usize)).map(|v| v.0), Some(3 * PAGE));
        // A read faults, and the handler maps it: the pages' bytes.
        // SAFETY: mapped in the title's eyes; the fault handler maps it.
        assert_eq!(unsafe { at(b, 1).cast::<u8>().read_volatile() }, 21);
        assert!(!lazy(b));
        assert_eq!(host(at(b, 2)), MEM_COMMIT);
        // A write through it lands in the pages.
        // SAFETY: mapped now.
        unsafe { at(b, 2).cast::<u8>().write_volatile(42) };
        // SAFETY: mapped.
        assert_eq!(unsafe { at(a, 2).cast::<u8>().read() }, 42);

        // Never touched, let go: no host view was there, and the addresses
        // take a view again.
        assert_eq!(map_pages(c, 3, pages.as_ptr(), true), c);
        assert!(lazy(c));
        assert_eq!(map_pages(c, 3, std::ptr::null(), true), c);
        assert!(!lazy(c));
        assert!(physical().views.get(&(c as usize)).is_none());
        assert_eq!(host(c), MEM_RESERVE);
        assert_eq!(map_pages(c, 3, pages.as_ptr(), false), c);
        // SAFETY: mapped.
        assert_eq!(unsafe { c.cast::<u8>().read() }, 20);

        // Cut in two: the ends stay lazy, the middle is unmapped; asked
        // through the runtime's hook, an end is mapped with its bytes.
        assert_eq!(map_pages(d, 3, pages.as_ptr(), true), d);
        assert_eq!(map_pages(at(d, 1), 1, std::ptr::null(), true), at(d, 1));
        assert!(lazy(d) && lazy(at(d, 2)));
        assert!(physical().views.get(&(at(d, 1) as usize)).is_none());
        assert!(materialize(at(d, 2) as usize, 1));
        assert!(!lazy(at(d, 2)) && lazy(d));
        // SAFETY: mapped now.
        assert_eq!(unsafe { at(d, 2).cast::<u8>().read() }, 42);
        assert_eq!(host(at(d, 1)), MEM_RESERVE);
        // The title's question about a lazy view: committed memory.
        // SAFETY: room for the answer.
        let mut info: BasicInformation = unsafe { std::mem::zeroed() };
        // SAFETY: as above.
        assert_eq!(XMemVirtualQuery(unsafe { GetCurrentProcess() }, d, &mut info), 1);
        assert_eq!(info.host.State, MEM_COMMIT);
        assert!(!lazy(d));
        // Nothing lazy there: the hook says so.
        assert!(!materialize(d as usize, PAGE));

        for p in [a, b, c, d] {
            map_pages(p, 3, std::ptr::null(), true);
        }
        assert_eq!(XMemFreePhysicalPages(3, pages.as_ptr()), 1);
    }

    /// Views kept in the books alone (`VICTORY_SOFT_VIEWS`), the title's own
    /// and the page-mapping copies': the host has a placeholder, the GPU
    /// side's reads take the bytes from the pages and are told where such
    /// views are; mapped anew or unmapped they change with no view of the
    /// host's; a touch of the CPU's maps one with its pages' bytes, and it is
    /// a view as any other from then on.
    #[test]
    fn views_in_the_books_alone_are_read_from_their_pages() {
        use_soft_views();
        let counted = |what: Soft| SOFT_N[what as usize].load(Ordering::Relaxed);
        let before = [Soft::Noted, Soft::NotedPool, Soft::NotedCopies, Soft::Gone, Soft::Real, Soft::FaultOther, Soft::Reads].map(counted);
        let mut pages = [0usize; 4];
        let mut n = 4;
        assert_eq!(XMemAllocatePhysicalPages(0, &mut n, pages.as_mut_ptr()), 1);
        let reserve = || XMemVirtualAlloc(std::ptr::null_mut(), 4 * PAGE, MEM_RESERVE | PAGES_64K, 0, PAGE_READWRITE) as usize;
        let (pool, heap) = (reserve(), reserve());
        let lazy = |at: usize| LAZY.read().unwrap().contains_key(&at);
        // What the host has there, not asking the runtime.
        let host = |at: usize| {
            use windows_sys::Win32::System::Memory::VirtualQuery;
            // SAFETY: plain data filled in by the query.
            let mut info: MEMORY_BASIC_INFORMATION = unsafe { std::mem::zeroed() };
            // SAFETY: a valid out pointer of the right size.
            unsafe { VirtualQuery(at as *const c_void, &mut info, size_of_val(&info)) };
            info.State
        };
        let read = |at: usize, len: usize| {
            let mut out = vec![0xeeu8; len];
            let answer = soft_read(at, out.as_mut_ptr(), len);
            (answer, out)
        };
        let alias = |to: usize, from: usize| alias_as(to as u64, from as u64, PAGE as u64, false, true);
        // The title maps its pool a call a page, DirectStorage fills the
        // pages by number, and the GPU maps them into the heap out of order.
        for k in 0..4 {
            assert_eq!(map_pages((pool + k * PAGE) as *mut c_void, 1, pages[k..].as_ptr(), true) as usize, pool + k * PAGE);
            assert!(write_physical(&pages[k..k + 1], 0, &vec![k as u8 + 1; PAGE]));
        }
        for (to, from) in [(0, 2), (1, 0), (2, 3)] {
            assert!(alias(heap + to * PAGE, pool + from * PAGE));
        }
        for k in 0..4 {
            assert!(lazy(pool + k * PAGE));
            assert_eq!(host(pool + k * PAGE), MEM_RESERVE);
            assert_eq!(lazy(heap + k * PAGE), k < 3);
            assert_eq!(host(heap + k * PAGE), MEM_RESERVE);
        }
        // Where such views are: those that touch as one, cut to the range.
        assert_eq!(soft_runs(heap, 4 * PAGE), [(heap, 3 * PAGE)]);
        assert_eq!(soft_runs(heap + PAGE / 2, PAGE), [(heap + PAGE / 2, PAGE)]);
        assert!(soft_runs(heap + 3 * PAGE, PAGE).is_empty());
        // Their bytes, a view at a time; from inside one, to its end.
        for (k, byte) in [(0, 3), (1, 1), (2, 4)] {
            let ((from_pages, n), out) = read(heap + k * PAGE, 3 * PAGE);
            assert!(from_pages);
            assert_eq!(n, PAGE);
            assert!(out[..PAGE].iter().all(|&b| b == byte) && out[PAGE..].iter().all(|&b| b == 0xee), "page {k}");
        }
        let (answer, out) = read(heap + PAGE - 4, 8);
        assert_eq!((answer, &out[..]), ((true, 4), &[3, 3, 3, 3, 0xee, 0xee, 0xee, 0xee][..]));
        // No such view there: as much as was asked (or up to the next one,
        // below).
        assert_eq!(read(heap + 3 * PAGE, PAGE).0, (false, PAGE));
        // None of that made a view of the host's.
        assert!((0..3).all(|k| lazy(heap + k * PAGE) && host(heap + k * PAGE) == MEM_RESERVE));
        // Mapped anew in the books: the other page's bytes.
        assert!(alias(heap, pool + PAGE));
        assert!(lazy(heap) && host(heap) == MEM_RESERVE);
        assert_eq!(read(heap, 1), ((true, 1), vec![2]));
        // Unmapped: gone, with no view of the host's ever there.
        assert!(alias_as((heap + PAGE) as u64, 0, PAGE as u64, false, true));
        assert!(!lazy(heap + PAGE) && physical().views.get(&(heap + PAGE)).is_none());
        assert_eq!(soft_runs(heap, 4 * PAGE), [(heap, PAGE), (heap + 2 * PAGE, PAGE)]);
        assert_eq!(read(heap + PAGE, 2 * PAGE).0, (false, PAGE));
        // The CPU touches one: the handler maps it with its page's bytes,
        // and a write through it lands in the page, which the pool's view of
        // it (in the books still) shows.
        // SAFETY: mapped in the title's eyes; the fault handler maps it.
        assert_eq!(unsafe { ((heap + 2 * PAGE) as *const u8).read_volatile() }, 4);
        assert!(!lazy(heap + 2 * PAGE));
        assert_eq!(host(heap + 2 * PAGE), MEM_COMMIT);
        // SAFETY: mapped now.
        unsafe { ((heap + 2 * PAGE) as *mut u8).write_volatile(77) };
        assert_eq!(read(pool + 3 * PAGE, 2), ((true, 2), vec![77, 4]));
        assert_eq!(read(heap + 2 * PAGE, 1).0, (false, 1));
        // The pool lets go of the page: the heap keeps showing it.
        assert_eq!(map_pages((pool + 3 * PAGE) as *mut c_void, 1, std::ptr::null(), true) as usize, pool + 3 * PAGE);
        assert!(!lazy(pool + 3 * PAGE));
        // SAFETY: mapped.
        assert_eq!(unsafe { ((heap + 2 * PAGE) as *const u8).read_volatile() }, 77);
        // Counted (other tests count too: at least these).
        let after = [Soft::Noted, Soft::NotedPool, Soft::NotedCopies, Soft::Gone, Soft::Real, Soft::FaultOther, Soft::Reads].map(counted);
        for (i, least) in [8, 4, 4, 3, 1, 1, 6].into_iter().enumerate() {
            assert!(after[i] - before[i] >= least, "count {i}: {} to {}", before[i], after[i]);
        }
        let line = soft_line(&mut ([0; SOFT_FIELDS], [0; 2]), 10).expect("something to say");
        assert!(line.contains("noted with no view of the host's") && line.contains("by a fault of other code (the last at"), "{line}");
        assert!(alias_as(heap as u64, 0, 4 * PAGE as u64, false, true));
        map_pages(pool as *mut c_void, 4, std::ptr::null(), true);
        assert_eq!(host(heap + 2 * PAGE), MEM_RESERVE);
        assert_eq!(XMemFreePhysicalPages(4, pages.as_ptr()), 1);
    }

    /// A reader of title memory in place (holding the runtime's reading
    /// lock, as the GPU side's texture refresh does) that faults into a lazy
    /// view gets it mapped while a mapping call waits for that lock: the
    /// call takes the lock before the views, so neither waits for the other
    /// for good.
    #[test]
    fn a_reader_in_place_faults_into_a_lazy_view_while_a_mapping_waits() {
        victory_gpu::use_lazy_views(materialize);
        let mut pages = [0usize; 2];
        let mut n = 2;
        assert_eq!(XMemAllocatePhysicalPages(0, &mut n, pages.as_mut_ptr()), 1);
        let reserve = || XMemVirtualAlloc(std::ptr::null_mut(), 2 * PAGE, MEM_RESERVE | PAGES_64K, 0, PAGE_READWRITE) as usize;
        let (a, b, c) = (reserve(), reserve(), reserve());
        assert_eq!(map_pages(a as *mut c_void, 2, pages.as_ptr(), false) as usize, a);
        // SAFETY: mapped read-write.
        unsafe { (a as *mut u8).write(9) };
        assert_eq!(map_pages(b as *mut c_void, 2, pages.as_ptr(), true) as usize, b);
        let (reading, read) = (std::sync::Barrier::new(2), std::sync::atomic::AtomicU8::new(0));
        std::thread::scope(|scope| {
            scope.spawn(|| {
                let _reading = victory_gpu::title_memory_reading();
                reading.wait();
                // Let the mapping call below begin to wait for the lock.
                std::thread::sleep(std::time::Duration::from_millis(50));
                // SAFETY: mapped in the title's eyes; the fault handler maps it.
                read.store(unsafe { (b as *const u8).read_volatile() }, std::sync::atomic::Ordering::Relaxed);
            });
            reading.wait();
            assert_eq!(map_pages(c as *mut c_void, 2, pages.as_ptr(), true) as usize, c);
        });
        assert_eq!(read.load(std::sync::atomic::Ordering::Relaxed), 9);
        for p in [a, b, c] {
            map_pages(p as *mut c_void, 2, std::ptr::null(), true);
        }
        assert_eq!(XMemFreePhysicalPages(2, pages.as_ptr()), 1);
    }

    /// A page-mapping copy of pages that are consecutive pages of one
    /// allocation shows the same bytes through one view as through a view a
    /// page, and a single page of it unmapped later leaves the others.
    #[test]
    fn a_copy_of_consecutive_pages_shows_them_through_one_view() {
        let mut pages = [0usize; 4];
        let mut n = 4;
        assert_eq!(XMemAllocatePhysicalPages(0, &mut n, pages.as_mut_ptr()), 1);
        let reserve = || XMemVirtualAlloc(std::ptr::null_mut(), 4 * PAGE, MEM_RESERVE | PAGES_64K, 0, PAGE_READWRITE);
        let (a, b, c) = (reserve(), reserve(), reserve());
        let at = |p: *mut c_void, page: usize| p.wrapping_byte_add(page * PAGE);
        // Pages 0-2 in one call and page 3 in another: still one run of
        // four consecutive section pages.
        let order = [pages[0], pages[1], pages[2]];
        assert_eq!(XMemMapPhysicalPages(a, 3, order.as_ptr()), a);
        assert_eq!(XMemMapPhysicalPages(at(a, 3), 1, pages[3..].as_ptr()), at(a, 3));
        for k in 0..4 {
            // SAFETY: mapped read-write.
            unsafe { at(a, k).cast::<u8>().write(10 + k as u8) };
        }
        let runs = {
            let physical = physical();
            let slices: Vec<Slice> = (0..4).map(|k| physical.slice_at(at(a, k) as usize).unwrap()).collect();
            runs_of(&slices)
        };
        assert_eq!(runs, vec![4]);
        for (to, in_one) in [(b, false), (c, true)] {
            assert!(alias_as(to as u64, a as u64, 4 * PAGE as u64, in_one, false));
            for k in 0..4 {
                // SAFETY: mapped read-write.
                assert_eq!(unsafe { at(to, k).cast::<u8>().read() }, 10 + k as u8);
            }
        }
        assert_eq!(physical().views.get(&(c as usize)).map(|v| v.0), Some(4 * PAGE));
        assert_eq!(physical().views.get(&(b as usize)).map(|v| v.0), Some(PAGE));
        // Mapped again in one view where four views of a page were: their
        // holes are joined into one placeholder.
        assert!(alias_as(b as u64, a as u64, 4 * PAGE as u64, true, false));
        assert_eq!(physical().views.get(&(b as usize)).map(|v| v.0), Some(4 * PAGE));
        for k in 0..4 {
            // SAFETY: mapped read-write.
            assert_eq!(unsafe { at(b, k).cast::<u8>().read() }, 10 + k as u8);
        }
        // One page of the run unmapped: the rest stay, with their bytes.
        assert!(map_alias(at(c, 1) as u64, 0, PAGE as u64));
        assert_eq!(query(at(c, 1)).host.State, MEM_RESERVE);
        for k in [0, 2, 3] {
            // SAFETY: still mapped.
            assert_eq!(unsafe { at(c, k).cast::<u8>().read() }, 10 + k as u8);
        }
        // A source page not mapped: the pages before it are mapped all the same.
        assert!(XMemMapPhysicalPages(at(a, 2), 1, std::ptr::null()) == at(a, 2));
        assert!(!alias_as(c as u64, a as u64, 4 * PAGE as u64, true, false));
        // SAFETY: mapped.
        assert_eq!(unsafe { at(c, 1).cast::<u8>().read() }, 11);
        assert_eq!(query(at(c, 2)).host.State, MEM_RESERVE);
        for p in [a, b, c] {
            XMemMapPhysicalPages(p, 4, std::ptr::null());
        }
        assert_eq!(XMemFreePhysicalPages(4, pages.as_ptr()), 1);
    }

    /// A thread that reads a mapped page in place, as the GPU side reads a
    /// texture, never meets the moment in which the runtime has taken the
    /// page's view away to map it again: mapping the same pages at the same
    /// address unmaps the view and maps a new one, and without the lock the
    /// reader faults on a page "reserved, never committed" (the crashes of
    /// runs 71 and 74).
    #[test]
    fn a_read_in_place_never_meets_the_gap_of_a_remapping() {
        use std::sync::atomic::{AtomicBool, Ordering};
        let mut pages = [0usize; 3];
        let mut n = 3;
        assert_eq!(XMemAllocatePhysicalPages(0, &mut n, pages.as_mut_ptr()), 1);
        let a = XMemVirtualAlloc(
            std::ptr::null_mut(),
            3 * PAGE,
            MEM_RESERVE | PAGES_64K,
            0,
            PAGE_READWRITE,
        );
        assert!(!a.is_null());
        assert_eq!(XMemMapPhysicalPages(a, 3, pages.as_ptr()), a);
        // SAFETY: mapped read-write.
        unsafe { a.cast::<u8>().write(1) };
        let first = a as usize;
        let stop = std::sync::Arc::new(AtomicBool::new(false));
        let reader = {
            let stop = stop.clone();
            std::thread::spawn(move || {
                let mut reads = 0u64;
                // (Once at least: the mapping thread may be done before this
                // one's first turn.)
                while reads == 0 || !stop.load(Ordering::Relaxed) {
                    let _reading = victory_gpu::title_memory_reading();
                    // SAFETY: the page is mapped whenever no change of
                    // mapping is under way, and none is while `_reading`
                    // is held.
                    assert_eq!(unsafe { (first as *const u8).read_volatile() }, 1);
                    reads += 1;
                }
                reads
            })
        };
        for _ in 0..2000 {
            // The same pages at the same address: the view goes and comes
            // back, with the same bytes.
            assert_eq!(XMemMapPhysicalPages(a, 3, pages.as_ptr()), a);
        }
        stop.store(true, Ordering::Relaxed);
        assert!(reader.join().expect("the reader never faulted") > 0);
        assert_eq!(XMemMapPhysicalPages(a, 3, std::ptr::null()), a);
        assert_eq!(XMemFreePhysicalPages(3, pages.as_ptr()), 1);
    }

    /// A title thread that reads and writes a page of a view while other
    /// pages of the view are unmapped and mapped again, as the console lets
    /// it: the page was never given up.
    #[test]
    fn a_title_thread_goes_on_using_the_rest_of_a_view() {
        use std::sync::atomic::{AtomicBool, Ordering};
        let pages = allocate(4);
        for _ in 0..200 {
            // A new reservation each time: the pieces of a view cut up stay
            // cut up.
            let a = XMemVirtualAlloc(
                std::ptr::null_mut(),
                4 * PAGE,
                MEM_RESERVE | PAGES_64K,
                0,
                PAGE_READWRITE,
            );
            assert!(!a.is_null());
            assert_eq!(XMemMapPhysicalPages(a, 4, pages.as_ptr()), a);
            let (first, stop) = (a as usize, AtomicBool::new(false));
            // SAFETY: mapped read-write.
            unsafe { (first as *mut u64).write_volatile(0) };
            std::thread::scope(|s| {
                let title = s.spawn(|| {
                    let mut n = 0u64;
                    // SAFETY (the block): the first page is the title's all
                    // the time; a fault would end the process.
                    unsafe {
                        while !stop.load(Ordering::Relaxed) {
                            assert_eq!((first as *const u64).read_volatile(), n);
                            n += 1;
                            (first as *mut u64).write_volatile(n);
                        }
                    }
                    n
                });
                // SAFETY: as above.
                while !title.is_finished() && unsafe { (first as *const u64).read_volatile() } < 100 {}
                for page in [3, 2, 1] {
                    let at = a.wrapping_byte_add(page * PAGE);
                    assert_eq!(XMemMapPhysicalPages(at, 1, std::ptr::null()), at);
                    assert_eq!(XMemMapPhysicalPages(at, 1, pages[page..].as_ptr()), at);
                }
                stop.store(true, Ordering::Relaxed);
                assert!(title.join().expect("the title's thread never faulted") > 0);
            });
            assert_eq!(XMemMapPhysicalPages(a, 4, std::ptr::null()), a);
        }
        assert_eq!(XMemFreePhysicalPages(4, pages.as_ptr()), 1);
    }

    /// Many pages in one call: mapped, moved over each other's addresses,
    /// given twice in one list, copied by the GPU's mappings and unmapped.
    #[test]
    fn a_scatter_of_many_pages_is_what_one_after_the_other_is() {
        const N: usize = 200;
        let pages = allocate(N);
        let a = XMemVirtualAlloc(std::ptr::null_mut(), 2 * N * PAGE, MEM_RESERVE | PAGES_64K, 0, PAGE_READWRITE) as usize;
        let at = |k: usize| (a + k * PAGE) as *mut c_void;
        let first = |k: usize| at(k).cast::<u64>();
        for round in 0..4_usize {
            // Every address shows another page each round.
            let to: Vec<*mut c_void> = (0..N).map(|i| at((i + 7 * round) % N)).collect();
            assert_eq!(XMemMapPhysicalPagesScatter(to.as_ptr(), N, pages.as_ptr()), 1);
            for i in 0..N {
                // SAFETY: mapped read-write.
                unsafe {
                    if round > 0 {
                        assert_eq!(first((i + 7 * round) % N).read(), (1000 * (round - 1) + i) as u64);
                    }
                    first((i + 7 * round) % N).write((1000 * round + i) as u64);
                }
            }
        }
        // The GPU's copies of the mappings, in ranges and one by one; a page
        // mapped from one the same call has mapped shows the same.
        let half = (N / 2 * PAGE) as u64;
        let (from, to) = (a as u64, at(N) as u64);
        assert!(map_aliases(&[(to, from, half), (to + half, to, half)]));
        for k in 0..N / 2 {
            // SAFETY: mapped read-write.
            unsafe {
                assert_eq!(first(N + k).read(), first(k).read());
                assert_eq!(first(N + N / 2 + k).read(), first(k).read());
                first(N + k).write(5);
                assert_eq!(first(k).read(), 5);
            }
        }
        // An address twice: the last one counts; page 0 unmaps.
        let to = [at(0), at(1), at(0), at(2), at(3), at(0)];
        let what = [pages[5], pages[6], 0, 0, pages[7], pages[8]];
        assert_eq!(XMemMapPhysicalPagesScatter(to.as_ptr(), 6, what.as_ptr()), 1);
        assert_eq!(query(at(2)).host.State, MEM_RESERVE);
        // SAFETY: mapped read-write; the same page at both.
        unsafe {
            first(0).write(77);
            assert_eq!(XMemMapPhysicalPagesScatter([at(2), at(4), at(6)].as_ptr(), 3, [pages[8]; 3].as_ptr()), 1);
            assert_eq!((first(2).read(), first(4).read(), first(6).read()), (77, 77, 77));
        }
        // A page the title does not own.
        assert_eq!(XMemMapPhysicalPagesScatter([at(0), at(1)].as_ptr(), 2, [pages[0], 1].as_ptr()), 0);
        // All gone, also parts of a larger view.
        assert_eq!(XMemMapPhysicalPages(at(0), 4, std::ptr::null()), at(0));
        // SAFETY: placeholders of ours, nothing mapped in them.
        unsafe { VirtualFree(at(0), 4 * PAGE, MEM_RELEASE | 1 /* MEM_COALESCE_PLACEHOLDERS */) };
        assert_eq!(XMemMapPhysicalPages(at(0), 4, pages.as_ptr()), at(0));
        assert!(map_aliases(&[(a as u64, 0, (2 * N * PAGE) as u64)]));
        assert!((0..2 * N).all(|k| query(at(k)).host.State == MEM_RESERVE));
        assert!(physical().views.range(a..a + 2 * N * PAGE).next().is_none());
        assert_eq!(XMemFreePhysicalPages(N, pages.as_ptr()), 1);
    }

    /// Pages keep what they hold however often they are mapped, moved and
    /// unmapped without a commit or a split of their own.
    #[test]
    fn pages_mapped_again_hold_what_they_held() {
        let pages = allocate(3);
        let a = XMemVirtualAlloc(std::ptr::null_mut(), 8 * PAGE, MEM_RESERVE | PAGES_64K, 0, PAGE_READWRITE);
        assert!(!a.is_null());
        let at = |k: usize| a.wrapping_byte_add(k * PAGE);
        for round in 0..6_usize {
            for (k, page) in pages.iter().enumerate() {
                let to = at((round + 2 * k) % 8);
                assert_eq!(XMemMapPhysicalPages(to, 1, page), to);
                let first = to.cast::<u64>();
                // SAFETY: mapped read-write; the far end of the page too.
                unsafe {
                    if round > 0 {
                        assert_eq!(first.read(), (round * 16 + k - 16) as u64);
                        assert_eq!(first.add(PAGE / 8 - 1).read(), k as u64);
                    }
                    first.write((round * 16 + k) as u64);
                    first.add(PAGE / 8 - 1).write(k as u64);
                }
            }
            for k in 0..pages.len() {
                let to = at((round + 2 * k) % 8);
                assert_eq!(XMemMapPhysicalPages(to, 1, std::ptr::null()), to);
                assert_eq!(query(to).host.State, MEM_RESERVE);
            }
            // The title joins what it unmapped: the next view splits it anew.
            if round == 3 {
                // SAFETY: placeholders of ours, nothing mapped in them.
                unsafe {
                    VirtualFree(a, 8 * PAGE, MEM_RELEASE | 1 /* MEM_COALESCE_PLACEHOLDERS */)
                };
            }
        }
        assert_eq!(XMemFreePhysicalPages(3, pages.as_ptr()), 1);
    }

    #[test]
    fn mapping_no_pages_changes_nothing() {
        let pages = allocate(2);
        let a = XMemVirtualAlloc(
            std::ptr::null_mut(),
            2 * PAGE,
            MEM_RESERVE | PAGES_64K,
            0,
            PAGE_READWRITE,
        );
        assert!(!a.is_null());
        assert_eq!(XMemMapPhysicalPages(a, 2, pages.as_ptr()), a);
        // SAFETY: both pages are mapped read-write.
        unsafe { a.cast::<u8>().write(5) };
        let second = a.wrapping_byte_add(PAGE);

        // A count of 0 at the start of a view, inside it and past it: with
        // pages, without (an unmap), and as the GPU's page-mapping copy.
        for at in [a, second, a.wrapping_byte_add(2 * PAGE)] {
            assert_eq!(XMemMapPhysicalPages(at, 0, pages.as_ptr()), at);
            assert_eq!(XMemMapPhysicalPages(at, 0, std::ptr::null()), at);
            assert!(map_alias(at as u64, a as u64, 0));
            assert!(map_alias(at as u64, 0, 0));
        }

        // The view is still the one view it was.
        let view = physical().views.get(&(a as usize)).map(|v| v.0);
        assert_eq!(view, Some(2 * PAGE));
        assert_eq!(query(a).host.State, MEM_COMMIT);
        assert_eq!(query(second).host.State, MEM_COMMIT);
        // SAFETY: still mapped.
        assert_eq!(unsafe { a.cast::<u8>().read() }, 5);

        // A count of 1 still unmaps that page alone.
        assert_eq!(XMemMapPhysicalPages(second, 1, std::ptr::null()), second);
        assert_eq!(query(second).host.State, MEM_RESERVE);
        assert_eq!(query(a).host.State, MEM_COMMIT);
        assert_eq!(XMemMapPhysicalPages(a, 1, std::ptr::null()), a);
        assert_eq!(XMemFreePhysicalPages(2, pages.as_ptr()), 1);
    }

    /// What a title that maps and unmaps pages all the time costs the
    /// workers that write others: 24 threads look pages up, fill one and
    /// tell of it, as a request does, while one maps.
    /// `cargo test --release -p victory-hle --lib map_bench -- --ignored --nocapture`
    #[test]
    #[ignore = "a benchmark"]
    fn map_bench() {
        use std::sync::atomic::AtomicU64;
        use std::time::{Duration, Instant};
        let pages = allocate(1024);
        let a = XMemVirtualAlloc(std::ptr::null_mut(), 1024 * PAGE, MEM_RESERVE | PAGES_64K, 0, PAGE_READWRITE) as usize;
        for mapping in [false, true] {
            let (done, waited, worst, maps) =
                (AtomicU64::new(0), AtomicU64::new(0), AtomicU64::new(0), AtomicU64::new(0));
            let until = Instant::now() + Duration::from_secs(3);
            std::thread::scope(|s| {
                if mapping {
                    s.spawn(|| {
                        let at: Vec<*mut c_void> = (0..256).map(|i| (a + i * PAGE) as *mut c_void).collect();
                        while Instant::now() < until {
                            assert_eq!(XMemMapPhysicalPagesScatter(at.as_ptr(), 256, pages.as_ptr()), 1);
                            assert_eq!(XMemMapPhysicalPagesScatter(at.as_ptr(), 256, std::ptr::null()), 1);
                            maps.fetch_add(512, Ordering::Relaxed);
                        }
                    });
                }
                for t in 0..24 {
                    let (pages, done, waited, worst) = (&pages, &done, &waited, &worst);
                    s.spawn(move || {
                        let mut i = 256 + t * 16;
                        while Instant::now() < until {
                            let page = &pages[i..=i];
                            i = if i == 256 + t * 16 + 15 { 256 + t * 16 } else { i + 1 };
                            let began = Instant::now();
                            assert!(pages_known(page, 0, PAGE));
                            let mut window = page_window(page, 0, PAGE).unwrap();
                            let looked = began.elapsed();
                            window.bytes().fill(t as u8);
                            let began = Instant::now();
                            pages_written(page, 0, PAGE);
                            let took = (looked + began.elapsed()).as_nanos() as u64;
                            waited.fetch_add(took, Ordering::Relaxed);
                            worst.fetch_max(took, Ordering::Relaxed);
                            done.fetch_add(1, Ordering::Relaxed);
                        }
                    });
                }
            });
            let n = done.load(Ordering::Relaxed).max(1);
            println!(
                "mapping {mapping}: {:.0} requests/s, {:.1} us of each on lookups and notices (worst {:.1} ms); {:.0} maps/s",
                n as f64 / 3.0,
                waited.load(Ordering::Relaxed) as f64 / n as f64 / 1e3,
                worst.load(Ordering::Relaxed) as f64 / 1e6,
                maps.load(Ordering::Relaxed) as f64 / 3.0
            );
        }
        assert_eq!(XMemFreePhysicalPages(1024, pages.as_ptr()), 1);
    }

    /// `n` pages of one new allocation.
    fn allocate(n: usize) -> Vec<usize> {
        let (mut pages, mut given) = (vec![0; n], n);
        assert_eq!(
            XMemAllocatePhysicalPages(0, &mut given, pages.as_mut_ptr()),
            1
        );
        assert_eq!(given, n);
        pages
    }

    /// The bytes of one page, through a view of our own.
    fn page_bytes(page: usize) -> Vec<u8> {
        let slice = page_table().pages.get(&page).cloned().expect("known page");
        View::map(&slice, 1).expect("mapped").bytes().to_vec()
    }

    #[test]
    fn runs_group_consecutive_pages_of_one_allocation() {
        let (a, b) = (allocate(3), allocate(1));
        let lengths = |pages: &[usize], offset, len| {
            runs(pages, offset, len).map(|r| r.iter().map(|&(_, n)| n).collect::<Vec<_>>())
        };
        assert_eq!(lengths(&a, 0, 3 * PAGE), Some(vec![3]));
        // Only the pages the bytes reach.
        assert_eq!(lengths(&a, PAGE + 5, 10), Some(vec![1]));
        assert_eq!(lengths(&a, PAGE - 1, 2), Some(vec![2]));
        assert_eq!(lengths(&a, 0, 0), Some(vec![]));
        // Out of order, or across allocations: one run each.
        assert_eq!(
            lengths(&[a[0], a[2], a[1]], 0, 3 * PAGE),
            Some(vec![1, 1, 1])
        );
        assert_eq!(lengths(&[a[1], a[2], b[0]], 0, 3 * PAGE), Some(vec![2, 1]));
        // A slice that follows on in another section starts a run.
        assert_eq!(lengths(&[b[0], a[1]], 0, 2 * PAGE), Some(vec![1, 1]));
        // Too few pages for the bytes, or an unknown one.
        assert_eq!(lengths(&a, 0, 3 * PAGE + 1), None);
        assert_eq!(lengths(&[a[0], 0x10], 0, 2 * PAGE), None);
        assert_eq!(lengths(&a, usize::MAX, 2), None);
        assert_eq!(XMemFreePhysicalPages(3, a.as_ptr()), 1);
        assert_eq!(XMemFreePhysicalPages(1, b.as_ptr()), 1);
    }

    #[test]
    fn writes_cross_runs_and_allocations() {
        let (a, b) = (allocate(2), allocate(1));
        let pages = [a[0], a[1], b[0]];
        let data: Vec<u8> = (0..2 * PAGE + 64).map(|i| (i * 7 % 251) as u8).collect();
        let offset = PAGE - 32;
        // Past the third page: the second run is too short.
        assert!(!write_physical(&pages, offset, &data));
        assert!(write_physical(&pages, offset, &data[..2 * PAGE]));
        let seen: Vec<u8> = pages.iter().flat_map(|&p| page_bytes(p)).collect();
        assert!(seen[..offset].iter().all(|&b| b == 0), "before the offset");
        assert_eq!(seen[offset..offset + 2 * PAGE], data[..2 * PAGE]);
        assert!(seen[offset + 2 * PAGE..].iter().all(|&b| b == 0), "after");
        assert!(
            !write_physical(&[a[0], 0x10], 0, &data[..PAGE + 1]),
            "unknown page"
        );
        assert_eq!(XMemFreePhysicalPages(2, a.as_ptr()), 1);
        assert_eq!(XMemFreePhysicalPages(1, b.as_ptr()), 1);
    }

    /// Pages say where the title has them mapped, byte for byte (after
    /// fork PR #571's test; its runs are whole pages).
    #[test]
    fn pages_say_where_they_are_mapped() {
        let pages = allocate(3);
        let reserve = |n: usize| {
            let at = XMemVirtualAlloc(std::ptr::null_mut(), n * PAGE, MEM_RESERVE | PAGES_64K, 0, PAGE_READWRITE);
            assert!(!at.is_null());
            at
        };
        // `b` keeps a page unmapped at either end, so that no run at `b`
        // ever touches one at `a`, wherever the host puts the two.
        let (a, b) = (reserve(3), reserve(4));
        assert!(shown_at(&pages, 0, 3 * PAGE).is_empty(), "mapped nowhere");
        // All three at `a`; the last two at `b`, from its second page on.
        assert_eq!(XMemMapPhysicalPages(a, 3, pages.as_ptr()), a);
        let second = b.wrapping_byte_add(PAGE);
        assert_eq!(XMemMapPhysicalPages(second, 2, pages[1..].as_ptr()), second);
        let (a, second) = (a as usize, second as usize);
        let sorted = |mut runs: Vec<(usize, usize)>| {
            runs.sort_unstable();
            runs
        };
        assert_eq!(shown_at(&pages, 0, PAGE), vec![(a, PAGE)]);
        // A request for part of a page names those bytes alone.
        assert_eq!(shown_at(&pages, 0x4000, 0x3000), vec![(a + 0x4000, 0x3000)]);
        // Across two pages, shown at two addresses each: one run at each.
        assert_eq!(
            shown_at(&pages, PAGE + 1, PAGE),
            sorted(vec![(a + PAGE + 1, PAGE), (second + 1, PAGE)])
        );
        // A page unmapped in the middle of a view: the rest still shows.
        let middle = (a + PAGE) as *mut c_void;
        assert_eq!(XMemMapPhysicalPages(middle, 1, std::ptr::null()), middle);
        assert_eq!(
            shown_at(&pages, 0, 3 * PAGE),
            sorted(vec![(a, PAGE), (a + 2 * PAGE, PAGE), (second, 2 * PAGE)])
        );
        // Too few pages for the bytes: nothing (the write fails too).
        assert!(shown_at(&pages, 0, 3 * PAGE + 1).is_empty());
        for (at, n) in [(a, 3), (second, 2)] {
            let at = at as *mut c_void;
            assert_eq!(XMemMapPhysicalPages(at, n, std::ptr::null()), at);
        }
        assert!(shown_at(&pages, 0, 3 * PAGE).is_empty());
        assert_eq!(XMemFreePhysicalPages(3, pages.as_ptr()), 1);
    }

    #[test]
    fn mapping_is_busy_from_a_quarter_of_the_time_to_a_twentieth() {
        let ms = std::time::Duration::from_millis;
        assert!(!busy_after(false, ms(60), ms(250)) && busy_after(false, ms(70), ms(250)));
        assert!(busy_after(true, ms(15), ms(250)) && !busy_after(true, ms(12), ms(250)));
        // A window without a call, then one short one.
        assert!(!busy_after(true, ms(5), ms(4000)));
    }

    #[test]
    fn page_windows_cover_one_run_in_place() {
        let (a, b) = (allocate(3), allocate(1));
        let mut window = page_window(&a, PAGE + 3, PAGE).expect("one run");
        assert_eq!(window.bytes().len(), PAGE);
        window.bytes().fill(0x5a);
        drop(window);
        let (second, third) = (page_bytes(a[1]), page_bytes(a[2]));
        assert!(second[..3].iter().all(|&b| b == 0));
        assert!(second[3..].iter().all(|&b| b == 0x5a));
        assert!(third[..3].iter().all(|&b| b == 0x5a));
        assert!(third[3..].iter().all(|&b| b == 0));
        // Several runs, or an unknown page: no window.
        assert!(page_window(&[a[0], b[0]], 0, PAGE + 1).is_none());
        assert!(page_window(&[a[1], a[0]], 0, PAGE + 1).is_none());
        assert!(page_window(&[0x10], 0, 1).is_none());
        // One page of several is still one run.
        assert!(page_window(&[a[0], b[0]], 0, PAGE).is_some());
        assert_eq!(XMemFreePhysicalPages(3, a.as_ptr()), 1);
        assert_eq!(XMemFreePhysicalPages(1, b.as_ptr()), 1);
    }
}
