//! The load pack (`VICTORY_LOAD_PACK=<folder>`): the bytes a launch reads
//! from the title's package, kept in one file in the order they were first
//! read, so the next launch reads them in one sweep instead of a seek each.
//!
//! The package may sit on a hard disk, where a read at a random place costs
//! a seek (5-16 ms: 60-400 reads a second however many run at once), while
//! one front to back runs at the disk's full speed. The title's loading
//! screen reads many thousands of scattered pieces of its packages and
//! waits on them. Every read of a package file (DirectStorage requests and
//! the title's own `ReadFile`s) is looked up here: one the pack holds is
//! read from the pack, which a thread reads front to back a little ahead of
//! what has been asked for, so the reads come out of the host's file cache;
//! one it does not hold is read from the file as before, and its bytes are
//! added at the pack's end, for the next launch.
//!
//! `pack.bin` holds the bytes; `pack.idx` lists the files (`F id size time
//! path`) and the pieces (`E id offset length at`). A file whose size or
//! time changed is a new file to the pack; the old one's pieces are left
//! unused. `VICTORY_LOAD_PACK_GB` caps the pack (default 32);
//! `VICTORY_LOAD_PACK_ADD=0` reads from it without adding.

use std::collections::{BTreeMap, HashMap, HashSet, VecDeque};
use std::io::{BufRead, Write};
use std::os::windows::fs::FileExt;
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::{Condvar, Mutex, MutexGuard, OnceLock, RwLock};
use std::time::{Duration, Instant};

/// A piece of a file the pack holds.
struct Piece {
    len: u64,
    /// Where in the pack it starts.
    at: u64,
    /// Read from the pack in this launch (counts toward what the reader
    /// thread may run ahead of).
    served: AtomicBool,
}

/// A package file as the pack knows it.
struct Source {
    key: String,
    size: u64,
    time: u64,
    pieces: BTreeMap<u64, Piece>,
}

/// Bytes read from a file, waiting to be written to the pack.
struct Adding {
    source: u32,
    offset: u64,
    bytes: Vec<u8>,
}

#[derive(Default)]
struct Queue {
    items: VecDeque<Adding>,
    bytes: u64,
    /// Pieces queued, not yet in the index.
    queued: HashSet<(u32, u64)>,
}

#[derive(Default)]
struct Counts {
    /// Reads answered from the pack, and their bytes.
    hits: AtomicU64,
    hit_bytes: AtomicU64,
    /// Reads of package files the pack did not hold, and their bytes.
    misses: AtomicU64,
    miss_bytes: AtomicU64,
    /// Bytes added to the pack; reads left out because the queue was full.
    added: AtomicU64,
    dropped: AtomicU64,
    /// Bytes the reader thread has read ahead.
    ahead: AtomicU64,
    /// Time spent in pack reads, nanoseconds.
    hit_ns: AtomicU64,
    /// The title's reads answered from the block cache; blocks read in.
    cached: AtomicU64,
    blocks_read: AtomicU64,
    block_ns: AtomicU64,
}

/// The title's own reads of package files go a few KiB at a time, on its
/// main thread, and come back to the same pages: 105,000 reads of 4-24 KiB
/// over 277 MB of `shaders.rpf` in a load, 875 MB in all, while a busy PC's
/// file cache keeps few of them, so each went to the disk again (101 s of
/// such re-reads in run n16b). They are answered from blocks of the file
/// held here instead, read in whole when first wanted: about 300 block
/// reads for that load with 256 MB. `VICTORY_READ_CACHE_MB` (256; 0: off).
/// Let go whole once the title has read nothing for a while.
struct BlockCache {
    budget: usize,
    blocks: Mutex<Blocks>,
    files: Mutex<HashMap<u32, Option<std::sync::Arc<std::fs::File>>>>,
}

#[derive(Default)]
struct Blocks {
    /// By (source, block number): the bytes and when last used.
    held: HashMap<(u32, u64), (std::sync::Arc<[u8]>, u64)>,
    /// Use stamp to block, oldest first.
    order: BTreeMap<u64, (u32, u64)>,
    stamp: u64,
    last_use: Option<Instant>,
}

/// A block of the cache.
const BLOCK: u64 = 1 << 20;
/// How long without a read before the cache is let go.
const IDLE: Duration = Duration::from_secs(20);

impl BlockCache {
    fn new() -> BlockCache {
        let mb = std::env::var("VICTORY_READ_CACHE_MB").ok().and_then(|v| v.trim().parse::<usize>().ok()).unwrap_or(256);
        BlockCache { budget: (mb << 20) / BLOCK as usize, blocks: Mutex::default(), files: Mutex::default() }
    }

    fn get(&self, key: (u32, u64)) -> Option<std::sync::Arc<[u8]>> {
        let mut b = lock(&self.blocks);
        b.stamp += 1;
        let stamp = b.stamp;
        b.last_use = Some(Instant::now());
        let (bytes, old) = b.held.get_mut(&key).map(|(bytes, used)| (bytes.clone(), std::mem::replace(used, stamp)))?;
        b.order.remove(&old);
        b.order.insert(stamp, key);
        Some(bytes)
    }

    fn put(&self, key: (u32, u64), bytes: std::sync::Arc<[u8]>) {
        let mut b = lock(&self.blocks);
        b.stamp += 1;
        let stamp = b.stamp;
        if let Some((_, old)) = b.held.insert(key, (bytes, stamp)) {
            b.order.remove(&old);
        }
        b.order.insert(stamp, key);
        while b.held.len() > self.budget {
            let Some((_, oldest)) = b.order.pop_first() else {
                break;
            };
            b.held.remove(&oldest);
        }
    }

    /// Lets the blocks go if the title has read nothing for [`IDLE`].
    fn trim_idle(&self) -> Option<usize> {
        let mut b = lock(&self.blocks);
        if b.held.is_empty() || b.last_use.is_none_or(|t| t.elapsed() < IDLE) {
            return None;
        }
        let n = b.held.len();
        *b = Blocks::default();
        Some(n)
    }

    fn file(&self, source: u32, key: &str) -> Option<std::sync::Arc<std::fs::File>> {
        lock(&self.files)
            .entry(source)
            .or_insert_with(|| std::fs::File::open(key).ok().map(std::sync::Arc::new))
            .clone()
    }
}

pub(crate) struct Pack {
    dir: PathBuf,
    sources: RwLock<Vec<Source>>,
    /// The title's open handles to package files: source, and whether the
    /// handle reads synchronously.
    handles: Mutex<HashMap<usize, (u32, bool)>>,
    index: Mutex<std::fs::File>,
    queue: Mutex<Queue>,
    wake: Condvar,
    add: bool,
    cap: u64,
    /// The pack's length as written and indexed.
    end: AtomicU64,
    /// Bytes of pieces read from the pack the first time this launch.
    consumed: AtomicU64,
    counts: Counts,
    started: Instant,
    cache: BlockCache,
}

/// Bytes waiting to be written, at most; a read past it is not added.
const QUEUE_BYTES: u64 = 128 << 20;
/// How much the reader thread reads at a time.
const AHEAD_CHUNK: usize = 4 << 20;

fn lock<T>(m: &Mutex<T>) -> MutexGuard<'_, T> {
    m.lock().unwrap_or_else(|e| e.into_inner())
}

/// The pack, opened on first use; `None` when `VICTORY_LOAD_PACK` is unset
/// or the folder cannot be used.
pub(crate) fn pack() -> Option<&'static Pack> {
    static PACK: OnceLock<Option<Pack>> = OnceLock::new();
    PACK.get_or_init(|| {
        let dir = PathBuf::from(std::env::var_os("VICTORY_LOAD_PACK").filter(|v| !v.is_empty())?);
        match Pack::open(dir.clone()) {
            Ok(pack) => Some(pack),
            Err(error) => {
                tracing::warn!(dir = %dir.display(), %error, "load pack: cannot be used");
                None
            }
        }
    })
    .as_ref()
    .map(|pack| {
        pack.start_threads();
        pack
    })
}

pub(crate) fn on() -> bool {
    static ON: OnceLock<bool> = OnceLock::new();
    *ON.get_or_init(|| std::env::var_os("VICTORY_LOAD_PACK").is_some_and(|v| !v.is_empty()))
}

impl Pack {
    fn open(dir: PathBuf) -> std::io::Result<Pack> {
        std::fs::create_dir_all(&dir)?;
        let bin = dir.join("pack.bin");
        let idx = dir.join("pack.idx");
        let bin_len = std::fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(&bin)?
            .metadata()?
            .len();
        let mut sources: Vec<Source> = Vec::new();
        let mut ids: HashMap<u32, usize> = HashMap::new();
        let mut end = 0u64;
        let (mut pieces, mut bad) = (0u64, 0u64);
        if let Ok(file) = std::fs::File::open(&idx) {
            for line in std::io::BufReader::new(file).lines() {
                let line = line?;
                let mut parts = line.splitn(5, ' ');
                match parts.next() {
                    Some("F") => {
                        let (Some(id), Some(size), Some(time), Some(key)) =
                            (parts.next(), parts.next(), parts.next(), parts.next())
                        else {
                            bad += 1;
                            continue;
                        };
                        let (Ok(id), Ok(size), Ok(time)) = (id.parse(), size.parse(), time.parse()) else {
                            bad += 1;
                            continue;
                        };
                        ids.insert(id, sources.len());
                        sources.push(Source { key: key.to_string(), size, time, pieces: BTreeMap::new() });
                    }
                    Some("E") => {
                        let numbers: Vec<u64> = parts.filter_map(|p| p.parse().ok()).collect();
                        let &[id, offset, len, at] = numbers.as_slice() else {
                            bad += 1;
                            continue;
                        };
                        let Some(&i) = u32::try_from(id).ok().and_then(|id| ids.get(&id)) else {
                            bad += 1;
                            continue;
                        };
                        // Written after the bytes, so a piece past the
                        // pack's end is one a crash cut short.
                        if at + len > bin_len || len == 0 {
                            bad += 1;
                            continue;
                        }
                        end = end.max(at + len);
                        pieces += 1;
                        sources[i].pieces.insert(offset, Piece { len, at, served: AtomicBool::new(false) });
                    }
                    _ => bad += 1,
                }
            }
        }
        // Ids are positions; the index on disk names them, so they are
        // renumbered only if a line was lost.
        let renumber = ids.iter().any(|(&id, &i)| id as usize != i);
        let index = std::fs::OpenOptions::new().create(true).append(true).open(&idx)?;
        let add = std::env::var("VICTORY_LOAD_PACK_ADD").map_or(true, |v| v.trim() != "0");
        let cap = std::env::var("VICTORY_LOAD_PACK_GB")
            .ok()
            .and_then(|v| v.trim().parse::<u64>().ok())
            .unwrap_or(32)
            << 30;
        let pack = Pack {
            dir,
            sources: RwLock::new(sources),
            handles: Mutex::new(HashMap::new()),
            index: Mutex::new(index),
            queue: Mutex::new(Queue::default()),
            wake: Condvar::new(),
            add: add && !renumber,
            cap,
            end: AtomicU64::new(bin_len.max(end)),
            consumed: AtomicU64::new(0),
            counts: Counts::default(),
            started: Instant::now(),
            cache: BlockCache::new(),
        };
        tracing::info!(
            dir = %pack.dir.display(),
            files = pack.read_sources().len(),
            pieces,
            mb = bin_len >> 20,
            unreadable_lines = bad,
            adding = pack.add,
            cap_gb = cap >> 30,
            "load pack: opened"
        );
        Ok(pack)
    }

    fn read_sources(&self) -> std::sync::RwLockReadGuard<'_, Vec<Source>> {
        self.sources.read().unwrap_or_else(|e| e.into_inner())
    }

    fn start_threads(&'static self) {
        static STARTED: std::sync::Once = std::sync::Once::new();
        STARTED.call_once(|| {
            if self.add {
                let _ = std::thread::Builder::new().name("victory-pack-write".into()).spawn(move || self.write_loop());
            }
            let _ = std::thread::Builder::new().name("victory-pack-ahead".into()).spawn(move || self.ahead_loop());
        });
    }

    /// The source for a file just opened, added if new (and adding).
    fn source_for(&self, key: &str, size: u64, time: u64) -> Option<u32> {
        if let Some(i) = self
            .read_sources()
            .iter()
            .rposition(|s| s.key == key && s.size == size && s.time == time)
        {
            return u32::try_from(i).ok();
        }
        if !self.add {
            return None;
        }
        let mut sources = self.sources.write().unwrap_or_else(|e| e.into_inner());
        if let Some(i) = sources.iter().rposition(|s| s.key == key && s.size == size && s.time == time) {
            return u32::try_from(i).ok();
        }
        let id = u32::try_from(sources.len()).ok()?;
        let mut index = lock(&self.index);
        writeln!(index, "F {id} {size} {time} {key}").ok()?;
        index.flush().ok()?;
        sources.push(Source { key: key.to_string(), size, time, pieces: BTreeMap::new() });
        Some(id)
    }

    /// Where in the pack `[offset, offset + len)` of `source` lies: pieces
    /// (pack position, bytes) that together cover it, and the bytes of
    /// pieces read for the first time.
    fn find(&self, sources: &[Source], source: u32, offset: u64, len: u64) -> Option<(Vec<(u64, u64)>, u64)> {
        let s = sources.get(source as usize)?;
        let end = offset.checked_add(len)?;
        let (mut at, mut parts, mut first) = (offset, Vec::new(), 0);
        while at < end {
            let (&start, piece) = s.pieces.range(..=at).next_back()?;
            let piece_end = start + piece.len;
            if piece_end <= at || parts.len() == 64 {
                return None;
            }
            let take = piece_end.min(end) - at;
            parts.push((piece.at + (at - start), take));
            if !piece.served.load(Ordering::Relaxed) {
                first += piece.len;
            }
            at += take;
        }
        Some((parts, first))
    }

    /// Fills `out` with the bytes of `source` from `offset` if the pack
    /// holds them all (as far as the file goes); the bytes filled.
    pub(crate) fn read(&self, source: u32, offset: u64, out: &mut [u8]) -> Option<usize> {
        let started = Instant::now();
        let (parts, first, want) = {
            let sources = self.read_sources();
            let size = sources.get(source as usize)?.size;
            let want = (out.len() as u64).min(size.saturating_sub(offset));
            if want == 0 {
                return None;
            }
            let Some((parts, first)) = self.find(&sources, source, offset, want) else {
                self.counts.misses.fetch_add(1, Ordering::Relaxed);
                self.counts.miss_bytes.fetch_add(want, Ordering::Relaxed);
                return None;
            };
            (parts, first, want)
        };
        let mut done = 0usize;
        for (at, len) in parts {
            let part = &mut out[done..done + len as usize];
            if !read_pack(&self.dir, part, at) {
                return None;
            }
            done += len as usize;
        }
        if first > 0 {
            let sources = self.read_sources();
            let Some(s) = sources.get(source as usize) else {
                return None;
            };
            let mut at = offset;
            while at < offset + want {
                let Some((&start, piece)) = s.pieces.range(..=at).next_back() else {
                    break;
                };
                if !piece.served.swap(true, Ordering::Relaxed) {
                    self.consumed.fetch_add(piece.len, Ordering::Relaxed);
                }
                at = start + piece.len;
            }
        }
        self.counts.hits.fetch_add(1, Ordering::Relaxed);
        self.counts.hit_bytes.fetch_add(want, Ordering::Relaxed);
        self.counts.hit_ns.fetch_add(started.elapsed().as_nanos() as u64, Ordering::Relaxed);
        Some(want as usize)
    }

    /// Fills `out` with the bytes of `source` from `offset` (as far as the
    /// file goes) from the block cache, reading in the blocks it lacks
    /// ([`BlockCache`]); the bytes filled, or `None` if it is off or a block
    /// could not be read.
    pub(crate) fn read_cached(&self, source: u32, offset: u64, out: &mut [u8]) -> Option<usize> {
        if self.cache.budget == 0 {
            return None;
        }
        let (size, key) = {
            let sources = self.read_sources();
            let s = sources.get(source as usize)?;
            (s.size, s.key.clone())
        };
        let want = (out.len() as u64).min(size.saturating_sub(offset));
        if want == 0 {
            return None;
        }
        let mut done = 0u64;
        while done < want {
            let at = offset + done;
            let number = at / BLOCK;
            let bytes = match self.cache.get((source, number)) {
                Some(bytes) => bytes,
                None => {
                    let started = Instant::now();
                    let file = self.cache.file(source, &key)?;
                    let len = BLOCK.min(size - number * BLOCK) as usize;
                    let mut block = vec![0u8; len];
                    let mut got = 0;
                    while got < len {
                        match file.seek_read(&mut block[got..], number * BLOCK + got as u64) {
                            Ok(0) | Err(_) => return None,
                            Ok(n) => got += n,
                        }
                    }
                    let block: std::sync::Arc<[u8]> = block.into();
                    self.cache.put((source, number), block.clone());
                    self.counts.blocks_read.fetch_add(1, Ordering::Relaxed);
                    self.counts.block_ns.fetch_add(started.elapsed().as_nanos() as u64, Ordering::Relaxed);
                    block
                }
            };
            let within = (at - number * BLOCK) as usize;
            let take = (bytes.len() - within).min((want - done) as usize);
            if take == 0 {
                return None;
            }
            out[done as usize..done as usize + take].copy_from_slice(&bytes[within..within + take]);
            done += take as u64;
        }
        self.counts.cached.fetch_add(1, Ordering::Relaxed);
        Some(want as usize)
    }

    /// Queues bytes just read from `source` at `offset` for the pack,
    /// unless it holds them already.
    pub(crate) fn record(&self, source: u32, offset: u64, bytes: &[u8]) {
        if !self.add || bytes.is_empty() {
            return;
        }
        let len = bytes.len() as u64;
        {
            let sources = self.read_sources();
            if self.find(&sources, source, offset, len).is_some() {
                return;
            }
        }
        let mut queue = lock(&self.queue);
        if queue.bytes + len > QUEUE_BYTES {
            self.counts.dropped.fetch_add(1, Ordering::Relaxed);
            return;
        }
        if self.end.load(Ordering::Relaxed) + queue.bytes + len > self.cap {
            return;
        }
        if !queue.queued.insert((source, offset)) {
            return;
        }
        queue.bytes += len;
        queue.items.push_back(Adding { source, offset, bytes: bytes.to_vec() });
        self.wake.notify_one();
    }

    /// Writes queued bytes to the pack's end, then lists them.
    fn write_loop(&'static self) {
        let path = self.dir.join("pack.bin");
        let Ok(mut bin) = std::fs::OpenOptions::new().append(true).open(&path) else {
            tracing::warn!(path = %path.display(), "load pack: cannot be written");
            return;
        };
        loop {
            let items: Vec<Adding> = {
                let mut queue = lock(&self.queue);
                while queue.items.is_empty() {
                    queue = self.wake.wait(queue).unwrap_or_else(|e| e.into_inner());
                }
                // Gathers what comes in for a moment, for fewer, larger writes.
                drop(queue);
                std::thread::sleep(Duration::from_millis(250));
                let mut queue = lock(&self.queue);
                queue.items.drain(..).collect()
            };
            let mut at = self.end.load(Ordering::Relaxed);
            let mut lines = String::new();
            let mut listed = Vec::with_capacity(items.len());
            let mut buffer = Vec::with_capacity(items.iter().map(|i| i.bytes.len()).sum());
            for item in &items {
                use std::fmt::Write as _;
                let len = item.bytes.len() as u64;
                let _ = writeln!(lines, "E {} {} {len} {}", item.source, item.offset, at + buffer.len() as u64);
                listed.push((item.source, item.offset, len, at + buffer.len() as u64));
                buffer.extend_from_slice(&item.bytes);
            }
            let written = bin.write_all(&buffer).and_then(|()| bin.flush());
            let mut queue = lock(&self.queue);
            for item in &items {
                queue.queued.remove(&(item.source, item.offset));
                queue.bytes -= item.bytes.len() as u64;
            }
            drop(queue);
            if let Err(error) = written {
                tracing::warn!(%error, "load pack: writing failed; no more is added");
                return;
            }
            {
                let mut index = lock(&self.index);
                if index.write_all(lines.as_bytes()).and_then(|()| index.flush()).is_err() {
                    tracing::warn!("load pack: the index could not be written; no more is added");
                    return;
                }
            }
            at += buffer.len() as u64;
            let mut sources = self.sources.write().unwrap_or_else(|e| e.into_inner());
            for (source, offset, len, piece_at) in listed {
                if let Some(s) = sources.get_mut(source as usize) {
                    // Served already: it was just read from the file.
                    s.pieces.insert(offset, Piece { len, at: piece_at, served: AtomicBool::new(true) });
                }
            }
            drop(sources);
            self.end.store(at, Ordering::Relaxed);
            self.counts.added.fetch_add(buffer.len() as u64, Ordering::Relaxed);
        }
    }

    /// Reads the pack front to back into the host's file cache, staying a
    /// window ahead of what has been read from it; and every 10 s a line
    /// of counts.
    fn ahead_loop(&'static self) {
        let path = self.dir.join("pack.bin");
        let length = self.end.load(Ordering::Relaxed);
        let file = std::fs::File::open(&path).ok();
        let mut buffer = vec![0u8; AHEAD_CHUNK];
        let mut pos = 0u64;
        let mut last = Instant::now();
        let mut done_logged = false;
        loop {
            if last.elapsed() >= Duration::from_secs(10) {
                last = Instant::now();
                self.log_counts(pos, length);
                if let Some(n) = self.cache.trim_idle() {
                    tracing::info!(mb = n as u64 * BLOCK >> 20, "load pack: the title's read cache let go (no reads for 20 s)");
                }
            }
            let Some(file) = file.as_ref().filter(|_| pos < length) else {
                if !done_logged && length > 0 {
                    done_logged = true;
                    tracing::info!(
                        mb = length >> 20,
                        s = self.started.elapsed().as_secs(),
                        "load pack: read ahead to its end"
                    );
                }
                std::thread::sleep(Duration::from_millis(500));
                continue;
            };
            if pos > self.consumed.load(Ordering::Relaxed) + window() {
                std::thread::sleep(Duration::from_millis(20));
                continue;
            }
            let n = (length - pos).min(AHEAD_CHUNK as u64) as usize;
            match file.seek_read(&mut buffer[..n], pos) {
                Ok(0) | Err(_) => pos = length,
                Ok(n) => {
                    pos += n as u64;
                    self.counts.ahead.store(pos, Ordering::Relaxed);
                }
            }
        }
    }

    fn log_counts(&self, ahead: u64, length: u64) {
        let c = &self.counts;
        let hits = c.hits.load(Ordering::Relaxed);
        tracing::info!(
            s = self.started.elapsed().as_secs(),
            reads_from_pack = hits,
            pack_mb = c.hit_bytes.load(Ordering::Relaxed) >> 20,
            pack_ms_each = format_args!(
                "{:.2}",
                c.hit_ns.load(Ordering::Relaxed) as f64 / 1e6 / hits.max(1) as f64
            ),
            reads_from_files = c.misses.load(Ordering::Relaxed),
            files_mb = c.miss_bytes.load(Ordering::Relaxed) >> 20,
            added_mb = c.added.load(Ordering::Relaxed) >> 20,
            left_out = c.dropped.load(Ordering::Relaxed),
            ahead_mb = ahead >> 20,
            of_mb = length >> 20,
            used_mb = self.consumed.load(Ordering::Relaxed) >> 20,
            title_reads_cached = c.cached.load(Ordering::Relaxed),
            blocks_read = c.blocks_read.load(Ordering::Relaxed),
            block_ms_each = format_args!(
                "{:.1}",
                c.block_ns.load(Ordering::Relaxed) as f64 / 1e6 / c.blocks_read.load(Ordering::Relaxed).max(1) as f64
            ),
            cache_mb = lock(&self.cache.blocks).held.len() as u64 * BLOCK >> 20,
            "load pack"
        );
    }

    /// Remembers a handle the title opened: a package file read only, or
    /// forgets the handle (its number may have been another file's).
    pub(crate) fn opened(&self, handle: usize, key: Option<&str>, synchronous: bool) {
        let source = key.and_then(|key| {
            let (size, time) = file_identity(handle)?;
            self.source_for(key, size, time)
        });
        let mut handles = lock(&self.handles);
        match source {
            Some(source) => handles.insert(handle, (source, synchronous)),
            None => handles.remove(&handle),
        };
    }

    pub(crate) fn handle(&self, handle: usize) -> Option<(u32, bool)> {
        lock(&self.handles).get(&handle).copied()
    }

    #[cfg(test)]
    pub(crate) fn hits(&self) -> u64 {
        self.counts.hits.load(Ordering::Relaxed)
    }

    #[cfg(test)]
    pub(crate) fn length(&self) -> u64 {
        self.end.load(Ordering::Relaxed)
    }
}

/// How far the reader thread may run ahead of what has been used: a third
/// of the memory the host has to spare, between 64 MiB and 1 GiB.
fn window() -> u64 {
    use windows_sys::Win32::System::SystemInformation::{GlobalMemoryStatusEx, MEMORYSTATUSEX};
    let mut status = MEMORYSTATUSEX { dwLength: size_of::<MEMORYSTATUSEX>() as u32, ..Default::default() };
    // SAFETY: a sized out struct.
    let available = if unsafe { GlobalMemoryStatusEx(&mut status) } != 0 { status.ullAvailPhys } else { 0 };
    (available / 3).clamp(64 << 20, 1 << 30)
}

/// Reads `out` from the pack at `at` through this thread's own handle.
fn read_pack(dir: &std::path::Path, out: &mut [u8], at: u64) -> bool {
    thread_local! {
        static FILE: std::cell::RefCell<Option<std::fs::File>> = const { std::cell::RefCell::new(None) };
    }
    FILE.with_borrow_mut(|file| {
        if file.is_none() {
            *file = std::fs::File::open(dir.join("pack.bin")).ok();
        }
        let Some(file) = file.as_ref() else {
            return false;
        };
        let mut done = 0;
        while done < out.len() {
            match file.seek_read(&mut out[done..], at + done as u64) {
                Ok(0) | Err(_) => return false,
                Ok(n) => done += n,
            }
        }
        true
    })
}

/// A file's size and last write time, by its handle; `None` for a
/// directory or a handle that is not a file's.
fn file_identity(handle: usize) -> Option<(u64, u64)> {
    use windows_sys::Win32::Storage::FileSystem::{
        BY_HANDLE_FILE_INFORMATION, FILE_ATTRIBUTE_DIRECTORY, GetFileInformationByHandle,
    };
    let mut info = BY_HANDLE_FILE_INFORMATION::default();
    // SAFETY: a handle the host just gave; a sized out struct.
    if unsafe { GetFileInformationByHandle(handle as _, &mut info) } == 0 {
        return None;
    }
    if info.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY != 0 {
        return None;
    }
    let size = u64::from(info.nFileSizeHigh) << 32 | u64::from(info.nFileSizeLow);
    let time = u64::from(info.ftLastWriteTime.dwHighDateTime) << 32 | u64::from(info.ftLastWriteTime.dwLowDateTime);
    Some((size, time))
}

/// The key a host path is known by: lower case, `\` separators.
pub(crate) fn key(host: &[u16]) -> String {
    let host = host.strip_suffix(&[0]).unwrap_or(host);
    String::from_utf16_lossy(host).replace('/', "\\").to_lowercase()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn pack_in(dir: &std::path::Path) -> Pack {
        Pack::open(dir.to_path_buf()).unwrap()
    }

    #[test]
    fn pieces_are_found_across_neighbours_and_not_past_gaps() {
        let dir = tempfile::tempdir().unwrap();
        let pack = pack_in(dir.path());
        {
            let mut sources = pack.sources.write().unwrap();
            let mut pieces = BTreeMap::new();
            pieces.insert(0, Piece { len: 100, at: 1000, served: AtomicBool::new(false) });
            pieces.insert(100, Piece { len: 50, at: 5000, served: AtomicBool::new(false) });
            pieces.insert(400, Piece { len: 10, at: 9000, served: AtomicBool::new(false) });
            sources.push(Source { key: "a".into(), size: 1000, time: 1, pieces });
        }
        let sources = pack.read_sources();
        let (parts, first) = pack.find(&sources, 0, 90, 30).unwrap();
        assert_eq!(parts, vec![(1090, 10), (5000, 20)]);
        assert_eq!(first, 150);
        assert!(pack.find(&sources, 0, 140, 20).is_none(), "a gap at 150");
        assert!(pack.find(&sources, 0, 395, 10).is_none(), "starts before a piece");
        assert_eq!(pack.find(&sources, 0, 402, 8).unwrap().0, vec![(9002, 8)]);
        assert!(pack.find(&sources, 1, 0, 1).is_none(), "no such file");
    }

    #[test]
    fn the_block_cache_answers_reads_across_blocks_and_reads_each_block_once() {
        use std::os::windows::ffi::OsStrExt;
        let dir = tempfile::tempdir().unwrap();
        let data = dir.path().join("data.bin");
        let len = 3 * BLOCK as usize + 1000;
        let bytes: Vec<u8> = (0..len as u32).map(|i| (i * 31 % 253) as u8).collect();
        std::fs::write(&data, &bytes).unwrap();
        let file = std::fs::File::open(&data).unwrap();
        let handle = std::os::windows::io::AsRawHandle::as_raw_handle(&file) as usize;
        let mut pack = pack_in(&dir.path().join("pack"));
        pack.cache.budget = 2;
        let key = key(&data.as_os_str().encode_wide().collect::<Vec<u16>>());
        pack.opened(handle, Some(&key), true);
        let (source, _) = pack.handle(handle).unwrap();
        let blocks = || pack.counts.blocks_read.load(Ordering::Relaxed);
        // Across the first two blocks.
        let at = BLOCK as usize - 100;
        let mut out = vec![0; 300];
        assert_eq!(pack.read_cached(source, at as u64, &mut out), Some(300));
        assert_eq!(out, &bytes[at..at + 300]);
        assert_eq!(blocks(), 2);
        // Held: no read.
        let mut out = vec![0; 4096];
        assert_eq!(pack.read_cached(source, 4096, &mut out), Some(4096));
        assert_eq!(out, &bytes[4096..8192]);
        assert_eq!(blocks(), 2);
        // The last, short block, past the file's end: as far as it goes.
        let mut out = vec![0; 5000];
        assert_eq!(pack.read_cached(source, (len - 1000) as u64, &mut out), Some(1000));
        assert_eq!(&out[..1000], &bytes[len - 1000..]);
        assert_eq!(blocks(), 3);
        assert!(pack.read_cached(source, len as u64, &mut out).is_none(), "at the end");
        // Two blocks held at most: the least lately used went (block 1;
        // block 0 was used again after it).
        assert_eq!(lock(&pack.cache.blocks).held.len(), 2);
        assert!(lock(&pack.cache.blocks).held.contains_key(&(source, 0)));
        assert!(lock(&pack.cache.blocks).held.contains_key(&(source, 3)));
        let mut out = vec![0; 10];
        assert_eq!(pack.read_cached(source, 5, &mut out), Some(10));
        assert_eq!(out, &bytes[5..15]);
        assert_eq!(blocks(), 3);
        assert_eq!(pack.read_cached(source, BLOCK + 7, &mut out), Some(10));
        assert_eq!(out, &bytes[BLOCK as usize + 7..BLOCK as usize + 17]);
        assert_eq!(blocks(), 4);
        assert!(pack.cache.trim_idle().is_none(), "just used");
        // Off.
        pack.cache.budget = 0;
        assert!(pack.read_cached(source, 5, &mut out).is_none());
    }

    #[test]
    fn what_is_added_is_read_back_by_the_next_launch() {
        let dir = tempfile::tempdir().unwrap();
        let data = dir.path().join("data.bin");
        let bytes: Vec<u8> = (0..200_000u32).map(|i| (i * 7 % 251) as u8).collect();
        std::fs::write(&data, &bytes).unwrap();
        let file = std::fs::File::open(&data).unwrap();
        let handle = std::os::windows::io::AsRawHandle::as_raw_handle(&file) as usize;
        let packdir = dir.path().join("pack");
        {
            let pack: &'static Pack = Box::leak(Box::new(pack_in(&packdir)));
            pack.opened(handle, Some("data"), true);
            let (source, synchronous) = pack.handle(handle).unwrap();
            assert!(synchronous);
            let mut out = vec![0; 5000];
            assert!(pack.read(source, 1000, &mut out).is_none(), "an empty pack holds nothing");
            pack.record(source, 1000, &bytes[1000..6000]);
            pack.record(source, 6000, &bytes[6000..7000]);
            std::thread::spawn(move || pack.write_loop());
            let t = Instant::now();
            while pack.end.load(Ordering::Relaxed) < 6000 && t.elapsed() < Duration::from_secs(5) {
                std::thread::sleep(Duration::from_millis(20));
            }
            assert_eq!(pack.end.load(Ordering::Relaxed), 6000);
            let mut out = vec![0; 5500];
            assert_eq!(pack.read(source, 1200, &mut out), Some(5500));
            assert_eq!(out, &bytes[1200..6700]);
        }
        // The next launch.
        let pack = pack_in(&packdir);
        pack.opened(handle, Some("data"), true);
        let (source, _) = pack.handle(handle).unwrap();
        let mut out = vec![0; 6000];
        assert_eq!(pack.read(source, 1000, &mut out), Some(6000));
        assert_eq!(out, &bytes[1000..7000]);
        assert_eq!(pack.consumed.load(Ordering::Relaxed), 6000);
        assert!(pack.read(source, 7000, &mut out).is_none(), "past what was added");
        // A changed file is another file.
        std::fs::write(&data.with_extension("2"), &bytes[..100]).unwrap();
        let other = std::fs::File::open(data.with_extension("2")).unwrap();
        let other_handle = std::os::windows::io::AsRawHandle::as_raw_handle(&other) as usize;
        pack.opened(other_handle, Some("data"), true);
        let (changed, _) = pack.handle(other_handle).unwrap();
        assert_ne!(changed, source);
        assert!(pack.read(changed, 0, &mut out[..10]).is_none());
        // Reads clamp to the file's end.
        let mut out = vec![0; 10_000];
        assert!(pack.read(source, 199_999, &mut out).is_none());
        // A handle reused for something else is forgotten.
        pack.opened(handle, None, true);
        assert!(pack.handle(handle).is_none());
    }
}
